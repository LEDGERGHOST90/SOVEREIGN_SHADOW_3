#!/usr/bin/env python3
"""
Coinbase Advanced Futures Trading Connector
Part of the Legacy Loop Hybrid Trading System

This module provides compliant US futures trading through Coinbase Advanced.
Integrates with the existing Olympus Elite ecosystem.
"""

import os
import json
import time
import hmac
import hashlib
import base64
import requests
from datetime import datetime
from typing import Dict, List, Optional, Any
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CoinbaseFuturesConnector:
    """
    Coinbase Advanced Futures Trading Connector
    
    Provides:
    - Futures account management
    - Position opening/closing
    - Risk management
    - Integration with Legacy Loop system
    """
    
    def __init__(self):
        """Initialize the Coinbase futures connector"""
        self.api_key = os.getenv('COINBASE_API_KEY')
        self.api_secret = os.getenv('COINBASE_API_SECRET')
        self.passphrase = os.getenv('COINBASE_PASSPHRASE')
        self.sandbox = os.getenv('COINBASE_SANDBOX', 'false').lower() == 'true'
        
        # API endpoints
        if self.sandbox:
            self.base_url = "https://api-public.sandbox.exchange.coinbase.com"
        else:
            self.base_url = "https://api.exchange.coinbase.com"
            
        # Futures-specific endpoints
        self.futures_base = f"{self.base_url}/api/v3/brokerage"
        
        # Validate credentials
        if not all([self.api_key, self.api_secret, self.passphrase]):
            logger.warning("Coinbase API credentials not found in environment variables")
    
    def _generate_signature(self, timestamp: str, method: str, path: str, body: str = '') -> str:
        """Generate API signature for authentication"""
        message = timestamp + method + path + body
        signature = hmac.new(
            base64.b64decode(self.api_secret),
            message.encode('utf-8'),
            hashlib.sha256
        ).digest()
        return base64.b64encode(signature).decode()
    
    def _make_request(self, method: str, endpoint: str, data: Dict = None) -> Dict:
        """Make authenticated API request"""
        timestamp = str(time.time())
        path = endpoint.replace(self.base_url, '')
        body = json.dumps(data) if data else ''
        
        headers = {
            'CB-ACCESS-KEY': self.api_key,
            'CB-ACCESS-SIGN': self._generate_signature(timestamp, method, path, body),
            'CB-ACCESS-TIMESTAMP': timestamp,
            'CB-ACCESS-PASSPHRASE': self.passphrase,
            'Content-Type': 'application/json'
        }
        
        url = f"{self.base_url}{path}"
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, headers=headers, data=body)
            elif method == 'DELETE':
                response = requests.delete(url, headers=headers)
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return {"error": str(e)}
    
    def get_futures_account(self) -> Dict:
        """Get futures account information"""
        endpoint = "/accounts"
        return self._make_request('GET', endpoint)
    
    def get_futures_positions(self) -> Dict:
        """Get current futures positions"""
        endpoint = "/cfm/positions"
        return self._make_request('GET', endpoint)
    
    def get_futures_products(self) -> Dict:
        """Get available futures products"""
        endpoint = "/cfm/products"
        return self._make_request('GET', endpoint)
    
    def place_futures_order(self, 
                          product_id: str,
                          side: str,  # 'BUY' or 'SELL'
                          size: str,
                          order_type: str = 'MARKET',
                          price: str = None,
                          leverage: str = None) -> Dict:
        """
        Place a futures order
        
        Args:
            product_id: Futures product (e.g., 'ETH-PERP-INTX')
            side: 'BUY' or 'SELL'
            size: Order size
            order_type: 'MARKET' or 'LIMIT'
            price: Limit price (required for LIMIT orders)
            leverage: Leverage multiplier
        """
        endpoint = "/cfm/orders"
        
        order_data = {
            "product_id": product_id,
            "side": side,
            "size": size,
            "order_type": order_type
        }
        
        if order_type == 'LIMIT' and price:
            order_data["price"] = price
            
        if leverage:
            order_data["leverage"] = leverage
        
        logger.info(f"Placing futures order: {order_data}")
        return self._make_request('POST', endpoint, order_data)
    
    def close_position(self, product_id: str, size: str = None) -> Dict:
        """
        Close a futures position
        
        Args:
            product_id: Futures product
            size: Partial close size (None for full close)
        """
        # Get current position
        positions = self.get_futures_positions()
        
        if 'error' in positions:
            return positions
        
        # Find the position to close
        target_position = None
        for position in positions.get('positions', []):
            if position.get('product_id') == product_id:
                target_position = position
                break
        
        if not target_position:
            return {"error": f"No position found for {product_id}"}
        
        # Determine close side (opposite of current position)
        current_side = target_position.get('side')
        close_side = 'SELL' if current_side == 'BUY' else 'BUY'
        
        # Use provided size or full position size
        close_size = size or target_position.get('size')
        
        return self.place_futures_order(
            product_id=product_id,
            side=close_side,
            size=close_size,
            order_type='MARKET'
        )
    
    def set_stop_loss(self, product_id: str, stop_price: str, size: str = None) -> Dict:
        """
        Set stop loss for a position
        
        Args:
            product_id: Futures product
            stop_price: Stop loss trigger price
            size: Position size (None for full position)
        """
        endpoint = "/cfm/orders"
        
        # Get current position to determine side
        positions = self.get_futures_positions()
        target_position = None
        
        for position in positions.get('positions', []):
            if position.get('product_id') == product_id:
                target_position = position
                break
        
        if not target_position:
            return {"error": f"No position found for {product_id}"}
        
        # Determine stop side (opposite of position)
        position_side = target_position.get('side')
        stop_side = 'SELL' if position_side == 'BUY' else 'BUY'
        stop_size = size or target_position.get('size')
        
        order_data = {
            "product_id": product_id,
            "side": stop_side,
            "size": stop_size,
            "order_type": "STOP_LOSS",
            "stop_price": stop_price
        }
        
        return self._make_request('POST', endpoint, order_data)
    
    def get_market_data(self, product_id: str) -> Dict:
        """Get market data for a futures product"""
        endpoint = f"/products/{product_id}/ticker"
        return self._make_request('GET', endpoint)
    
    def calculate_hedge_size(self, spot_exposure: float, hedge_ratio: float = 0.8) -> float:
        """
        Calculate optimal hedge size for spot exposure
        
        Args:
            spot_exposure: USD value of spot exposure
            hedge_ratio: Percentage to hedge (0.8 = 80%)
        """
        # Get ETH price for conversion
        eth_ticker = self.get_market_data('ETH-USD')
        
        if 'error' in eth_ticker:
            logger.error("Failed to get ETH price for hedge calculation")
            return 0.0
        
        eth_price = float(eth_ticker.get('price', 0))
        if eth_price == 0:
            return 0.0
        
        # Calculate ETH amount to hedge
        eth_to_hedge = (spot_exposure * hedge_ratio) / eth_price
        
        logger.info(f"Hedge calculation: ${spot_exposure:.2f} exposure @ {hedge_ratio*100}% = {eth_to_hedge:.4f} ETH")
        return eth_to_hedge
    
    def execute_steth_hedge(self, steth_value: float, hedge_ratio: float = 0.8) -> Dict:
        """
        Execute hedge for stETH position
        
        Args:
            steth_value: USD value of stETH position
            hedge_ratio: Percentage to hedge
        """
        logger.info(f"Executing stETH hedge: ${steth_value:.2f} @ {hedge_ratio*100}%")
        
        # Calculate hedge size
        hedge_size = self.calculate_hedge_size(steth_value, hedge_ratio)
        
        if hedge_size == 0:
            return {"error": "Failed to calculate hedge size"}
        
        # Place short order
        result = self.place_futures_order(
            product_id='ETH-PERP-INTX',  # Coinbase ETH perpetual
            side='SELL',  # Short to hedge long exposure
            size=str(round(hedge_size, 4)),
            order_type='MARKET'
        )
        
        if 'error' not in result:
            logger.info(f"Hedge executed successfully: {result}")
            
            # Set stop loss at 5% above entry
            eth_price = float(self.get_market_data('ETH-USD').get('price', 0))
            stop_price = eth_price * 1.05  # 5% stop loss
            
            self.set_stop_loss(
                product_id='ETH-PERP-INTX',
                stop_price=str(round(stop_price, 2)),
                size=str(round(hedge_size, 4))
            )
        
        return result
    
    def get_portfolio_summary(self) -> Dict:
        """Get comprehensive portfolio summary"""
        summary = {
            "timestamp": datetime.now().isoformat(),
            "account": self.get_futures_account(),
            "positions": self.get_futures_positions(),
            "available_products": self.get_futures_products()
        }
        
        return summary

def main():
    """Test the Coinbase futures connector"""
    print("🚀 Coinbase Advanced Futures Connector Test")
    print("=" * 50)
    
    connector = CoinbaseFuturesConnector()
    
    # Test account access
    print("Testing account access...")
    account = connector.get_futures_account()
    print(f"Account status: {'✅ Connected' if 'error' not in account else '❌ Failed'}")
    
    # Test market data
    print("\nTesting market data...")
    eth_data = connector.get_market_data('ETH-USD')
    if 'error' not in eth_data:
        print(f"ETH Price: ${eth_data.get('price', 'N/A')}")
    
    # Test hedge calculation
    print("\nTesting hedge calculation...")
    test_steth_value = 3636  # User's stETH value
    hedge_size = connector.calculate_hedge_size(test_steth_value, 0.8)
    print(f"Hedge size for ${test_steth_value}: {hedge_size:.4f} ETH")
    
    print("\n✅ Coinbase connector ready for integration!")

if __name__ == "__main__":
    main()

