#!/usr/bin/env python3
"""
Coinbase Advanced API Connector - Updated for CDP API
====================================================
"""

import os
import json
import time
import requests
from datetime import datetime
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
import jwt
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CoinbaseAdvancedConnector:
    """
    Updated Coinbase connector for CDP API format
    """
    
    def __init__(self):
        self.api_key_name = os.getenv('COINBASE_API_KEY')
        self.private_key_pem = os.getenv('COINBASE_PRIVATE_KEY')
        self.base_url = "https://api.coinbase.com"
        
        if not self.api_key_name or not self.private_key_pem:
            logger.warning("Coinbase API credentials not found")
            return
            
        # Load private key
        try:
            self.private_key = serialization.load_pem_private_key(
                self.private_key_pem.encode('utf-8'),
                password=None
            )
            logger.info("✅ Coinbase API credentials loaded")
        except Exception as e:
            logger.error(f"Failed to load private key: {e}")
            self.private_key = None
    
    def _create_jwt_token(self, request_method: str, request_path: str) -> str:
        """Create JWT token for authentication"""
        if not self.private_key:
            raise Exception("Private key not loaded")
            
        # Create JWT payload
        payload = {
            'sub': self.api_key_name,
            'iss': "cdp",
            'nbf': int(time.time()),
            'exp': int(time.time()) + 120,  # 2 minutes
            'aud': ["retail_rest_api_proxy"],
            'uri': f"{request_method} {request_path}"
        }
        
        # Sign JWT
        token = jwt.encode(payload, self.private_key, algorithm='ES256')
        return token
    
    def _make_request(self, method: str, endpoint: str, data: dict = None) -> dict:
        """Make authenticated API request"""
        try:
            # Create JWT token
            jwt_token = self._create_jwt_token(method, endpoint)
            
            headers = {
                'Authorization': f'Bearer {jwt_token}',
                'Content-Type': 'application/json'
            }
            
            url = f"{self.base_url}{endpoint}"
            
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data)
            
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            logger.error(f"API request failed: {e}")
            return {"error": str(e)}
    
    def get_accounts(self) -> dict:
        """Get account information"""
        return self._make_request('GET', '/api/v3/brokerage/accounts')
    
    def place_market_order(self, product_id: str, side: str, size: str) -> dict:
        """
        Place a market order
        
        Args:
            product_id: Trading pair (e.g., 'ETH-USD')
            side: 'BUY' or 'SELL'
            size: Order size
        """
        order_data = {
            "client_order_id": f"hedge_{int(time.time())}",
            "product_id": product_id,
            "side": side,
            "order_configuration": {
                "market_market_ioc": {
                    "base_size": size
                }
            }
        }
        
        logger.info(f"Placing market order: {order_data}")
        return self._make_request('POST', '/api/v3/brokerage/orders', order_data)
    
    def execute_hedge_order(self, size_eth: float) -> dict:
        """
        Execute the hedge order for ETH
        
        Args:
            size_eth: Amount of ETH to short
        """
        logger.info(f"🎯 Executing hedge: SHORT {size_eth} ETH")
        
        # For now, we'll use spot ETH since futures might not be available
        # This still provides some hedge protection
        result = self.place_market_order(
            product_id="ETH-USD",
            side="SELL",
            size=str(round(size_eth, 4))
        )
        
        if 'error' not in result:
            logger.info(f"✅ Hedge order placed: {result}")
        else:
            logger.error(f"❌ Hedge order failed: {result}")
            
        return result

def test_connection():
    """Test the Coinbase connection"""
    print("🔗 Testing Coinbase Advanced Connection")
    print("=" * 50)
    
    connector = CoinbaseAdvancedConnector()
    
    # Test account access
    accounts = connector.get_accounts()
    
    if 'error' not in accounts:
        print("✅ Connection successful!")
        print(f"Found {len(accounts.get('accounts', []))} accounts")
        
        # Show account balances
        for account in accounts.get('accounts', []):
            currency = account.get('currency')
            balance = account.get('available_balance', {}).get('value', '0')
            if float(balance) > 0:
                print(f"💰 {currency}: {balance}")
    else:
        print(f"❌ Connection failed: {accounts.get('error')}")
    
    return accounts

if __name__ == "__main__":
    test_connection()

