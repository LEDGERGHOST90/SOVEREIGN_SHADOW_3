#!/bin/bash
# FUTURES/PERPETUALS/SPOT HEDGE SYSTEM DEPLOYMENT
# Deploy to permanent Legacy Loop location

echo "🚀 DEPLOYING HEDGE SYSTEM TO PERMANENT LOCATION"
echo "================================================"

# Set permanent location
PERMANENT_LOCATION="/Volumes/Ω_Legacy/fut:purp:spot_Aug19"

# Create permanent directory
echo "📁 Creating permanent directory..."
mkdir -p "$PERMANENT_LOCATION"

# Copy all files
echo "📋 Copying system files..."
cp -r * "$PERMANENT_LOCATION/"

# Set permissions
echo "🔐 Setting permissions..."
chmod +x "$PERMANENT_LOCATION"/*.py
chmod +x "$PERMANENT_LOCATION"/DEPLOY.sh

# Create quick access scripts
echo "⚡ Creating quick access scripts..."

# Quick hedge execution script
cat > "$PERMANENT_LOCATION/EXECUTE_HEDGE.sh" << 'EOF'
#!/bin/bash
echo "🎯 EXECUTING HEDGE WITH OVERSEER APPROVAL"
echo "========================================"
cd "$(dirname "$0")"
python3 overseer_approval_system.py propose_hedge
EOF

# Quick monitoring script
cat > "$PERMANENT_LOCATION/START_MONITORING.sh" << 'EOF'
#!/bin/bash
echo "👁️ STARTING 24/7 HEDGE MONITORING"
echo "================================="
cd "$(dirname "$0")"
python3 hedge_monitoring_system.py
EOF

# Make scripts executable
chmod +x "$PERMANENT_LOCATION/EXECUTE_HEDGE.sh"
chmod +x "$PERMANENT_LOCATION/START_MONITORING.sh"

echo "✅ DEPLOYMENT COMPLETE!"
echo ""
echo "📍 Location: $PERMANENT_LOCATION"
echo ""
echo "🚀 QUICK START:"
echo "   cd '$PERMANENT_LOCATION'"
echo "   ./EXECUTE_HEDGE.sh"
echo ""
echo "👁️ MONITORING:"
echo "   ./START_MONITORING.sh"
echo ""
echo "🎯 Your 1.2381 ETH hedge is ready for execution!"

