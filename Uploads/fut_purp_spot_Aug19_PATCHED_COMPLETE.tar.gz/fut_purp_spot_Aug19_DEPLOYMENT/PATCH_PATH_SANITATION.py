#!/usr/bin/env python3
"""
PATCH SCRIPT - PATH SANITATION
==============================
Fixes all hard-coded /home/ubuntu/ paths to use config_paths
"""

import os
import re
from pathlib import Path

def patch_file_paths(file_path):
    """Patch a single file to use config_paths instead of hard-coded paths"""
    
    if not os.path.exists(file_path):
        print(f"⚠️ File not found: {file_path}")
        return False
    
    with open(file_path, 'r') as f:
        content = f.read()
    
    original_content = content
    
    # Add config_paths import if not present
    if 'from config_paths import' not in content and 'import config_paths' not in content:
        # Find first import or add at top
        import_pattern = r'^(import .*?\n|from .*?\n)'
        match = re.search(import_pattern, content, re.MULTILINE)
        if match:
            insertion_point = match.end()
            content = content[:insertion_point] + "from config_paths import *\n" + content[insertion_point:]
        else:
            content = "from config_paths import *\n" + content
    
    # Replace hard-coded paths
    path_replacements = {
        '"/home/ubuntu/trading_authorization.json"': 'str(TRADING_AUTHORIZATION)',
        "'/home/ubuntu/trading_authorization.json'": 'str(TRADING_AUTHORIZATION)',
        '"/home/ubuntu/monitoring_status.json"': 'str(MONITORING_STATUS)',
        "'/home/ubuntu/monitoring_status.json'": 'str(MONITORING_STATUS)',
        '"/home/ubuntu/hedge_execution_log.json"': 'str(HEDGE_EXECUTION_LOG)',
        "'/home/ubuntu/hedge_execution_log.json'": 'str(HEDGE_EXECUTION_LOG)',
        '"/home/ubuntu/hedge_execution_final.json"': 'str(HEDGE_EXECUTION_FINAL)',
        "'/home/ubuntu/hedge_execution_final.json'": 'str(HEDGE_EXECUTION_FINAL)',
        '"/home/ubuntu/risk_metrics.json"': 'str(RISK_METRICS)',
        "'/home/ubuntu/risk_metrics.json'": 'str(RISK_METRICS)',
        '"/home/ubuntu/stop_loss_alert.json"': 'str(STOP_LOSS_ALERT)',
        "'/home/ubuntu/stop_loss_alert.json'": 'str(STOP_LOSS_ALERT)',
        '"/home/ubuntu/rebalancing_alert.json"': 'str(REBALANCING_ALERT)',
        "'/home/ubuntu/rebalancing_alert.json'": 'str(REBALANCING_ALERT)',
        '"/home/ubuntu/high_risk_alert.json"': 'str(HIGH_RISK_ALERT)',
        "'/home/ubuntu/high_risk_alert.json'": 'str(HIGH_RISK_ALERT)',
        '"/home/ubuntu/hedge_success_log.json"': 'str(HEDGE_SUCCESS_LOG)',
        "'/home/ubuntu/hedge_success_log.json'": 'str(HEDGE_SUCCESS_LOG)',
        '"/home/ubuntu/shadow_hedge_log.json"': 'str(SHADOW_HEDGE_LOG)',
        "'/home/ubuntu/shadow_hedge_log.json'": 'str(SHADOW_HEDGE_LOG)',
    }
    
    for old_path, new_path in path_replacements.items():
        if old_path in content:
            content = content.replace(old_path, new_path)
            print(f"   📝 Replaced {old_path} -> {new_path}")
    
    # Write back if changed
    if content != original_content:
        with open(file_path, 'w') as f:
            f.write(content)
        print(f"✅ Patched {file_path}")
        return True
    else:
        print(f"ℹ️ No changes needed for {file_path}")
        return False

def apply_path_sanitation():
    """Apply path sanitation to all relevant files"""
    
    files_to_patch = [
        "automated_hedge_system.py",
        "hedge_monitoring_system.py",
        "execute_hedge_now.py",
        "execute_hedge_final.py",
        "overseer_approval_system.py",
        "ledger_vault_connector.py"
    ]
    
    print("🔧 APPLYING PATH SANITATION PATCHES")
    print("=" * 50)
    
    patched_count = 0
    
    for file_path in files_to_patch:
        print(f"🔍 Checking {file_path}...")
        if patch_file_paths(file_path):
            patched_count += 1
    
    print()
    print(f"✅ Path sanitation complete: {patched_count} files patched")

if __name__ == "__main__":
    apply_path_sanitation()

