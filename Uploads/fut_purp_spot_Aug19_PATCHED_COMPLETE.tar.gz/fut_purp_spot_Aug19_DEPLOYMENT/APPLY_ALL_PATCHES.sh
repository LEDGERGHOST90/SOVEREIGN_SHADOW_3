#!/bin/bash
# APPLY ALL PATCHES - MASTER SCRIPT
# Applies all surgical patches to fix the identified issues

echo "🔧 APPLYING ALL OLYMPUS ELITE PATCHES"
echo "====================================="

# Set DRY_RUN mode
export DRY_RUN=1

# Apply patches in order
echo "1️⃣ Applying Ledger Vault Connector patch..."
python3 PATCH_LEDGER_VAULT.py

echo ""
echo "2️⃣ Applying Path Sanitation patches..."
python3 PATCH_PATH_SANITATION.py

echo ""
echo "3️⃣ Creating directory structure..."
python3 -c "import config_paths; print('📁 Directories created')"

echo ""
echo "4️⃣ Running smoke test..."
python3 scripts/smoke_test.py

echo ""
echo "5️⃣ Testing EXECUTE_HEDGE.sh..."
if [ -x "EXECUTE_HEDGE.sh" ]; then
    echo "🚀 Running EXECUTE_HEDGE.sh in DRY_RUN mode..."
    ./EXECUTE_HEDGE.sh
else
    echo "⚠️ EXECUTE_HEDGE.sh not found or not executable"
fi

echo ""
echo "✅ ALL PATCHES APPLIED!"
echo "📊 Check state/ directory for results"
echo "🎯 System ready for DRY_RUN testing"

