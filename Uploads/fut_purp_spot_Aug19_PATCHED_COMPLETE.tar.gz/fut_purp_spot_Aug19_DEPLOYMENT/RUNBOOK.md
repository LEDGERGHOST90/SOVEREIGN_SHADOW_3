# OLYMPUS ELITE RUNBOOK - EXACT COMMANDS
## Surgical Patches Applied - Ready for DRY_RUN

### DEPLOYMENT COMMANDS

```bash
# 1. Navigate to permanent location
cd "/Volumes/Ω_Legacy/fut:purp:spot_Aug19"

# 2. Activate virtual environment
source /Volumes/Ω_Legacy/global_venv/bin/activate

# 3. Apply all patches
./APPLY_ALL_PATCHES.sh

# 4. Run smoke test
python3 scripts/smoke_test.py

# 5. Execute hedge system (DRY_RUN)
./EXECUTE_HEDGE.sh
```

### VERIFICATION COMMANDS

```bash
# Check DRY_RUN status
echo "DRY_RUN=$DRY_RUN"

# Check Python environment
which python3
python3 --version

# Check file structure
ls -la state/
ls -la logs/
ls -la data/

# Check state files
cat state/smoke_test.json
cat state/hedge_execution_final.json
cat state/monitoring_status.json
```

### ACCEPTANCE CRITERIA

All these should run without exceptions:

```bash
python3 device_manager.py                 # ✅ No exceptions
python3 ledger_vault_connector.py         # ✅ No AttributeError
python3 execute_hedge_now.py              # ✅ Creates state files locally
python3 hedge_monitoring_system.py        # ✅ Creates monitoring_status.json
./EXECUTE_HEDGE.sh                        # ✅ Runs full stack in DRY_RUN
python3 scripts/smoke_test.py             # ✅ Exit code 0
```

### PATCHES APPLIED

1. **config_paths.py** - Path sanitation module
2. **PATCH_LEDGER_VAULT.py** - Adds missing execute_emergency_hedge method
3. **PATCH_PATH_SANITATION.py** - Fixes all /home/ubuntu/ hard-coded paths
4. **scripts/smoke_test.py** - Comprehensive test harness
5. **.env.sample** - Environment variable documentation
6. **requirements.txt** - Python dependencies

### EXPECTED OUTPUT

After running `./APPLY_ALL_PATCHES.sh`:

```
🔧 APPLYING ALL OLYMPUS ELITE PATCHES
=====================================
1️⃣ Applying Ledger Vault Connector patch...
✅ Applied execute_emergency_hedge patch to ledger_vault_connector.py

2️⃣ Applying Path Sanitation patches...
✅ Patched automated_hedge_system.py
✅ Patched hedge_monitoring_system.py
✅ Patched execute_hedge_now.py

3️⃣ Creating directory structure...
📁 Directories created

4️⃣ Running smoke test...
🎉 SMOKE TEST PASSED - SYSTEM READY!

5️⃣ Testing EXECUTE_HEDGE.sh...
🚀 Running EXECUTE_HEDGE.sh in DRY_RUN mode...
[EXECUTE_HEDGE] done (DRY_RUN=1)

✅ ALL PATCHES APPLIED!
📊 Check state/ directory for results
🎯 System ready for DRY_RUN testing
```

### GO/NO-GO DECISION

**GO Criteria:**
- ✅ All patches applied successfully
- ✅ Smoke test passes (exit code 0)
- ✅ EXECUTE_HEDGE.sh runs without exceptions
- ✅ State files created in project directory
- ✅ No hard-coded /home/ubuntu/ paths remain

**NO-GO Criteria:**
- ❌ Any unhandled exceptions
- ❌ Missing state files
- ❌ Smoke test failures
- ❌ Path resolution errors

### NEXT STEPS AFTER GO

1. Set `DRY_RUN=0` in EXECUTE_HEDGE.sh
2. Add real API credentials to .env
3. Execute live hedge with overseer approval
4. Monitor with 24/7 system

