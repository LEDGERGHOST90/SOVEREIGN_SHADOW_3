#!/usr/bin/env python3
"""
CONFIG PATHS - Path Sanitation Module
====================================
Resolves all file paths relative to project root
No more hard-coded /home/ubuntu/ paths
"""

import os
from pathlib import Path

# Project root detection
PROJECT_ROOT = Path(__file__).resolve().parent

# Core directories
DATA_DIR = Path(os.environ.get('LLF_DATA_DIR', PROJECT_ROOT / "data"))
STATE_DIR = Path(os.environ.get('LLF_STATE_DIR', PROJECT_ROOT / "state"))
LOG_DIR = Path(os.environ.get('LLF_LOG_DIR', PROJECT_ROOT / "logs"))

# Ensure directories exist
for directory in [DATA_DIR, STATE_DIR, LOG_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# Common file paths
TRADING_AUTHORIZATION = STATE_DIR / "trading_authorization.json"
MONITORING_STATUS = STATE_DIR / "monitoring_status.json"
HEDGE_EXECUTION_LOG = STATE_DIR / "hedge_execution_log.json"
HEDGE_EXECUTION_FINAL = STATE_DIR / "hedge_execution_final.json"
RISK_METRICS = STATE_DIR / "risk_metrics.json"
STOP_LOSS_ALERT = STATE_DIR / "stop_loss_alert.json"
REBALANCING_ALERT = STATE_DIR / "rebalancing_alert.json"
HIGH_RISK_ALERT = STATE_DIR / "high_risk_alert.json"
HEDGE_SUCCESS_LOG = STATE_DIR / "hedge_success_log.json"
SHADOW_HEDGE_LOG = LOG_DIR / "shadow_hedge_log.json"

# Environment detection
DRY_RUN = os.environ.get("DRY_RUN", "1") == "1"

def get_project_path(relative_path: str) -> Path:
    """Get absolute path relative to project root"""
    return PROJECT_ROOT / relative_path

def get_state_path(filename: str) -> Path:
    """Get path in state directory"""
    return STATE_DIR / filename

def get_log_path(filename: str) -> Path:
    """Get path in logs directory"""
    return LOG_DIR / filename

def get_data_path(filename: str) -> Path:
    """Get path in data directory"""
    return DATA_DIR / filename

# Initialize default state files
def initialize_default_states():
    """Initialize default state files if missing"""
    
    # Default monitoring status
    if not MONITORING_STATUS.exists():
        default_monitoring = {
            "timestamp": "1970-01-01T00:00:00",
            "monitoring_active": False,
            "positions_count": 0,
            "portfolio_snapshots": 0,
            "last_check": "1970-01-01T00:00:00"
        }
        
        import json
        with open(MONITORING_STATUS, 'w') as f:
            json.dump(default_monitoring, f, indent=2)
    
    # Default hedge execution log
    if not HEDGE_EXECUTION_LOG.exists():
        default_hedge_log = {
            "timestamp": "1970-01-01T00:00:00",
            "action": "NONE",
            "symbol": "ETH-PERP",
            "size": 0.0,
            "value": 0.0,
            "purpose": "INITIALIZATION",
            "platform": "NONE",
            "status": "INITIALIZED"
        }
        
        import json
        with open(HEDGE_EXECUTION_LOG, 'w') as f:
            json.dump(default_hedge_log, f, indent=2)

# Auto-initialize on import
initialize_default_states()

print(f"📁 Config Paths Initialized:")
print(f"   PROJECT_ROOT: {PROJECT_ROOT}")
print(f"   STATE_DIR: {STATE_DIR}")
print(f"   LOG_DIR: {LOG_DIR}")
print(f"   DATA_DIR: {DATA_DIR}")
print(f"   DRY_RUN: {DRY_RUN}")

