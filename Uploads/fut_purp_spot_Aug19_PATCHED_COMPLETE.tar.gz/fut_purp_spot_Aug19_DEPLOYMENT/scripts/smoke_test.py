#!/usr/bin/env python3
"""
SMOKE TEST HARNESS
==================
Tests all modules with DRY_RUN=1
Validates system integrity without live trading
"""

import os
import sys
import json
import traceback
from datetime import datetime
from pathlib import Path

# Ensure DRY_RUN mode
os.environ['DRY_RUN'] = '1'

# Add project root to path
project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_root))

from config_paths import STATE_DIR, get_state_path

def smoke_test():
    """Run comprehensive smoke test"""
    
    results = {
        "timestamp": datetime.now().isoformat(),
        "test_mode": "DRY_RUN",
        "project_root": str(project_root),
        "python_version": sys.version,
        "tests": {},
        "overall_status": "UNKNOWN"
    }
    
    print("🧪 OLYMPUS ELITE SMOKE TEST")
    print("=" * 50)
    print(f"📁 Project Root: {project_root}")
    print(f"🐍 Python: {sys.version}")
    print(f"🏃 Mode: DRY_RUN")
    print()
    
    # Test 1: Config Paths
    try:
        print("1️⃣ Testing config_paths...")
        import config_paths
        assert config_paths.DRY_RUN == True
        assert config_paths.STATE_DIR.exists()
        results["tests"]["config_paths"] = {"status": "PASS", "message": "Path resolution working"}
        print("   ✅ Config paths initialized")
    except Exception as e:
        results["tests"]["config_paths"] = {"status": "FAIL", "error": str(e)}
        print(f"   ❌ Config paths failed: {e}")
    
    # Test 2: Device Manager
    try:
        print("2️⃣ Testing device_manager...")
        import device_manager
        # Just import test - don't run full detection
        results["tests"]["device_manager"] = {"status": "PASS", "message": "Module imports successfully"}
        print("   ✅ Device manager imports")
    except Exception as e:
        results["tests"]["device_manager"] = {"status": "FAIL", "error": str(e)}
        print(f"   ❌ Device manager failed: {e}")
    
    # Test 3: Ledger Vault Connector
    try:
        print("3️⃣ Testing ledger_vault_connector...")
        import ledger_vault_connector
        # Test class instantiation
        config = {"test_mode": True}
        connector = ledger_vault_connector.LedgerVaultConnector(config)
        results["tests"]["ledger_vault_connector"] = {"status": "PASS", "message": "Connector instantiated"}
        print("   ✅ Ledger vault connector ready")
    except Exception as e:
        results["tests"]["ledger_vault_connector"] = {"status": "FAIL", "error": str(e)}
        print(f"   ❌ Ledger vault connector failed: {e}")
    
    # Test 4: Overseer Approval System
    try:
        print("4️⃣ Testing overseer_approval_system...")
        import overseer_approval_system
        system = overseer_approval_system.OverseerApprovalSystem()
        results["tests"]["overseer_approval_system"] = {"status": "PASS", "message": "Approval system ready"}
        print("   ✅ Overseer approval system initialized")
    except Exception as e:
        results["tests"]["overseer_approval_system"] = {"status": "FAIL", "error": str(e)}
        print(f"   ❌ Overseer approval system failed: {e}")
    
    # Test 5: Hedge Monitoring System
    try:
        print("5️⃣ Testing hedge_monitoring_system...")
        import hedge_monitoring_system
        config = {"max_loss_pct": 0.10, "rebalance_threshold": 0.15, "stop_loss_pct": 0.05}
        monitor = hedge_monitoring_system.HedgeMonitoringSystem(config)
        results["tests"]["hedge_monitoring_system"] = {"status": "PASS", "message": "Monitoring system ready"}
        print("   ✅ Hedge monitoring system initialized")
    except Exception as e:
        results["tests"]["hedge_monitoring_system"] = {"status": "FAIL", "error": str(e)}
        print(f"   ❌ Hedge monitoring system failed: {e}")
    
    # Test 6: Coinbase Connectors
    try:
        print("6️⃣ Testing coinbase connectors...")
        import coinbase_futures_connector
        connector = coinbase_futures_connector.CoinbaseFuturesConnector()
        results["tests"]["coinbase_connectors"] = {"status": "PASS", "message": "Connectors import successfully"}
        print("   ✅ Coinbase connectors ready")
    except Exception as e:
        results["tests"]["coinbase_connectors"] = {"status": "FAIL", "error": str(e)}
        print(f"   ❌ Coinbase connectors failed: {e}")
    
    # Test 7: Execute Hedge Scripts
    try:
        print("7️⃣ Testing execute_hedge_final...")
        import execute_hedge_final
        results["tests"]["execute_hedge_scripts"] = {"status": "PASS", "message": "Execution scripts import"}
        print("   ✅ Hedge execution scripts ready")
    except Exception as e:
        results["tests"]["execute_hedge_scripts"] = {"status": "FAIL", "error": str(e)}
        print(f"   ❌ Hedge execution scripts failed: {e}")
    
    # Calculate overall status
    passed_tests = sum(1 for test in results["tests"].values() if test["status"] == "PASS")
    total_tests = len(results["tests"])
    
    if passed_tests == total_tests:
        results["overall_status"] = "ALL_PASS"
        exit_code = 0
    elif passed_tests > total_tests // 2:
        results["overall_status"] = "MOSTLY_PASS"
        exit_code = 0
    else:
        results["overall_status"] = "FAIL"
        exit_code = 1
    
    # Save results
    smoke_test_file = get_state_path("smoke_test.json")
    with open(smoke_test_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    print()
    print("📊 SMOKE TEST RESULTS:")
    print(f"   ✅ Passed: {passed_tests}/{total_tests}")
    print(f"   📁 Results: {smoke_test_file}")
    print(f"   🎯 Status: {results['overall_status']}")
    print()
    
    if exit_code == 0:
        print("🎉 SMOKE TEST PASSED - SYSTEM READY!")
    else:
        print("⚠️ SMOKE TEST ISSUES - CHECK LOGS")
    
    return exit_code

if __name__ == "__main__":
    try:
        exit_code = smoke_test()
        sys.exit(exit_code)
    except Exception as e:
        print(f"💥 SMOKE TEST CRASHED: {e}")
        traceback.print_exc()
        sys.exit(1)

