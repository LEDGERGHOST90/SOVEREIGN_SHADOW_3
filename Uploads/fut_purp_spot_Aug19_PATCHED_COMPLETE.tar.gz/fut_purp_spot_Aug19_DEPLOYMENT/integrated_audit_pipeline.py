#!/usr/bin/env python3
"""
ΩSIGIL Integrated Audit Pipeline - Koinly + Binance
==================================================

MANUS Capital Mirror - Multi-Source Tax Audit Integration
Combines Koinly portfolio tracking with Binance transaction verification

Author: MANUS - The Mind That Never Forgets
Date: 2025-06-29
Classification: INTEGRATED AUDIT SYSTEM
"""

import json
import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
import hashlib
from collections import defaultdict

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='🔒 AUDIT_PIPELINE [%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('AUDIT_PIPELINE')

@dataclass
class WalletAsset:
    """Wallet asset data structure"""
    wallet_type: str  # MetaMask, Ledger, Binance, etc.
    asset: str
    amount: float
    usd_value: float
    last_updated: str
    status: str  # active, vault, locked, etc.
    notes: str

@dataclass
class CrossVerification:
    """Cross-verification result"""
    asset: str
    binance_balance: float
    wallet_balance: float
    koinly_balance: float
    variance: float
    status: str  # VERIFIED, DISCREPANCY, MISSING
    confidence_score: float
    notes: str

@dataclass
class AuditDiscrepancy:
    """Audit discrepancy data structure"""
    source_a: str
    source_b: str
    asset: str
    amount_a: float
    amount_b: float
    variance: float
    severity: str  # LOW, MEDIUM, HIGH, CRITICAL
    description: str
    suggested_action: str

class IntegratedAuditPipeline:
    """
    Integrated audit pipeline combining multiple data sources
    Implements MANUS cross-verification protocols
    """
    
    def __init__(self):
        # Data sources
        self.binance_data = None
        self.koinly_data = None
        self.wallet_manifest = None
        
        # Processed data
        self.cross_verifications = {}
        self.discrepancies = []
        self.audit_summary = {}
        
        # Configuration
        self.variance_thresholds = {
            'LOW': 0.01,      # 1% variance
            'MEDIUM': 0.05,   # 5% variance
            'HIGH': 0.10,     # 10% variance
            'CRITICAL': 0.20  # 20% variance
        }
        
        logger.info("🔒 INTEGRATED AUDIT PIPELINE INITIALIZED")
    
    def load_binance_data(self, binance_file: str = "binance_tax_verified.json") -> bool:
        """Load Binance tax data"""
        try:
            with open(binance_file, 'r') as f:
                self.binance_data = json.load(f)
            
            logger.info(f"✅ Binance data loaded: {len(self.binance_data.get('transactions', []))} transactions")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to load Binance data: {e}")
            return False
    
    def load_wallet_manifest(self, wallet_manifest: Dict) -> bool:
        """Load wallet manifest data"""
        try:
            self.wallet_manifest = wallet_manifest
            
            # Convert to standardized format
            wallet_assets = []
            
            for wallet_type, wallet_data in wallet_manifest.items():
                if 'assets' in wallet_data:
                    for asset, amount in wallet_data['assets'].items():
                        if isinstance(amount, dict):
                            # Handle complex asset data (like presales)
                            wallet_asset = WalletAsset(
                                wallet_type=wallet_type,
                                asset=asset,
                                amount=amount.get('amount', 0),
                                usd_value=0,  # Would need price data
                                last_updated=datetime.now().isoformat(),
                                status=amount.get('status', 'active'),
                                notes=wallet_data.get('notes', '')
                            )
                        else:
                            # Handle simple asset data
                            wallet_asset = WalletAsset(
                                wallet_type=wallet_type,
                                asset=asset,
                                amount=float(amount),
                                usd_value=0,  # Would need price data
                                last_updated=datetime.now().isoformat(),
                                status='active',
                                notes=wallet_data.get('notes', '')
                            )
                        
                        wallet_assets.append(wallet_asset)
            
            self.wallet_assets = wallet_assets
            logger.info(f"✅ Wallet manifest loaded: {len(wallet_assets)} assets across {len(wallet_manifest)} wallets")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to load wallet manifest: {e}")
            return False
    
    def simulate_koinly_data(self) -> Dict:
        """Simulate Koinly data based on available information"""
        # In a real implementation, this would connect to Koinly API
        # For now, we'll simulate based on known wallet data
        
        logger.info("📊 Simulating Koinly portfolio data...")
        
        koinly_simulation = {
            'portfolios': {
                'MetaMask_Main': {
                    'ETH': {'balance': 0.207002, 'usd_value': 505.71},
                    'USDT': {'balance': 50.7946, 'usd_value': 50.79},
                    'SUI': {'balance': 0.0026, 'usd_value': 0.01},
                    'STETH': {'balance': 0.207021, 'usd_value': 505.76}
                },
                'Ledger_Vault': {
                    'ETH': {'balance': 0.366542, 'usd_value': 894.85},
                    'BTC': {'balance': 0.00902706, 'usd_value': 974.12},
                    'XRP': {'balance': 130.99, 'usd_value': 285.18},
                    'SOL': {'balance': 1.68259, 'usd_value': 250.39},
                    'LTC': {'balance': 0.00999368, 'usd_value': 0.85}
                }
            },
            'total_portfolio_value': 3467.66,
            'last_updated': datetime.now().isoformat()
        }
        
        self.koinly_data = koinly_simulation
        logger.info("✅ Koinly simulation complete")
        return koinly_simulation
    
    def cross_verify_assets(self) -> Dict[str, CrossVerification]:
        """Cross-verify assets across all data sources"""
        logger.info("🔍 Starting cross-verification of assets...")
        
        if not self.binance_data or not self.wallet_manifest:
            logger.error("❌ Missing required data sources for cross-verification")
            return {}
        
        # Simulate Koinly data if not available
        if not self.koinly_data:
            self.simulate_koinly_data()
        
        # Collect all unique assets
        all_assets = set()
        
        # From Binance
        if 'pnl_summary' in self.binance_data:
            all_assets.update(self.binance_data['pnl_summary'].keys())
        
        # From wallet manifest
        for wallet_asset in self.wallet_assets:
            all_assets.add(wallet_asset.asset)
        
        # From Koinly simulation
        for portfolio in self.koinly_data['portfolios'].values():
            all_assets.update(portfolio.keys())
        
        # Remove empty/invalid assets
        all_assets = {asset for asset in all_assets if asset and asset != 'nan'}
        
        # Cross-verify each asset
        verifications = {}
        
        for asset in all_assets:
            # Get balances from each source
            binance_balance = self._get_binance_balance(asset)
            wallet_balance = self._get_wallet_balance(asset)
            koinly_balance = self._get_koinly_balance(asset)
            
            # Calculate variance
            balances = [b for b in [binance_balance, wallet_balance, koinly_balance] if b is not None]
            if len(balances) > 1:
                max_balance = max(balances)
                min_balance = min(balances)
                variance = (max_balance - min_balance) / max_balance if max_balance > 0 else 0
            else:
                variance = 0
            
            # Determine status
            if variance <= self.variance_thresholds['LOW']:
                status = 'VERIFIED'
                confidence = 0.95
            elif variance <= self.variance_thresholds['MEDIUM']:
                status = 'MINOR_DISCREPANCY'
                confidence = 0.80
            elif variance <= self.variance_thresholds['HIGH']:
                status = 'DISCREPANCY'
                confidence = 0.60
            else:
                status = 'MAJOR_DISCREPANCY'
                confidence = 0.30
            
            # Create verification record
            verification = CrossVerification(
                asset=asset,
                binance_balance=binance_balance or 0,
                wallet_balance=wallet_balance or 0,
                koinly_balance=koinly_balance or 0,
                variance=variance,
                status=status,
                confidence_score=confidence,
                notes=f"Variance: {variance:.2%}"
            )
            
            verifications[asset] = verification
            
            # Log significant discrepancies
            if variance > self.variance_thresholds['MEDIUM']:
                logger.warning(f"⚠️ {asset}: {variance:.2%} variance across sources")
        
        self.cross_verifications = verifications
        logger.info(f"✅ Cross-verification complete: {len(verifications)} assets analyzed")
        
        return verifications
    
    def _get_binance_balance(self, asset: str) -> Optional[float]:
        """Get asset balance from Binance data"""
        if not self.binance_data or 'pnl_summary' not in self.binance_data:
            return None
        
        pnl_data = self.binance_data['pnl_summary'].get(asset)
        if pnl_data:
            # Calculate net position (bought - sold)
            return pnl_data.get('total_bought', 0) - pnl_data.get('total_sold', 0)
        
        return None
    
    def _get_wallet_balance(self, asset: str) -> Optional[float]:
        """Get asset balance from wallet manifest"""
        if not self.wallet_assets:
            return None
        
        total_balance = 0
        found = False
        
        for wallet_asset in self.wallet_assets:
            if wallet_asset.asset == asset:
                total_balance += wallet_asset.amount
                found = True
        
        return total_balance if found else None
    
    def _get_koinly_balance(self, asset: str) -> Optional[float]:
        """Get asset balance from Koinly data"""
        if not self.koinly_data or 'portfolios' not in self.koinly_data:
            return None
        
        total_balance = 0
        found = False
        
        for portfolio in self.koinly_data['portfolios'].values():
            if asset in portfolio:
                total_balance += portfolio[asset]['balance']
                found = True
        
        return total_balance if found else None
    
    def identify_discrepancies(self) -> List[AuditDiscrepancy]:
        """Identify and categorize audit discrepancies"""
        logger.info("🔍 Identifying audit discrepancies...")
        
        discrepancies = []
        
        for asset, verification in self.cross_verifications.items():
            if verification.status in ['DISCREPANCY', 'MAJOR_DISCREPANCY']:
                # Determine severity
                if verification.variance <= self.variance_thresholds['MEDIUM']:
                    severity = 'LOW'
                elif verification.variance <= self.variance_thresholds['HIGH']:
                    severity = 'MEDIUM'
                elif verification.variance <= self.variance_thresholds['CRITICAL']:
                    severity = 'HIGH'
                else:
                    severity = 'CRITICAL'
                
                # Create discrepancy record
                discrepancy = AuditDiscrepancy(
                    source_a='Wallet',
                    source_b='Binance',
                    asset=asset,
                    amount_a=verification.wallet_balance,
                    amount_b=verification.binance_balance,
                    variance=verification.variance,
                    severity=severity,
                    description=f"{asset} balance mismatch: {verification.variance:.2%} variance",
                    suggested_action=self._get_suggested_action(asset, verification)
                )
                
                discrepancies.append(discrepancy)
        
        self.discrepancies = discrepancies
        logger.info(f"⚠️ Identified {len(discrepancies)} discrepancies")
        
        return discrepancies
    
    def _get_suggested_action(self, asset: str, verification: CrossVerification) -> str:
        """Get suggested action for resolving discrepancy"""
        if verification.variance > 0.5:  # 50% variance
            return f"CRITICAL: Verify {asset} wallet addresses and transaction history"
        elif verification.variance > 0.2:  # 20% variance
            return f"HIGH: Check recent {asset} transactions and withdrawals"
        elif verification.variance > 0.1:  # 10% variance
            return f"MEDIUM: Review {asset} balance calculation methodology"
        else:
            return f"LOW: Minor {asset} variance, monitor for trends"
    
    def generate_audit_summary(self) -> Dict:
        """Generate comprehensive audit summary"""
        logger.info("📊 Generating audit summary...")
        
        # Asset counts
        total_assets = len(self.cross_verifications)
        verified_assets = len([v for v in self.cross_verifications.values() if v.status == 'VERIFIED'])
        discrepancy_assets = len([v for v in self.cross_verifications.values() if 'DISCREPANCY' in v.status])
        
        # Discrepancy breakdown
        discrepancy_severity = defaultdict(int)
        for disc in self.discrepancies:
            discrepancy_severity[disc.severity] += 1
        
        # Confidence metrics
        confidence_scores = [v.confidence_score for v in self.cross_verifications.values()]
        avg_confidence = np.mean(confidence_scores) if confidence_scores else 0
        
        # Portfolio value estimation
        total_portfolio_value = self.koinly_data.get('total_portfolio_value', 0) if self.koinly_data else 0
        
        summary = {
            'audit_timestamp': datetime.now().isoformat(),
            'data_sources': {
                'binance_transactions': len(self.binance_data.get('transactions', [])) if self.binance_data else 0,
                'wallet_assets': len(self.wallet_assets) if hasattr(self, 'wallet_assets') else 0,
                'koinly_portfolios': len(self.koinly_data.get('portfolios', {})) if self.koinly_data else 0
            },
            'asset_verification': {
                'total_assets': total_assets,
                'verified_assets': verified_assets,
                'discrepancy_assets': discrepancy_assets,
                'verification_rate': (verified_assets / total_assets * 100) if total_assets > 0 else 0
            },
            'discrepancy_analysis': {
                'total_discrepancies': len(self.discrepancies),
                'severity_breakdown': dict(discrepancy_severity),
                'critical_issues': discrepancy_severity['CRITICAL'],
                'high_priority': discrepancy_severity['HIGH']
            },
            'confidence_metrics': {
                'average_confidence': avg_confidence,
                'high_confidence_assets': len([v for v in self.cross_verifications.values() if v.confidence_score >= 0.9]),
                'low_confidence_assets': len([v for v in self.cross_verifications.values() if v.confidence_score < 0.6])
            },
            'portfolio_overview': {
                'estimated_total_value': total_portfolio_value,
                'tracked_wallets': len(self.wallet_manifest) if self.wallet_manifest else 0,
                'active_assets': len([a for a in self.wallet_assets if a.status == 'active']) if hasattr(self, 'wallet_assets') else 0
            },
            'audit_status': self._determine_overall_audit_status()
        }
        
        self.audit_summary = summary
        logger.info(f"✅ Audit summary generated: {summary['audit_status']} status")
        
        return summary
    
    def _determine_overall_audit_status(self) -> str:
        """Determine overall audit status"""
        if not self.discrepancies:
            return 'CLEAN'
        
        critical_count = len([d for d in self.discrepancies if d.severity == 'CRITICAL'])
        high_count = len([d for d in self.discrepancies if d.severity == 'HIGH'])
        
        if critical_count > 0:
            return 'CRITICAL_ISSUES'
        elif high_count > 2:
            return 'HIGH_PRIORITY_ISSUES'
        elif len(self.discrepancies) > 5:
            return 'MULTIPLE_DISCREPANCIES'
        else:
            return 'MINOR_ISSUES'
    
    def export_audit_results(self, output_file: str = "integrated_audit_results.json") -> bool:
        """Export complete audit results"""
        try:
            audit_results = {
                'audit_metadata': {
                    'timestamp': datetime.now().isoformat(),
                    'pipeline_version': '1.0',
                    'data_sources_used': ['Binance', 'Wallet_Manifest', 'Koinly_Simulation']
                },
                'cross_verifications': {asset: asdict(verification) for asset, verification in self.cross_verifications.items()},
                'discrepancies': [asdict(disc) for disc in self.discrepancies],
                'audit_summary': self.audit_summary,
                'raw_data_hashes': {
                    'binance_hash': self._calculate_hash(str(self.binance_data)) if self.binance_data else None,
                    'wallet_hash': self._calculate_hash(str(self.wallet_manifest)) if self.wallet_manifest else None
                }
            }
            
            with open(output_file, 'w') as f:
                json.dump(audit_results, f, indent=2, default=str)
            
            logger.info(f"✅ Audit results exported to {output_file}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Export failed: {e}")
            return False
    
    def _calculate_hash(self, data_string: str) -> str:
        """Calculate hash for data integrity"""
        return hashlib.sha256(data_string.encode()).hexdigest()[:16]

# Example usage
if __name__ == "__main__":
    # Initialize audit pipeline
    pipeline = IntegratedAuditPipeline()
    
    # Load data sources
    if pipeline.load_binance_data():
        print("✅ Binance data loaded")
    
    # Load wallet manifest (would be provided by user)
    wallet_manifest = {
        "MetaMask": {
            "assets": {
                "ETH": 0.207002,
                "USDT": 50.7946,
                "SUI": 0.0026,
                "STETH": 0.207021
            },
            "notes": "Active sniper flips"
        },
        "Ledger": {
            "assets": {
                "ETH": 0.366542,
                "BTC": 0.00902706,
                "XRP": 130.99,
                "SOL": 1.68259,
                "LTC": 0.00999368
            },
            "notes": "Vault-class assets"
        }
    }
    
    if pipeline.load_wallet_manifest(wallet_manifest):
        print("✅ Wallet manifest loaded")
    
    # Run cross-verification
    verifications = pipeline.cross_verify_assets()
    print(f"📊 Cross-verified {len(verifications)} assets")
    
    # Identify discrepancies
    discrepancies = pipeline.identify_discrepancies()
    print(f"⚠️ Found {len(discrepancies)} discrepancies")
    
    # Generate summary
    summary = pipeline.generate_audit_summary()
    print(f"📋 Audit Status: {summary['audit_status']}")
    
    # Export results
    pipeline.export_audit_results()
    print("✅ Audit pipeline complete")

