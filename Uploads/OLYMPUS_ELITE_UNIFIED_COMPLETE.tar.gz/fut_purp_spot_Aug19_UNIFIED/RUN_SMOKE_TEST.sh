#!/bin/bash
echo "🧪 RUNNING SMOKE TEST"
echo "===================="
python3 OLYMPUS_ELITE_UNIFIED_SYSTEM.py smoke_test
