#!/bin/bash
# OLYMPUS ELITE HEDGE EXECUTION LAUNCHER
export DRY_RUN=1   # set to 0 only after verification

echo "🚀 OLYMPUS ELITE HEDGE SYSTEM"
echo "============================="
echo "Mode: DRY_RUN=$DRY_RUN"
echo "Python: $(which python3)"
echo ""

python3 OLYMPUS_ELITE_UNIFIED_SYSTEM.py execute_hedge

echo ""
echo "[EXECUTE_HEDGE] done (DRY_RUN=$DRY_RUN)"
