// Sovereign Legacy Loop - Persistent Database Manager
// This ensures your data survives restarts and maintains state

const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

class DatabaseManager {
    constructor() {
        // Store database in a persistent location
        this.dbPath = path.join(__dirname, '../../data/sovereign_legacy.db');
        this.schemaPath = path.join(__dirname, 'schema.sql');
        
        // Ensure data directory exists
        const dataDir = path.dirname(this.dbPath);
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
        
        this.db = null;
        this.initialize();
    }

    initialize() {
        try {
            console.log('🔄 Initializing persistent database...');
            
            // Open database connection
            this.db = new Database(this.dbPath);
            
            // Enable WAL mode for better performance
            this.db.pragma('journal_mode = WAL');
            
            // Load and execute schema
            if (fs.existsSync(this.schemaPath)) {
                const schema = fs.readFileSync(this.schemaPath, 'utf8');
                this.db.exec(schema);
                console.log('✅ Database schema loaded successfully');
            }
            
            // Update last startup time
            this.updateSetting('last_startup', new Date().toISOString());
            
            console.log('✅ Persistent database initialized at:', this.dbPath);
            
        } catch (error) {
            console.error('❌ Database initialization failed:', error);
            throw error;
        }
    }

    // System Settings Management
    getSetting(key) {
        try {
            const stmt = this.db.prepare('SELECT value FROM system_settings WHERE key = ?');
            const result = stmt.get(key);
            return result ? result.value : null;
        } catch (error) {
            console.error('Error getting setting:', error);
            return null;
        }
    }

    updateSetting(key, value, description = null) {
        try {
            const stmt = this.db.prepare(`
                INSERT OR REPLACE INTO system_settings (key, value, description, updated_at) 
                VALUES (?, ?, ?, datetime('now'))
            `);
            stmt.run(key, value, description);
            return true;
        } catch (error) {
            console.error('Error updating setting:', error);
            return false;
        }
    }

    // Safety Settings Management
    getSafetySettings() {
        try {
            const stmt = this.db.prepare('SELECT * FROM safety_settings ORDER BY setting_name');
            return stmt.all();
        } catch (error) {
            console.error('Error getting safety settings:', error);
            return [];
        }
    }

    updateSafetySetting(settingName, isEnabled, settingValue = null) {
        try {
            const stmt = this.db.prepare(`
                UPDATE safety_settings 
                SET is_enabled = ?, setting_value = ?, updated_at = datetime('now')
                WHERE setting_name = ?
            `);
            stmt.run(isEnabled, settingValue, settingName);
            console.log(`🛡️ Safety setting updated: ${settingName} = ${isEnabled}`);
            return true;
        } catch (error) {
            console.error('Error updating safety setting:', error);
            return false;
        }
    }

    // Check if live trading is allowed
    isLiveTradingAllowed() {
        try {
            const disableLive = this.getSafetySetting('DISABLE_LIVE_TRADING');
            const simulationMode = this.getSafetySetting('SIMULATION_MODE');
            
            return !disableLive.is_enabled && !simulationMode.is_enabled;
        } catch (error) {
            console.error('Error checking live trading status:', error);
            return false; // Default to safe mode
        }
    }

    getSafetySetting(settingName) {
        try {
            const stmt = this.db.prepare('SELECT * FROM safety_settings WHERE setting_name = ?');
            return stmt.get(settingName);
        } catch (error) {
            console.error('Error getting safety setting:', error);
            return { is_enabled: true }; // Default to safe
        }
    }

    // Portfolio Management
    savePortfolioSnapshot(portfolioData, isLive = false) {
        try {
            const stmt = this.db.prepare(`
                INSERT INTO portfolio_snapshots 
                (total_usd_value, btc_balance, eth_balance, sol_balance, xrp_balance, usdt_balance, snapshot_data, is_live)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `);
            
            const result = stmt.run(
                portfolioData.totalUsdValue || 0,
                portfolioData.btc || 0,
                portfolioData.eth || 0,
                portfolioData.sol || 0,
                portfolioData.xrp || 0,
                portfolioData.usdt || 0,
                JSON.stringify(portfolioData),
                isLive ? 1 : 0
            );
            
            console.log(`💾 Portfolio snapshot saved (${isLive ? 'LIVE' : 'MOCK'} data)`);
            return result.lastInsertRowid;
        } catch (error) {
            console.error('Error saving portfolio snapshot:', error);
            return null;
        }
    }

    getLatestPortfolioSnapshot() {
        try {
            const stmt = this.db.prepare(`
                SELECT * FROM portfolio_snapshots 
                ORDER BY timestamp DESC 
                LIMIT 1
            `);
            return stmt.get();
        } catch (error) {
            console.error('Error getting latest portfolio:', error);
            return null;
        }
    }

    // Trading History
    saveTrade(tradeData) {
        try {
            const stmt = this.db.prepare(`
                INSERT INTO trading_history 
                (symbol, side, quantity, price, total_usd, is_simulated, trade_type, profit_loss, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);
            
            const result = stmt.run(
                tradeData.symbol,
                tradeData.side,
                tradeData.quantity,
                tradeData.price,
                tradeData.totalUsd,
                tradeData.isSimulated ? 1 : 0,
                tradeData.tradeType || 'manual',
                tradeData.profitLoss || 0,
                tradeData.notes || null
            );
            
            console.log(`📊 Trade logged: ${tradeData.side} ${tradeData.quantity} ${tradeData.symbol} ${tradeData.isSimulated ? '(SIMULATED)' : '(LIVE)'}`);
            return result.lastInsertRowid;
        } catch (error) {
            console.error('Error saving trade:', error);
            return null;
        }
    }

    // Siphon Operations
    saveSiphonOperation(siphonData) {
        try {
            const stmt = this.db.prepare(`
                INSERT INTO siphon_operations 
                (passphrase_used, total_profit, core_reinvest_amount, usdt_war_chest_amount, vault_transfer_amount, is_simulated, operation_data, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `);
            
            const result = stmt.run(
                siphonData.passphrase,
                siphonData.totalProfit,
                siphonData.coreReinvest,
                siphonData.usdtWarChest,
                siphonData.vaultTransfer || 0,
                siphonData.isSimulated ? 1 : 0,
                JSON.stringify(siphonData),
                siphonData.status || 'completed'
            );
            
            console.log(`🌊 Siphon operation logged: $${siphonData.totalProfit} ${siphonData.isSimulated ? '(SIMULATED)' : '(LIVE)'}`);
            return result.lastInsertRowid;
        } catch (error) {
            console.error('Error saving siphon operation:', error);
            return null;
        }
    }

    // Database maintenance
    cleanup() {
        try {
            // Clean old portfolio snapshots (keep last 1000)
            this.db.exec(`
                DELETE FROM portfolio_snapshots 
                WHERE id NOT IN (
                    SELECT id FROM portfolio_snapshots 
                    ORDER BY timestamp DESC 
                    LIMIT 1000
                )
            `);
            
            console.log('🧹 Database cleanup completed');
        } catch (error) {
            console.error('Error during cleanup:', error);
        }
    }

    close() {
        if (this.db) {
            this.db.close();
            console.log('📦 Database connection closed');
        }
    }
}

// Export singleton instance
module.exports = new DatabaseManager();
