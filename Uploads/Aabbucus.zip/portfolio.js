import binanceService from '../services/binanceService.js'

// Live portfolio data from Binance US API
export const getPortfolioData = async () => {
  try {
    const corePositions = await binanceService.getCorePositions()
    const portfolioData = {}
    
    // Convert core positions to expected format
    Object.entries(corePositions.corePositions).forEach(([key, position]) => {
      portfolioData[key] = {
        amount: position.usdValue,
        percentage: position.percentage,
        target: position.target,
        price: position.price,
        change_24h: 0 // Will be populated by 24hr stats
      }
    })

    // Add USDT war chest
    portfolioData.usdt = {
      amount: corePositions.usdtBalance,
      percentage: Math.round((corePositions.usdtBalance / corePositions.totalValue) * 100),
      target: 0,
      price: 1.00,
      change_24h: 0.0
    }

    // Get 24hr price changes
    const coreAssets = ['BTC', 'ETH', 'SOL', 'XRP']
    for (const asset of coreAssets) {
      try {
        const stats = await binanceService.get24hrStats(asset)
        const key = asset.toLowerCase()
        if (portfolioData[key]) {
          portfolioData[key].change_24h = stats.priceChangePercent
          portfolioData[key].price = stats.lastPrice
        }
      } catch (error) {
        console.warn(`Failed to get 24hr stats for ${asset}:`, error)
      }
    }

    // Calculate total change
    let totalChange24h = 0
    Object.values(portfolioData).forEach(position => {
      if (position.amount > 0 && position.change_24h !== undefined) {
        totalChange24h += (position.amount * position.change_24h / 100)
      }
    })

    return {
      ...portfolioData,
      total_value: corePositions.totalValue,
      total_change_24h: totalChange24h,
      total_change_percent: (totalChange24h / corePositions.totalValue) * 100,
      last_updated: corePositions.lastUpdated,
      source: 'binance_live'
    }
  } catch (error) {
    console.error('Failed to get live portfolio data:', error)
    // Fallback to mock data
    return getMockPortfolioData()
  }
}

// Mock portfolio data as fallback
const getMockPortfolioData = () => ({
  btc: { 
    amount: 630, 
    percentage: 31, 
    target: 500,
    price: 42500,
    change_24h: 2.3
  },
  eth: { 
    amount: 407, 
    percentage: 20, 
    target: 500,
    price: 2650,
    change_24h: 1.8
  },
  sol: { 
    amount: 393, 
    percentage: 19, 
    target: 500,
    price: 98.50,
    change_24h: 4.2
  },
  xrp: { 
    amount: 392, 
    percentage: 19, 
    target: 500,
    price: 0.52,
    change_24h: -0.8
  },
  usdt: { 
    amount: 232, 
    percentage: 11, 
    target: 0,
    price: 1.00,
    change_24h: 0.0
  },
  total_value: 2054,
  total_change_24h: 26.05,
  total_change_percent: 1.28,
  last_updated: new Date().toISOString(),
  source: 'mock_fallback'
})

export const pnlHistory = [
  { timestamp: "2024-01-15T00:00:00Z", value: 2054, pnl: 26.05, pnl_percent: 1.28 },
  { timestamp: "2024-01-14T00:00:00Z", value: 2028, pnl: -15.20, pnl_percent: -0.74 },
  { timestamp: "2024-01-13T00:00:00Z", value: 2043, pnl: 18.50, pnl_percent: 0.91 },
  { timestamp: "2024-01-12T00:00:00Z", value: 2025, pnl: -8.30, pnl_percent: -0.41 },
  { timestamp: "2024-01-11T00:00:00Z", value: 2033, pnl: 12.75, pnl_percent: 0.63 },
  { timestamp: "2024-01-10T00:00:00Z", value: 2020, pnl: -22.10, pnl_percent: -1.08 },
  { timestamp: "2024-01-09T00:00:00Z", value: 2042, pnl: 35.60, pnl_percent: 1.77 },
  { timestamp: "2024-01-08T00:00:00Z", value: 2007, pnl: -18.90, pnl_percent: -0.93 },
  { timestamp: "2024-01-07T00:00:00Z", value: 2026, pnl: 14.20, pnl_percent: 0.71 },
  { timestamp: "2024-01-06T00:00:00Z", value: 2012, pnl: -5.80, pnl_percent: -0.29 }
]

export const vaultData = {
  total_balance: 15420,
  assets: {
    btc: { amount: 0.15, value: 6375, graduation_date: "2024-01-10T00:00:00Z" },
    eth: { amount: 2.8, value: 7420, graduation_date: "2024-01-08T00:00:00Z" },
    sol: { amount: 16.2, value: 1595, graduation_date: "2024-01-12T00:00:00Z" },
    xrp: { amount: 60, value: 30, graduation_date: "2024-01-05T00:00:00Z" }
  },
  total_graduated: 4,
  next_graduation_candidate: "btc",
  next_graduation_threshold: 1500
}

export const simulateSiphon = async (passphrase, dryRun = true) => {
  try {
    // Use the live Binance service for profit siphon simulation
    return await binanceService.simulateProfitSiphon(passphrase, dryRun)
  } catch (error) {
    console.error('Live siphon simulation failed, using fallback:', error)
    
    // Fallback to mock simulation
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '')
    const expectedPassphrase = `ΩSIGIL-COLLECT-${today}`
    
    if (passphrase !== expectedPassphrase) {
      throw new Error('Invalid passphrase')
    }

    const totalProfit = 156.50
    const coreReinvestment = totalProfit * 0.3
    const usdtAllocation = totalProfit * 0.7

    return {
      success: true,
      simulation_id: `mock_${Date.now()}`,
      dry_run: dryRun,
      actions: [
        { 
          type: 'profit_calculation', 
          amount: totalProfit,
          description: 'Calculated total profit from recent trades (MOCK DATA)'
        },
        { 
          type: 'core_reinvestment', 
          amount: coreReinvestment, 
          percentage: 30,
          description: '30% allocated back to core positions'
        },
        { 
          type: 'usdt_allocation', 
          amount: usdtAllocation, 
          percentage: 70,
          description: '70% allocated to USDT war chest'
        },
        { 
          type: 'rebalancing', 
          trades: [
            { asset: 'btc', action: 'buy', amount: 15.65 },
            { asset: 'eth', action: 'buy', amount: 15.65 },
            { asset: 'sol', action: 'buy', amount: 15.65 }
          ],
          description: 'Rebalancing trades to maintain target allocations'
        }
      ],
      estimated_completion: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
      source: 'mock_fallback'
    }
  }
}

// In-memory waitlist storage (in production, this would be a database)
let waitlistMembers = []

export const addToWaitlist = (email, name, useCase, note, tier) => {
  const member = {
    id: Date.now(),
    email,
    name,
    useCase,
    note,
    tier,
    timestamp: new Date().toISOString(),
    position: waitlistMembers.length + 1
  }
  
  waitlistMembers.push(member)
  
  return {
    success: true,
    message: 'Successfully added to waitlist',
    position: member.position
  }
}
