import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { ThemeProvider } from 'next-themes'
import './App.css'

// Import pages
import Landing from './pages/Landing'
import Demo from './pages/Demo'
import Pricing from './pages/Pricing'
import Vault from './pages/Vault'
import ApiDocs from './pages/ApiDocs'
import Waitlist from './pages/Waitlist'
import ApiSettings from './pages/ApiSettings'

// Import components
import Navigation from './components/Navigation'
import Footer from './components/Footer'
import CosmicBackground from './components/CosmicBackground'

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
      <Router>
        <div className="min-h-screen bg-background text-foreground">
          <Navigation />
          <main>
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/demo" element={<Demo />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/vault" element={<Vault />} />
              <Route path="/docs/api" element={<ApiDocs />} />
              <Route path="/waitlist" element={<Waitlist />} />
              <Route path="/settings" element={<ApiSettings />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </ThemeProvider>
  )
}

export default App
