import { useEffect, useRef } from 'react'
import './CosmicBackground.css'

const CosmicBackground = () => {
  const canvasRef = useRef(null)
  const animationRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    let animationId

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resizeCanvas()
    window.addEventListener('resize', resizeCanvas)

    // Stars array
    const stars = []
    const shootingStars = []
    const nebulaClouds = []

    // Create static stars
    for (let i = 0; i < 200; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.8 + 0.2,
        twinkleSpeed: Math.random() * 0.02 + 0.01
      })
    }

    // Create nebula clouds
    for (let i = 0; i < 8; i++) {
      nebulaClouds.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 300 + 100,
        opacity: Math.random() * 0.1 + 0.05,
        color: `hsl(${Math.random() * 60 + 240}, 70%, 50%)`, // Blue to purple hues
        drift: {
          x: (Math.random() - 0.5) * 0.2,
          y: (Math.random() - 0.5) * 0.2
        }
      })
    }

    // Create shooting star
    const createShootingStar = () => {
      const side = Math.floor(Math.random() * 4)
      let startX, startY, endX, endY

      switch (side) {
        case 0: // Top
          startX = Math.random() * canvas.width
          startY = -50
          endX = startX + (Math.random() - 0.5) * 400
          endY = canvas.height + 50
          break
        case 1: // Right
          startX = canvas.width + 50
          startY = Math.random() * canvas.height
          endX = -50
          endY = startY + (Math.random() - 0.5) * 400
          break
        case 2: // Bottom
          startX = Math.random() * canvas.width
          startY = canvas.height + 50
          endX = startX + (Math.random() - 0.5) * 400
          endY = -50
          break
        case 3: // Left
          startX = -50
          startY = Math.random() * canvas.height
          endX = canvas.width + 50
          endY = startY + (Math.random() - 0.5) * 400
          break
      }

      return {
        x: startX,
        y: startY,
        endX,
        endY,
        speed: Math.random() * 3 + 2,
        size: Math.random() * 2 + 1,
        opacity: 1,
        trail: [],
        maxTrailLength: 20,
        life: 1
      }
    }

    // Animation loop
    const animate = () => {
      ctx.fillStyle = 'rgba(5, 5, 15, 0.1)'
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw nebula clouds
      nebulaClouds.forEach(cloud => {
        const gradient = ctx.createRadialGradient(
          cloud.x, cloud.y, 0,
          cloud.x, cloud.y, cloud.size
        )
        gradient.addColorStop(0, cloud.color.replace('50%', '30%') + Math.floor(cloud.opacity * 255).toString(16).padStart(2, '0'))
        gradient.addColorStop(0.5, cloud.color.replace('50%', '20%') + Math.floor(cloud.opacity * 128).toString(16).padStart(2, '0'))
        gradient.addColorStop(1, 'transparent')

        ctx.fillStyle = gradient
        ctx.fillRect(
          cloud.x - cloud.size,
          cloud.y - cloud.size,
          cloud.size * 2,
          cloud.size * 2
        )

        // Drift nebula clouds
        cloud.x += cloud.drift.x
        cloud.y += cloud.drift.y

        // Wrap around screen
        if (cloud.x < -cloud.size) cloud.x = canvas.width + cloud.size
        if (cloud.x > canvas.width + cloud.size) cloud.x = -cloud.size
        if (cloud.y < -cloud.size) cloud.y = canvas.height + cloud.size
        if (cloud.y > canvas.height + cloud.size) cloud.y = -cloud.size
      })

      // Draw static stars
      stars.forEach(star => {
        star.opacity += Math.sin(Date.now() * star.twinkleSpeed) * 0.01
        star.opacity = Math.max(0.1, Math.min(1, star.opacity))

        ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()

        // Add sparkle effect for larger stars
        if (star.size > 1.5 && star.opacity > 0.7) {
          ctx.strokeStyle = `rgba(255, 255, 255, ${star.opacity * 0.5})`
          ctx.lineWidth = 0.5
          ctx.beginPath()
          ctx.moveTo(star.x - star.size * 2, star.y)
          ctx.lineTo(star.x + star.size * 2, star.y)
          ctx.moveTo(star.x, star.y - star.size * 2)
          ctx.lineTo(star.x, star.y + star.size * 2)
          ctx.stroke()
        }
      })

      // Create new shooting stars randomly
      if (Math.random() < 0.003) {
        shootingStars.push(createShootingStar())
      }

      // Draw and update shooting stars
      shootingStars.forEach((star, index) => {
        // Calculate direction
        const dx = star.endX - star.x
        const dy = star.endY - star.y
        const distance = Math.sqrt(dx * dx + dy * dy)
        const dirX = dx / distance
        const dirY = dy / distance

        // Update position
        star.x += dirX * star.speed
        star.y += dirY * star.speed

        // Add to trail
        star.trail.push({ x: star.x, y: star.y, opacity: star.opacity })
        if (star.trail.length > star.maxTrailLength) {
          star.trail.shift()
        }

        // Draw trail
        star.trail.forEach((point, i) => {
          const trailOpacity = (i / star.trail.length) * star.opacity * 0.8
          ctx.fillStyle = `rgba(110, 231, 255, ${trailOpacity})`
          ctx.beginPath()
          ctx.arc(point.x, point.y, star.size * (i / star.trail.length), 0, Math.PI * 2)
          ctx.fill()
        })

        // Draw shooting star head
        const gradient = ctx.createRadialGradient(
          star.x, star.y, 0,
          star.x, star.y, star.size * 3
        )
        gradient.addColorStop(0, `rgba(255, 255, 255, ${star.opacity})`)
        gradient.addColorStop(0.3, `rgba(110, 231, 255, ${star.opacity * 0.8})`)
        gradient.addColorStop(1, 'transparent')

        ctx.fillStyle = gradient
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size * 3, 0, Math.PI * 2)
        ctx.fill()

        // Core bright point
        ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()

        // Fade out over time
        star.life -= 0.005
        star.opacity = star.life

        // Remove if off screen or faded
        const margin = 100
        if (star.x < -margin || star.x > canvas.width + margin ||
            star.y < -margin || star.y > canvas.height + margin ||
            star.opacity <= 0) {
          shootingStars.splice(index, 1)
        }
      })

      animationId = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener('resize', resizeCanvas)
      if (animationId) {
        cancelAnimationFrame(animationId)
      }
    }
  }, [])

  return (
    <>
      <div className="cosmic-background">
        <canvas
          ref={canvasRef}
          className="cosmic-canvas"
        />
        <div className="cosmic-overlay" />
      </div>
    </>
  )
}

export default CosmicBackground
