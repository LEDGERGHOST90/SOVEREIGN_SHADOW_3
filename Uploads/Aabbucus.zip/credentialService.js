// Sovereign Legacy Loop - Encrypted Credential Storage
// Keeps your API keys safe and persistent

const CryptoJS = require('crypto-js');
const bcrypt = require('bcryptjs');
const db = require('../database/database');

class CredentialService {
    constructor() {
        this.encryptionKey = this.getOrCreateEncryptionKey();
    }

    getOrCreateEncryptionKey() {
        // Try to get existing key from environment or generate new one
        let key = process.env.ENCRYPTION_KEY;
        
        if (!key) {
            // Generate a new encryption key
            key = CryptoJS.lib.WordArray.random(256/8).toString();
            console.log('🔐 Generated new encryption key for credential storage');
            
            // Save to database settings
            db.updateSetting('encryption_key_hash', bcrypt.hashSync(key, 10));
            db.updateSetting('encryption_key_set', 'true');
        }
        
        return key;
    }

    // Encrypt API credentials
    encryptCredentials(apiKey, secretKey) {
        try {
            const encryptedApiKey = CryptoJS.AES.encrypt(apiKey, this.encryptionKey).toString();
            const encryptedSecretKey = CryptoJS.AES.encrypt(secretKey, this.encryptionKey).toString();
            
            return {
                encryptedApiKey,
                encryptedSecretKey
            };
        } catch (error) {
            console.error('❌ Encryption failed:', error);
            throw new Error('Failed to encrypt credentials');
        }
    }

    // Decrypt API credentials
    decryptCredentials(encryptedApiKey, encryptedSecretKey) {
        try {
            const apiKey = CryptoJS.AES.decrypt(encryptedApiKey, this.encryptionKey).toString(CryptoJS.enc.Utf8);
            const secretKey = CryptoJS.AES.decrypt(encryptedSecretKey, this.encryptionKey).toString(CryptoJS.enc.Utf8);
            
            return {
                apiKey,
                secretKey
            };
        } catch (error) {
            console.error('❌ Decryption failed:', error);
            throw new Error('Failed to decrypt credentials');
        }
    }

    // Save encrypted credentials to database
    async saveCredentials(exchange, apiKey, secretKey) {
        try {
            const { encryptedApiKey, encryptedSecretKey } = this.encryptCredentials(apiKey, secretKey);
            
            const stmt = db.db.prepare(`
                INSERT OR REPLACE INTO api_credentials 
                (exchange, api_key_encrypted, secret_key_encrypted, is_active, updated_at)
                VALUES (?, ?, ?, 1, datetime('now'))
            `);
            
            const result = stmt.run(exchange, encryptedApiKey, encryptedSecretKey);
            
            console.log(`🔐 Credentials saved for ${exchange}`);
            return result.lastInsertRowid;
        } catch (error) {
            console.error('❌ Failed to save credentials:', error);
            throw error;
        }
    }

    // Get decrypted credentials from database
    async getCredentials(exchange = 'binance_us') {
        try {
            const stmt = db.db.prepare(`
                SELECT api_key_encrypted, secret_key_encrypted, last_tested, test_result
                FROM api_credentials 
                WHERE exchange = ? AND is_active = 1
                ORDER BY updated_at DESC
                LIMIT 1
            `);
            
            const result = stmt.get(exchange);
            
            if (!result) {
                return null;
            }
            
            const { apiKey, secretKey } = this.decryptCredentials(
                result.api_key_encrypted,
                result.secret_key_encrypted
            );
            
            return {
                apiKey,
                secretKey,
                lastTested: result.last_tested,
                testResult: result.test_result
            };
        } catch (error) {
            console.error('❌ Failed to get credentials:', error);
            return null;
        }
    }

    // Test API credentials and save result
    async testAndSaveCredentials(exchange, apiKey, secretKey, testFunction) {
        try {
            console.log(`🧪 Testing ${exchange} API credentials...`);
            
            // Run the test function
            const testResult = await testFunction(apiKey, secretKey);
            
            // Save credentials if test passed
            if (testResult.success) {
                await this.saveCredentials(exchange, apiKey, secretKey);
                
                // Update test result
                const stmt = db.db.prepare(`
                    UPDATE api_credentials 
                    SET last_tested = datetime('now'), test_result = ?
                    WHERE exchange = ? AND is_active = 1
                `);
                stmt.run(JSON.stringify(testResult), exchange);
                
                console.log(`✅ ${exchange} credentials tested and saved successfully`);
                return { success: true, message: 'Credentials saved successfully' };
            } else {
                console.log(`❌ ${exchange} credential test failed:`, testResult.error);
                return { success: false, error: testResult.error };
            }
        } catch (error) {
            console.error('❌ Credential test failed:', error);
            return { success: false, error: error.message };
        }
    }

    // Remove credentials
    async removeCredentials(exchange = 'binance_us') {
        try {
            const stmt = db.db.prepare(`
                UPDATE api_credentials 
                SET is_active = 0, updated_at = datetime('now')
                WHERE exchange = ?
            `);
            
            stmt.run(exchange);
            console.log(`🗑️ Credentials removed for ${exchange}`);
            return true;
        } catch (error) {
            console.error('❌ Failed to remove credentials:', error);
            return false;
        }
    }

    // Check if credentials exist
    async hasCredentials(exchange = 'binance_us') {
        try {
            const stmt = db.db.prepare(`
                SELECT COUNT(*) as count
                FROM api_credentials 
                WHERE exchange = ? AND is_active = 1
            `);
            
            const result = stmt.get(exchange);
            return result.count > 0;
        } catch (error) {
            console.error('❌ Failed to check credentials:', error);
            return false;
        }
    }
}

module.exports = new CredentialService();
