import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  CheckCircle, 
  Mail, 
  User, 
  MessageSquare, 
  Target,
  Zap,
  Crown,
  ArrowRight,
  Sparkles
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const Waitlist = () => {
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    useCase: '',
    note: '',
    tier: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [position, setPosition] = useState(null)

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Mock response
      const mockPosition = Math.floor(Math.random() * 1000) + 500
      setPosition(mockPosition)
      setIsSubmitted(true)
    } catch (error) {
      console.error('Submission error:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const benefits = [
    {
      icon: Target,
      title: "Early Access",
      description: "Be among the first to experience the Sovereign Legacy Loop platform",
      color: "text-[#6EE7FF]"
    },
    {
      icon: Zap,
      title: "Beta Pricing",
      description: "Lock in special pricing before public launch",
      color: "text-[#FF6EE7]"
    },
    {
      icon: Crown,
      title: "Priority Support",
      description: "Direct access to the development team and priority feature requests",
      color: "text-[#A3FF8F]"
    },
    {
      icon: Sparkles,
      title: "Exclusive Updates",
      description: "Regular updates on development progress and new features",
      color: "text-[#C084FC]"
    }
  ]

  const useCases = [
    "Personal wealth building",
    "Professional trading",
    "Portfolio management",
    "Institutional use",
    "API integration",
    "Research & analysis",
    "Other"
  ]

  const tiers = [
    { value: "signals", label: "Signals ($49/mo)", description: "Basic signals and dashboards" },
    { value: "ai-sniper", label: "AI Sniper ($149/mo)", description: "Advanced AI insights" },
    { value: "institutional", label: "Institutional ($499/mo)", description: "Full API access" },
    { value: "enterprise", label: "Enterprise", description: "Custom solutions" }
  ]

  if (isSubmitted) {
    return (
      <div className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <Card className="glass-card border-green-500/30 neon-glow">
              <CardContent className="p-12">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6"
                >
                  <CheckCircle className="w-12 h-12 text-green-400" />
                </motion.div>
                
                <h1 className="text-3xl font-bold mb-4">
                  <span className="text-gradient">Welcome to the Future!</span>
                </h1>
                
                <p className="text-xl text-muted-foreground mb-6">
                  You're successfully on the Sovereign Legacy Loop waitlist
                </p>

                <div className="glass-card p-6 rounded-lg mb-8">
                  <div className="text-4xl font-bold text-primary mb-2">#{position}</div>
                  <div className="text-sm text-muted-foreground">Your position in line</div>
                </div>

                <div className="space-y-4 text-left max-w-md mx-auto">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                    <span className="text-sm">Confirmation email sent to {formData.email}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                    <span className="text-sm">You'll receive updates on development progress</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                    <span className="text-sm">Early access when beta launches</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                    <span className="text-sm">Special pricing locked in</span>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/10">
                  <p className="text-sm text-muted-foreground mb-4">
                    Share the Sovereign Legacy Loop with others:
                  </p>
                  <div className="flex justify-center space-x-4">
                    <Button variant="outline" size="sm" className="border-primary/30">
                      Share on Twitter
                    </Button>
                    <Button variant="outline" size="sm" className="border-primary/30">
                      Copy Link
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    )
  }

  return (
    <div className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="text-gradient">Join the Waitlist</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Be among the first to experience the revolutionary Sovereign Legacy Loop platform. 
            Get early access, special pricing, and direct input on features.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mail className="w-6 h-6 text-primary" />
                  <span>Reserve Your Spot</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Your name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="glass"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your@email.com"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="glass"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="useCase">Primary Use Case</Label>
                    <Select onValueChange={(value) => handleInputChange('useCase', value)}>
                      <SelectTrigger className="glass">
                        <SelectValue placeholder="Select your primary use case" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/10">
                        {useCases.map((useCase) => (
                          <SelectItem key={useCase} value={useCase}>
                            {useCase}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tier">Interested Tier</Label>
                    <Select onValueChange={(value) => handleInputChange('tier', value)}>
                      <SelectTrigger className="glass">
                        <SelectValue placeholder="Select your preferred tier" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/10">
                        {tiers.map((tier) => (
                          <SelectItem key={tier.value} value={tier.value}>
                            <div>
                              <div className="font-medium">{tier.label}</div>
                              <div className="text-xs text-muted-foreground">{tier.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="note">Additional Notes</Label>
                    <Textarea
                      id="note"
                      placeholder="Tell us about your specific needs, questions, or how you plan to use the platform..."
                      value={formData.note}
                      onChange={(e) => handleInputChange('note', e.target.value)}
                      className="glass min-h-[100px]"
                      rows={4}
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting || !formData.email}
                    className="w-full gradient-aqua-magenta text-black font-semibold hover-lift"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>
                        <span>Joining Waitlist...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <span>Join Waitlist</span>
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    )}
                  </Button>

                  <p className="text-xs text-muted-foreground text-center">
                    By joining, you agree to receive updates about the Sovereign Legacy Loop platform. 
                    You can unsubscribe at any time.
                  </p>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Benefits */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="space-y-6"
          >
            <div>
              <h2 className="text-2xl font-bold mb-6">
                <span className="text-gradient">Waitlist Benefits</span>
              </h2>
              <div className="space-y-4">
                {benefits.map((benefit, index) => {
                  const Icon = benefit.icon
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                    >
                      <Card className="glass-card hover-lift">
                        <CardContent className="p-6">
                          <div className="flex items-start space-x-4">
                            <div className={`w-12 h-12 rounded-full bg-gradient-to-br from-current/20 to-current/5 flex items-center justify-center flex-shrink-0 ${benefit.color}`}>
                              <Icon className={`w-6 h-6 ${benefit.color}`} />
                            </div>
                            <div>
                              <h3 className="font-semibold mb-2">{benefit.title}</h3>
                              <p className="text-sm text-muted-foreground leading-relaxed">
                                {benefit.description}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )
                })}
              </div>
            </div>

            {/* Stats */}
            <Card className="glass-card border-primary/30">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4 text-center">Current Waitlist Stats</h3>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-[#6EE7FF] mb-1">1,247</div>
                    <div className="text-xs text-muted-foreground">Total Members</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-[#FF6EE7] mb-1">Q2 2024</div>
                    <div className="text-xs text-muted-foreground">Expected Launch</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Social Proof */}
            <Card className="glass-card">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">What Early Members Say</h3>
                <div className="space-y-4">
                  <blockquote className="text-sm text-muted-foreground italic">
                    "Finally, a system that makes sense for building real wealth in crypto. 
                    The graduation protocol is genius."
                  </blockquote>
                  <div className="text-xs text-muted-foreground">— Alex K., Portfolio Manager</div>
                  
                  <blockquote className="text-sm text-muted-foreground italic">
                    "I've been waiting for something like this. The self-fueling concept 
                    is exactly what retail traders need."
                  </blockquote>
                  <div className="text-xs text-muted-foreground">— Sarah M., Crypto Trader</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

export default Waitlist
