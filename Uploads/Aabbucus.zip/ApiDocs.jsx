import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Code, 
  Copy, 
  CheckCircle, 
  FileText, 
  Zap, 
  Shield,
  Globe,
  Key,
  Database,
  ArrowRight
} from 'lucide-react'
import { motion } from 'framer-motion'

const ApiDocs = () => {
  const [copiedEndpoint, setCopiedEndpoint] = useState(null)

  const copyToClipboard = (text, endpoint) => {
    navigator.clipboard.writeText(text)
    setCopiedEndpoint(endpoint)
    setTimeout(() => setCopiedEndpoint(null), 2000)
  }

  const endpoints = [
    {
      method: 'GET',
      path: '/api/portfolio',
      description: 'Retrieve current portfolio balances and positions',
      auth: false,
      response: {
        btc: { amount: 630, percentage: 31, target: 500 },
        eth: { amount: 407, percentage: 20, target: 500 },
        sol: { amount: 393, percentage: 19, target: 500 },
        xrp: { amount: 392, percentage: 19, target: 500 },
        usdt: { amount: 232, percentage: 11, target: 0 },
        total_value: 2054,
        last_updated: "2024-01-15T10:30:00Z"
      }
    },
    {
      method: 'GET',
      path: '/api/pnl',
      description: 'Get profit and loss history for charting',
      auth: false,
      params: {
        timeframe: 'Optional. Values: 1h, 4h, 1d, 1w, 1m. Default: 1d',
        limit: 'Optional. Number of data points. Default: 100'
      },
      response: {
        data: [
          { timestamp: "2024-01-15T00:00:00Z", value: 2054, pnl: 26.05, pnl_percent: 1.28 },
          { timestamp: "2024-01-14T00:00:00Z", value: 2028, pnl: -15.20, pnl_percent: -0.74 }
        ],
        total_pnl: 26.05,
        total_pnl_percent: 1.28
      }
    },
    {
      method: 'POST',
      path: '/api/simulate-siphon',
      description: 'Execute profit siphon simulation (requires passphrase)',
      auth: true,
      body: {
        passphrase: 'ΩSIGIL-COLLECT-YYYYMMDD',
        dry_run: true
      },
      response: {
        success: true,
        simulation_id: 'sim_abc123',
        actions: [
          { type: 'profit_calculation', amount: 156.50 },
          { type: 'core_reinvestment', amount: 46.95, percentage: 30 },
          { type: 'usdt_allocation', amount: 109.55, percentage: 70 },
          { type: 'rebalancing', trades: [] }
        ],
        estimated_completion: '2024-01-15T10:35:00Z'
      }
    },
    {
      method: 'POST',
      path: '/api/waitlist',
      description: 'Add user to waitlist',
      auth: false,
      body: {
        email: 'user@example.com',
        note: 'Interested in AI Sniper tier',
        use_case: 'Personal wealth building'
      },
      response: {
        success: true,
        message: 'Successfully added to waitlist',
        position: 1247
      }
    }
  ]

  const errorCodes = [
    { code: 400, description: 'Bad Request - Invalid parameters or missing required fields' },
    { code: 401, description: 'Unauthorized - Invalid or missing passphrase' },
    { code:403, description: 'Forbidden - Access denied or rate limit exceeded' },
    { code: 404, description: 'Not Found - Endpoint does not exist' },
    { code: 429, description: 'Too Many Requests - Rate limit exceeded' },
    { code: 500, description: 'Internal Server Error - Server-side error occurred' }
  ]

  return (
    <div className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="text-gradient">API Documentation</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Integrate the Sovereign Legacy Loop into your applications with our comprehensive API. 
            Build custom dashboards, automate workflows, and access real-time portfolio data.
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5 glass-card">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="endpoints">Endpoints</TabsTrigger>
            <TabsTrigger value="authentication">Auth</TabsTrigger>
            <TabsTrigger value="examples">Examples</TabsTrigger>
            <TabsTrigger value="errors">Errors</TabsTrigger>
          </TabsList>

          {/* Overview */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="glass-card">
                <CardContent className="p-6 text-center">
                  <Globe className="w-12 h-12 text-[#6EE7FF] mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">RESTful API</h3>
                  <p className="text-sm text-muted-foreground">
                    Standard HTTP methods with JSON responses for easy integration
                  </p>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardContent className="p-6 text-center">
                  <Zap className="w-12 h-12 text-[#FF6EE7] mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Real-time Data</h3>
                  <p className="text-sm text-muted-foreground">
                    Live portfolio updates and profit/loss tracking
                  </p>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardContent className="p-6 text-center">
                  <Shield className="w-12 h-12 text-[#A3FF8F] mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Secure Access</h3>
                  <p className="text-sm text-muted-foreground">
                    Passphrase-protected sensitive operations with rate limiting
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Code className="w-6 h-6 text-primary" />
                  <span>Base URL</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="glass p-4 rounded-lg font-mono text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-primary">https://api.sovereignlegacyloop.com</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard('https://api.sovereignlegacyloop.com', 'base-url')}
                    >
                      {copiedEndpoint === 'base-url' ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mt-4">
                  All API requests should be made to this base URL. The API is currently in beta 
                  and available to waitlist members only.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Endpoints */}
          <TabsContent value="endpoints" className="space-y-6">
            {endpoints.map((endpoint, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="glass-card">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center space-x-3">
                        <Badge 
                          className={`${
                            endpoint.method === 'GET' 
                              ? 'bg-green-500/20 text-green-400 border-green-500/30' 
                              : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                          }`}
                        >
                          {endpoint.method}
                        </Badge>
                        <span className="font-mono text-lg">{endpoint.path}</span>
                      </CardTitle>
                      {endpoint.auth && (
                        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                          <Key className="w-3 h-3 mr-1" />
                          Auth Required
                        </Badge>
                      )}
                    </div>
                    <p className="text-muted-foreground">{endpoint.description}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {endpoint.params && (
                      <div>
                        <h4 className="font-semibold mb-2 text-[#6EE7FF]">Parameters</h4>
                        <div className="glass p-4 rounded-lg">
                          {Object.entries(endpoint.params).map(([param, desc]) => (
                            <div key={param} className="flex justify-between items-start mb-2 last:mb-0">
                              <code className="text-sm text-primary">{param}</code>
                              <span className="text-sm text-muted-foreground ml-4">{desc}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {endpoint.body && (
                      <div>
                        <h4 className="font-semibold mb-2 text-[#FF6EE7]">Request Body</h4>
                        <div className="glass p-4 rounded-lg">
                          <pre className="text-sm text-muted-foreground overflow-x-auto">
                            {JSON.stringify(endpoint.body, null, 2)}
                          </pre>
                        </div>
                      </div>
                    )}

                    <div>
                      <h4 className="font-semibold mb-2 text-[#A3FF8F]">Response</h4>
                      <div className="glass p-4 rounded-lg">
                        <pre className="text-sm text-muted-foreground overflow-x-auto">
                          {JSON.stringify(endpoint.response, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </TabsContent>

          {/* Authentication */}
          <TabsContent value="authentication" className="space-y-6">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Key className="w-6 h-6 text-primary" />
                  <span>Authentication</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-[#6EE7FF]">Passphrase System</h3>
                  <p className="text-muted-foreground mb-4">
                    Sensitive operations require a daily passphrase for security. The passphrase format is:
                  </p>
                  <div className="glass p-4 rounded-lg font-mono text-center">
                    <span className="text-primary">ΩSIGIL-COLLECT-YYYYMMDD</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    Replace YYYYMMDD with the current date (e.g., 20240115 for January 15, 2024)
                  </p>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3 text-[#FF6EE7]">Rate Limiting</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="glass p-4 rounded-lg">
                      <h4 className="font-semibold text-sm mb-2">Public Endpoints</h4>
                      <p className="text-sm text-muted-foreground">100 requests per minute</p>
                    </div>
                    <div className="glass p-4 rounded-lg">
                      <h4 className="font-semibold text-sm mb-2">Authenticated Endpoints</h4>
                      <p className="text-sm text-muted-foreground">10 requests per minute</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3 text-[#C084FC]">Headers</h3>
                  <div className="glass p-4 rounded-lg">
                    <div className="space-y-2 font-mono text-sm">
                      <div className="flex justify-between">
                        <span className="text-primary">Content-Type:</span>
                        <span className="text-muted-foreground">application/json</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-primary">Accept:</span>
                        <span className="text-muted-foreground">application/json</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-primary">User-Agent:</span>
                        <span className="text-muted-foreground">YourApp/1.0</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Examples */}
          <TabsContent value="examples" className="space-y-6">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="w-6 h-6 text-primary" />
                  <span>Code Examples</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-[#6EE7FF]">JavaScript / Node.js</h3>
                  <div className="glass p-4 rounded-lg">
                    <pre className="text-sm text-muted-foreground overflow-x-auto">
{`// Get portfolio data
const response = await fetch('https://api.sovereignlegacyloop.com/api/portfolio');
const portfolio = await response.json();

// Simulate siphon (requires passphrase)
const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
const passphrase = \`ΩSIGIL-COLLECT-\${today}\`;

const siphonResponse = await fetch('https://api.sovereignlegacyloop.com/api/simulate-siphon', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ passphrase, dry_run: true })
});`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3 text-[#FF6EE7]">Python</h3>
                  <div className="glass p-4 rounded-lg">
                    <pre className="text-sm text-muted-foreground overflow-x-auto">
{`import requests
from datetime import datetime

# Get portfolio data
response = requests.get('https://api.sovereignlegacyloop.com/api/portfolio')
portfolio = response.json()

# Simulate siphon
today = datetime.now().strftime('%Y%m%d')
passphrase = f'ΩSIGIL-COLLECT-{today}'

siphon_response = requests.post(
    'https://api.sovereignlegacyloop.com/api/simulate-siphon',
    json={'passphrase': passphrase, 'dry_run': True}
)`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3 text-[#A3FF8F]">cURL</h3>
                  <div className="glass p-4 rounded-lg">
                    <pre className="text-sm text-muted-foreground overflow-x-auto">
{`# Get portfolio data
curl -X GET https://api.sovereignlegacyloop.com/api/portfolio

# Simulate siphon
curl -X POST https://api.sovereignlegacyloop.com/api/simulate-siphon \\
  -H "Content-Type: application/json" \\
  -d '{"passphrase": "ΩSIGIL-COLLECT-20240115", "dry_run": true}'`}
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Errors */}
          <TabsContent value="errors" className="space-y-6">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Database className="w-6 h-6 text-primary" />
                  <span>Error Handling</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-[#6EE7FF]">Error Response Format</h3>
                  <div className="glass p-4 rounded-lg">
                    <pre className="text-sm text-muted-foreground">
{`{
  "success": false,
  "error": {
    "code": "INVALID_PASSPHRASE",
    "message": "The provided passphrase is invalid or expired",
    "details": "Expected format: ΩSIGIL-COLLECT-YYYYMMDD"
  },
  "timestamp": "2024-01-15T10:30:00Z"
}`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3 text-[#FF6EE7]">HTTP Status Codes</h3>
                  <div className="space-y-3">
                    {errorCodes.map((error, index) => (
                      <div key={index} className="flex items-center justify-between glass p-3 rounded-lg">
                        <Badge className={`${
                          error.code < 400 ? 'bg-green-500/20 text-green-400' :
                          error.code < 500 ? 'bg-amber-500/20 text-amber-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {error.code}
                        </Badge>
                        <span className="text-sm text-muted-foreground ml-4">{error.description}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <Card className="glass-card border-primary/30">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Join our waitlist to get early access to the API and start building 
                with the Sovereign Legacy Loop platform.
              </p>
              <Button className="gradient-aqua-magenta text-black font-semibold hover-lift">
                Join API Waitlist
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default ApiDocs
