// Using Web Crypto API for browser compatibility

class SecurityManager {
  constructor() {
    this.maxTradeAmount = 1000 // Maximum single trade amount in USD
    this.dailyTradeLimit = 5000 // Maximum daily trading volume in USD
    this.tradingCooldown = 30000 // 30 seconds between trades
    this.lastTradeTime = 0
    this.dailyTradeVolume = 0
    this.lastResetDate = new Date().toDateString()
    
    this.loadDailyLimits()
  }

  // Load daily trading limits from localStorage
  loadDailyLimits() {
    try {
      const stored = localStorage.getItem('daily_trade_data')
      if (stored) {
        const data = JSON.parse(stored)
        const today = new Date().toDateString()
        
        if (data.date === today) {
          this.dailyTradeVolume = data.volume || 0
        } else {
          // Reset for new day
          this.dailyTradeVolume = 0
          this.saveDailyLimits()
        }
      }
    } catch (error) {
      console.warn('Failed to load daily limits:', error)
    }
  }

  // Save daily trading limits to localStorage
  saveDailyLimits() {
    try {
      const data = {
        date: new Date().toDateString(),
        volume: this.dailyTradeVolume
      }
      localStorage.setItem('daily_trade_data', JSON.stringify(data))
    } catch (error) {
      console.warn('Failed to save daily limits:', error)
    }
  }

  // Validate trade parameters before execution
  validateTrade(side, symbol, amount, type = 'MARKET') {
    const errors = []

    // Check trade amount
    if (!amount || amount <= 0) {
      errors.push('Trade amount must be greater than 0')
    }

    if (amount > this.maxTradeAmount) {
      errors.push(`Trade amount exceeds maximum limit of $${this.maxTradeAmount}`)
    }

    // Check daily limits
    if (this.dailyTradeVolume + amount > this.dailyTradeLimit) {
      errors.push(`Trade would exceed daily limit of $${this.dailyTradeLimit}`)
    }

    // Check cooldown period
    const now = Date.now()
    if (now - this.lastTradeTime < this.tradingCooldown) {
      const remainingCooldown = Math.ceil((this.tradingCooldown - (now - this.lastTradeTime)) / 1000)
      errors.push(`Please wait ${remainingCooldown} seconds before next trade`)
    }

    // Validate symbol
    const allowedSymbols = ['BTC', 'ETH', 'SOL', 'XRP']
    if (!allowedSymbols.includes(symbol.toUpperCase())) {
      errors.push(`Trading not allowed for ${symbol}. Allowed assets: ${allowedSymbols.join(', ')}`)
    }

    // Validate side
    if (!['BUY', 'SELL'].includes(side.toUpperCase())) {
      errors.push('Trade side must be BUY or SELL')
    }

    // Validate type
    if (!['MARKET', 'LIMIT'].includes(type.toUpperCase())) {
      errors.push('Trade type must be MARKET or LIMIT')
    }

    return {
      isValid: errors.length === 0,
      errors: errors
    }
  }

  // Record a successful trade
  recordTrade(amount) {
    this.lastTradeTime = Date.now()
    this.dailyTradeVolume += amount
    this.saveDailyLimits()
  }

  // Validate passphrase format and timing
  validatePassphrase(passphrase) {
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '')
    const expectedFormat = `ΩSIGIL-COLLECT-${today}`
    
    if (passphrase !== expectedFormat) {
      return {
        isValid: false,
        error: `Invalid passphrase. Expected format: ΩSIGIL-COLLECT-${today}`
      }
    }

    return { isValid: true }
  }

  // Encrypt sensitive data for storage using Web Crypto API
  async encryptData(data, password) {
    try {
      const encoder = new TextEncoder()
      const dataBuffer = encoder.encode(JSON.stringify(data))
      const passwordBuffer = encoder.encode(password)
      
      // Create key from password
      const keyMaterial = await crypto.subtle.importKey(
        'raw',
        passwordBuffer,
        { name: 'PBKDF2' },
        false,
        ['deriveKey']
      )
      
      const salt = crypto.getRandomValues(new Uint8Array(16))
      const key = await crypto.subtle.deriveKey(
        {
          name: 'PBKDF2',
          salt: salt,
          iterations: 100000,
          hash: 'SHA-256'
        },
        keyMaterial,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt']
      )
      
      const iv = crypto.getRandomValues(new Uint8Array(12))
      const encrypted = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        dataBuffer
      )
      
      // Combine salt, iv, and encrypted data
      const result = new Uint8Array(salt.length + iv.length + encrypted.byteLength)
      result.set(salt, 0)
      result.set(iv, salt.length)
      result.set(new Uint8Array(encrypted), salt.length + iv.length)
      
      return btoa(String.fromCharCode(...result))
    } catch (error) {
      console.error('Encryption failed:', error)
      throw new Error('Failed to encrypt data')
    }
  }

  // Decrypt sensitive data from storage using Web Crypto API
  async decryptData(encryptedData, password) {
    try {
      const data = new Uint8Array(atob(encryptedData).split('').map(c => c.charCodeAt(0)))
      const salt = data.slice(0, 16)
      const iv = data.slice(16, 28)
      const encrypted = data.slice(28)
      
      const encoder = new TextEncoder()
      const passwordBuffer = encoder.encode(password)
      
      // Recreate key from password and salt
      const keyMaterial = await crypto.subtle.importKey(
        'raw',
        passwordBuffer,
        { name: 'PBKDF2' },
        false,
        ['deriveKey']
      )
      
      const key = await crypto.subtle.deriveKey(
        {
          name: 'PBKDF2',
          salt: salt,
          iterations: 100000,
          hash: 'SHA-256'
        },
        keyMaterial,
        { name: 'AES-GCM', length: 256 },
        false,
        ['decrypt']
      )
      
      const decrypted = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        encrypted
      )
      
      const decoder = new TextDecoder()
      return JSON.parse(decoder.decode(decrypted))
    } catch (error) {
      console.error('Decryption failed:', error)
      throw new Error('Failed to decrypt data')
    }
  }

  // Validate API credentials format
  validateApiCredentials(apiKey, secretKey) {
    const errors = []

    if (!apiKey || apiKey.length < 10) {
      errors.push('API key appears to be invalid or too short')
    }

    if (!secretKey || secretKey.length < 10) {
      errors.push('Secret key appears to be invalid or too short')
    }

    // Check for common patterns that might indicate test/fake keys
    const testPatterns = ['test', 'demo', 'fake', 'example', '123456']
    const keyLower = (apiKey + secretKey).toLowerCase()
    
    for (const pattern of testPatterns) {
      if (keyLower.includes(pattern)) {
        errors.push('API credentials appear to be test/demo keys')
        break
      }
    }

    return {
      isValid: errors.length === 0,
      errors: errors
    }
  }

  // Rate limiting for API calls
  checkRateLimit(endpoint) {
    const rateLimits = {
      'account': { limit: 10, window: 60000 }, // 10 calls per minute
      'prices': { limit: 100, window: 60000 }, // 100 calls per minute
      'trade': { limit: 5, window: 60000 }, // 5 trades per minute
      'default': { limit: 50, window: 60000 } // 50 calls per minute
    }

    const limit = rateLimits[endpoint] || rateLimits.default
    const key = `rate_limit_${endpoint}`
    
    try {
      const stored = localStorage.getItem(key)
      const now = Date.now()
      
      if (stored) {
        const data = JSON.parse(stored)
        
        // Reset if window has passed
        if (now - data.windowStart > limit.window) {
          data.count = 0
          data.windowStart = now
        }
        
        if (data.count >= limit.limit) {
          const resetTime = Math.ceil((limit.window - (now - data.windowStart)) / 1000)
          return {
            allowed: false,
            error: `Rate limit exceeded for ${endpoint}. Try again in ${resetTime} seconds.`
          }
        }
        
        data.count++
        localStorage.setItem(key, JSON.stringify(data))
      } else {
        localStorage.setItem(key, JSON.stringify({
          count: 1,
          windowStart: now
        }))
      }
      
      return { allowed: true }
    } catch (error) {
      console.warn('Rate limit check failed:', error)
      return { allowed: true } // Allow on error
    }
  }

  // Portfolio risk assessment
  assessPortfolioRisk(portfolioData) {
    const risks = []
    const warnings = []

    if (!portfolioData) {
      return { risks: ['No portfolio data available'], warnings: [] }
    }

    // Check concentration risk
    Object.entries(portfolioData).forEach(([asset, data]) => {
      if (asset === 'total_value' || asset === 'last_updated' || asset === 'source') return
      
      if (data.percentage > 50) {
        risks.push(`High concentration in ${asset.toUpperCase()}: ${data.percentage}%`)
      } else if (data.percentage > 35) {
        warnings.push(`Moderate concentration in ${asset.toUpperCase()}: ${data.percentage}%`)
      }
    })

    // Check if USDT allocation is too low (should be at least 10% for opportunities)
    const usdtPercentage = portfolioData.usdt?.percentage || 0
    if (usdtPercentage < 5) {
      warnings.push('USDT war chest is very low - consider maintaining higher cash position')
    }

    // Check total portfolio value for minimum thresholds
    const totalValue = portfolioData.total_value || 0
    if (totalValue < 1000) {
      warnings.push('Portfolio value is below recommended minimum for active trading')
    }

    // Check for negative 24h performance
    const change24h = portfolioData.total_change_percent || 0
    if (change24h < -10) {
      risks.push(`Significant 24h loss: ${change24h.toFixed(2)}%`)
    } else if (change24h < -5) {
      warnings.push(`Notable 24h decline: ${change24h.toFixed(2)}%`)
    }

    return {
      risks: risks,
      warnings: warnings,
      riskLevel: risks.length > 0 ? 'HIGH' : warnings.length > 2 ? 'MEDIUM' : 'LOW'
    }
  }

  // Get current security settings
  getSecuritySettings() {
    return {
      maxTradeAmount: this.maxTradeAmount,
      dailyTradeLimit: this.dailyTradeLimit,
      tradingCooldown: this.tradingCooldown,
      dailyTradeVolume: this.dailyTradeVolume,
      remainingDailyLimit: this.dailyTradeLimit - this.dailyTradeVolume
    }
  }

  // Update security settings
  updateSecuritySettings(settings) {
    if (settings.maxTradeAmount && settings.maxTradeAmount > 0) {
      this.maxTradeAmount = settings.maxTradeAmount
    }
    
    if (settings.dailyTradeLimit && settings.dailyTradeLimit > 0) {
      this.dailyTradeLimit = settings.dailyTradeLimit
    }
    
    if (settings.tradingCooldown && settings.tradingCooldown >= 0) {
      this.tradingCooldown = settings.tradingCooldown
    }

    // Save to localStorage
    try {
      localStorage.setItem('security_settings', JSON.stringify({
        maxTradeAmount: this.maxTradeAmount,
        dailyTradeLimit: this.dailyTradeLimit,
        tradingCooldown: this.tradingCooldown
      }))
    } catch (error) {
      console.warn('Failed to save security settings:', error)
    }
  }

  // Load security settings from localStorage
  loadSecuritySettings() {
    try {
      const stored = localStorage.getItem('security_settings')
      if (stored) {
        const settings = JSON.parse(stored)
        this.maxTradeAmount = settings.maxTradeAmount || this.maxTradeAmount
        this.dailyTradeLimit = settings.dailyTradeLimit || this.dailyTradeLimit
        this.tradingCooldown = settings.tradingCooldown || this.tradingCooldown
      }
    } catch (error) {
      console.warn('Failed to load security settings:', error)
    }
  }
}

// Export singleton instance
export default new SecurityManager()
