import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Settings, 
  Key, 
  Shield, 
  CheckCircle, 
  AlertTriangle,
  Eye,
  EyeOff,
  RefreshCw,
  Zap,
  TrendingUp
} from 'lucide-react'
import { motion } from 'framer-motion'
import binanceService from '../services/binanceService'
import SecurityDashboard from '../components/SecurityDashboard'

const ApiSettings = () => {
  const [credentials, setCredentials] = useState({
    apiKey: '',
    secretKey: ''
  })
  const [showSecrets, setShowSecrets] = useState({
    apiKey: false,
    secretKey: false
  })
  const [isTestingConnection, setIsTestingConnection] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState(null)
  const [accountInfo, setAccountInfo] = useState(null)
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    // Load saved credentials from localStorage (in production, use secure storage)
    const savedApiKey = localStorage.getItem('binance_api_key')
    const savedSecretKey = localStorage.getItem('binance_secret_key')
    
    if (savedApiKey && savedSecretKey) {
      setCredentials({
        apiKey: savedApiKey,
        secretKey: savedSecretKey
      })
    }
  }, [])

  const handleInputChange = (field, value) => {
    setCredentials(prev => ({ ...prev, [field]: value }))
    setConnectionStatus(null) // Reset connection status when credentials change
  }

  const toggleShowSecret = (field) => {
    setShowSecrets(prev => ({ ...prev, [field]: !prev[field] }))
  }

  const saveCredentials = async () => {
    setIsSaving(true)
    try {
      // In production, these should be encrypted and stored securely
      localStorage.setItem('binance_api_key', credentials.apiKey)
      localStorage.setItem('binance_secret_key', credentials.secretKey)
      
      // Set credentials in the service
      binanceService.setCredentials(credentials.apiKey, credentials.secretKey)
      
      setConnectionStatus({
        type: 'success',
        message: 'API credentials saved successfully!'
      })
    } catch (error) {
      setConnectionStatus({
        type: 'error',
        message: `Failed to save credentials: ${error.message}`
      })
    } finally {
      setIsSaving(false)
    }
  }

  const testConnection = async () => {
    if (!credentials.apiKey || !credentials.secretKey) {
      setConnectionStatus({
        type: 'error',
        message: 'Please enter both API key and secret key'
      })
      return
    }

    setIsTestingConnection(true)
    setConnectionStatus(null)

    try {
      // Set credentials in the service
      binanceService.setCredentials(credentials.apiKey, credentials.secretKey)
      
      // Test the connection via backend proxy
      const testResult = await binanceService.testConnection()
      
      if (testResult.success) {
        setConnectionStatus({
          type: 'success',
          message: `Connection successful! Account type: ${testResult.accountType || 'SPOT'}`
        })
        setAccountInfo(testResult)
      } else {
        setConnectionStatus({
          type: 'error',
          message: testResult.error || 'Connection failed'
        })
        setAccountInfo(null)
      }
    } catch (error) {
      setConnectionStatus({
        type: 'error',
        message: `Connection failed: ${error.message}`
      })
      setAccountInfo(null)
    } finally {
      setIsTestingConnection(false)
    }
  }

  const clearCredentials = () => {
    setCredentials({ apiKey: '', secretKey: '' })
    localStorage.removeItem('binance_api_key')
    localStorage.removeItem('binance_secret_key')
    setConnectionStatus(null)
    setAccountInfo(null)
  }

  return (
    <div className="pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">
            <span className="text-gradient">API Configuration</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Connect your Binance US account to enable live trading and portfolio management. 
            Your credentials are stored securely and never transmitted to our servers.
          </p>
        </div>

        <Tabs defaultValue="credentials" className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 glass-card">
            <TabsTrigger value="credentials">API Credentials</TabsTrigger>
            <TabsTrigger value="security">Security & Risk</TabsTrigger>
          </TabsList>

          <TabsContent value="credentials" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Credentials Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Key className="w-6 h-6 text-primary" />
                  <span>Binance US API Credentials</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="apiKey">API Key</Label>
                  <div className="relative">
                    <Input
                      id="apiKey"
                      type={showSecrets.apiKey ? "text" : "password"}
                      placeholder="Enter your Binance US API key"
                      value={credentials.apiKey}
                      onChange={(e) => handleInputChange('apiKey', e.target.value)}
                      className="glass pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                      onClick={() => toggleShowSecret('apiKey')}
                    >
                      {showSecrets.apiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="secretKey">Secret Key</Label>
                  <div className="relative">
                    <Input
                      id="secretKey"
                      type={showSecrets.secretKey ? "text" : "password"}
                      placeholder="Enter your Binance US secret key"
                      value={credentials.secretKey}
                      onChange={(e) => handleInputChange('secretKey', e.target.value)}
                      className="glass pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                      onClick={() => toggleShowSecret('secretKey')}
                    >
                      {showSecrets.secretKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                {connectionStatus && (
                  <Alert className={`${connectionStatus.type === 'success' ? 'border-green-500/30' : 'border-red-500/30'}`}>
                    <div className="flex items-center space-x-2">
                      {connectionStatus.type === 'success' ? 
                        <CheckCircle className="w-4 h-4 text-green-400" /> : 
                        <AlertTriangle className="w-4 h-4 text-red-400" />
                      }
                      <AlertDescription className={connectionStatus.type === 'success' ? 'text-green-400' : 'text-red-400'}>
                        {connectionStatus.message}
                      </AlertDescription>
                    </div>
                  </Alert>
                )}

                <div className="flex space-x-3">
                  <Button
                    onClick={testConnection}
                    disabled={isTestingConnection || !credentials.apiKey || !credentials.secretKey}
                    className="flex-1 gradient-aqua-magenta text-black font-semibold hover-lift"
                  >
                    {isTestingConnection ? (
                      <div className="flex items-center space-x-2">
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Testing...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <Zap className="w-4 h-4" />
                        <span>Test Connection</span>
                      </div>
                    )}
                  </Button>
                  
                  <Button
                    onClick={saveCredentials}
                    disabled={isSaving || !credentials.apiKey || !credentials.secretKey}
                    variant="outline"
                    className="border-primary/30"
                  >
                    {isSaving ? 'Saving...' : 'Save'}
                  </Button>
                  
                  <Button
                    onClick={clearCredentials}
                    variant="outline"
                    className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                  >
                    Clear
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Account Info & Security */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="space-y-6"
          >
            {/* Account Information */}
            {accountInfo && (
              <Card className="glass-card border-green-500/30">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-6 h-6 text-green-400" />
                    <span>Account Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Account Type</div>
                      <div className="font-semibold">{accountInfo.accountType}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Trading Enabled</div>
                      <div className={`font-semibold ${accountInfo.canTrade ? 'text-green-400' : 'text-red-400'}`}>
                        {accountInfo.canTrade ? 'Yes' : 'No'}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Withdrawals</div>
                      <div className={`font-semibold ${accountInfo.canWithdraw ? 'text-green-400' : 'text-red-400'}`}>
                        {accountInfo.canWithdraw ? 'Enabled' : 'Disabled'}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Deposits</div>
                      <div className={`font-semibold ${accountInfo.canDeposit ? 'text-green-400' : 'text-red-400'}`}>
                        {accountInfo.canDeposit ? 'Enabled' : 'Disabled'}
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-muted-foreground mb-2">Active Balances</div>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {accountInfo.balances.slice(0, 5).map((balance, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span>{balance.asset}</span>
                          <span>{parseFloat(balance.free).toFixed(6)}</span>
                        </div>
                      ))}
                      {accountInfo.balances.length > 5 && (
                        <div className="text-xs text-muted-foreground">
                          +{accountInfo.balances.length - 5} more assets
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Security Information */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="w-6 h-6 text-primary" />
                  <span>Security & Privacy</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>Credentials are stored locally in your browser</span>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>API calls are made directly to Binance US servers</span>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>No credentials are transmitted to our servers</span>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>Trading is disabled by default for safety</span>
                  </div>
                </div>

                <Alert className="border-yellow-500/30">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  <AlertDescription className="text-yellow-400">
                    <strong>Important:</strong> Only use API keys with read-only permissions initially. 
                    Trading permissions can be enabled later in the advanced settings.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            {/* API Setup Instructions */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-6 h-6 text-primary" />
                  <span>Setup Instructions</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <strong>1. Create API Key:</strong> Log into your Binance US account and navigate to API Management
                </div>
                <div>
                  <strong>2. Set Permissions:</strong> Enable "Read Info" and optionally "Enable Trading" (for live execution)
                </div>
                <div>
                  <strong>3. IP Restrictions:</strong> Consider adding IP restrictions for enhanced security
                </div>
                <div>
                  <strong>4. Test First:</strong> Always test with read-only permissions before enabling trading
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </TabsContent>

      <TabsContent value="security" className="space-y-6">
        <SecurityDashboard />
      </TabsContent>
    </Tabs>
      </div>
    </div>
  )
}

export default ApiSettings
