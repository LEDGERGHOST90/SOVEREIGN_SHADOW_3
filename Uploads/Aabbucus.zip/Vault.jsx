import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Shield, 
  Lock, 
  Zap, 
  TrendingUp, 
  Target, 
  Repeat,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  Crown,
  FileText,
  Users,
  Globe
} from 'lucide-react'
import { motion } from 'framer-motion'

const Vault = () => {
  const [activeSection, setActiveSection] = useState('overview')

  const sections = [
    { id: 'overview', label: 'Overview', icon: Shield },
    { id: 'technical', label: 'Technical Thesis', icon: FileText },
    { id: 'architecture', label: 'Architecture', icon: Zap },
    { id: 'ip', label: 'IP & Ownership', icon: Crown }
  ]

  const technicalPrinciples = [
    {
      title: "Self-Sustaining Minimums",
      description: "Each core asset maintains a $500 floor, ensuring the engine never stops running even during market downturns.",
      icon: Shield,
      color: "text-[#6EE7FF]"
    },
    {
      title: "Dual-Route Profit Allocation",
      description: "30% of profits reinvest into core positions for compound growth, while 70% flows to USDT for opportunity capture.",
      icon: Repeat,
      color: "text-[#FF6EE7]"
    },
    {
      title: "Graduation Protocol",
      description: "Positions hitting $1.5k-$3.5k automatically transfer excess to cold storage, protecting gains while maintaining active capital.",
      icon: TrendingUp,
      color: "text-[#A3FF8F]"
    },
    {
      title: "Sniper War Chest",
      description: "USDT reserves enable rapid deployment into high-conviction opportunities without disrupting core positions.",
      icon: Target,
      color: "text-[#C084FC]"
    }
  ]

  const architectureComponents = [
    {
      layer: "Layer 1: Core Engine",
      components: ["BTC, ETH, SOL, XRP positions", "$500 minimum floors", "Automated rebalancing"],
      color: "border-[#6EE7FF]/30"
    },
    {
      layer: "Layer 2: Profit Siphon",
      components: ["30/70 allocation logic", "Real-time P&L tracking", "Automated execution"],
      color: "border-[#FF6EE7]/30"
    },
    {
      layer: "Layer 3: Graduation System",
      components: ["Threshold monitoring", "Cold storage integration", "Ledger Vault transfers"],
      color: "border-[#A3FF8F]/30"
    },
    {
      layer: "Layer 4: Sniper Module",
      components: ["USDT war chest", "Opportunity detection", "Rapid deployment"],
      color: "border-[#C084FC]/30"
    }
  ]

  return (
    <div className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="text-gradient">Vault Technology</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Deep dive into the technical architecture and intellectual property 
            behind the Sovereign Legacy Loop wealth engine.
          </p>
        </div>

        {/* Navigation */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {sections.map((section) => {
            const Icon = section.icon
            return (
              <Button
                key={section.id}
                variant={activeSection === section.id ? "default" : "outline"}
                onClick={() => setActiveSection(section.id)}
                className={`${
                  activeSection === section.id 
                    ? 'gradient-aqua-magenta text-black' 
                    : 'border-primary/30 text-primary hover:bg-primary/10'
                }`}
              >
                <Icon className="w-4 h-4 mr-2" />
                {section.label}
              </Button>
            )
          })}
        </div>

        {/* Content Sections */}
        <div className="space-y-12">
          {/* Overview */}
          {activeSection === 'overview' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-8"
            >
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="w-6 h-6 text-primary" />
                    <span>The Sovereign Legacy Loop Methodology</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    The Sovereign Legacy Loop represents a paradigm shift in cryptocurrency wealth management. 
                    Unlike traditional "buy and hold" or active trading strategies, our system creates a 
                    <span className="text-primary font-semibold"> self-perpetuating wealth engine</span> that 
                    simultaneously builds protected long-term wealth while maintaining aggressive opportunity capture capabilities.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-xl font-semibold text-[#6EE7FF]">Core Innovation</h3>
                      <ul className="space-y-2 text-muted-foreground">
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Automated profit siphoning with dual allocation</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Graduation protocol for wealth protection</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Self-sustaining minimum position floors</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Integrated sniper mode for opportunities</span>
                        </li>
                      </ul>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-xl font-semibold text-[#FF6EE7]">Key Differentiators</h3>
                      <ul className="space-y-2 text-muted-foreground">
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Never fully exits profitable positions</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Maintains liquidity for market opportunities</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Automatically protects gains in cold storage</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Scales with portfolio size and market conditions</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {technicalPrinciples.map((principle, index) => {
                  const Icon = principle.icon
                  return (
                    <Card key={index} className="glass-card hover-lift">
                      <CardContent className="p-6 text-center">
                        <div className={`w-12 h-12 rounded-full bg-gradient-to-br from-current/20 to-current/5 flex items-center justify-center mx-auto mb-4 ${principle.color}`}>
                          <Icon className={`w-6 h-6 ${principle.color}`} />
                        </div>
                        <h3 className="font-semibold mb-3">{principle.title}</h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {principle.description}
                        </p>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </motion.div>
          )}

          {/* Technical Thesis */}
          {activeSection === 'technical' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-8"
            >
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="w-6 h-6 text-primary" />
                    <span>Technical Thesis & Mathematical Foundation</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="prose prose-invert max-w-none">
                    <h3 className="text-xl font-semibold text-[#6EE7FF] mb-4">The Wealth Engine Equation</h3>
                    <p className="text-muted-foreground leading-relaxed mb-6">
                      The Sovereign Legacy Loop operates on a mathematical principle that ensures continuous wealth 
                      accumulation while maintaining operational liquidity. The core equation balances growth, 
                      protection, and opportunity capture:
                    </p>

                    <div className="glass-card p-6 rounded-lg mb-6">
                      <div className="text-center">
                        <div className="text-lg font-mono text-primary mb-2">
                          W(t+1) = W(t) + P(t) × [0.3 × R + 0.7 × S] + G(t)
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Where W = Wealth, P = Profit, R = Reinvestment, S = Sniper Capital, G = Graduation Transfer
                        </div>
                      </div>
                    </div>

                    <h3 className="text-xl font-semibold text-[#FF6EE7] mb-4">Risk Management Framework</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div className="glass p-4 rounded-lg">
                        <h4 className="font-semibold text-[#A3FF8F] mb-2">Position Risk Controls</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Minimum $500 floor prevents total position loss</li>
                          <li>• Maximum 35% allocation to any single asset</li>
                          <li>• Automatic rebalancing on 10% deviation</li>
                          <li>• Stop-loss protection at 20% below floor</li>
                        </ul>
                      </div>
                      <div className="glass p-4 rounded-lg">
                        <h4 className="font-semibold text-[#C084FC] mb-2">Liquidity Management</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Minimum 10% USDT for opportunities</li>
                          <li>• Maximum 30% USDT to prevent cash drag</li>
                          <li>• Dynamic allocation based on volatility</li>
                          <li>• Emergency liquidity reserves</li>
                        </ul>
                      </div>
                    </div>

                    <h3 className="text-xl font-semibold text-[#FFCBA4] mb-4">Graduation Algorithm</h3>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      The graduation protocol uses a sophisticated algorithm to determine optimal transfer timing:
                    </p>
                    <div className="glass-card p-4 rounded-lg">
                      <div className="font-mono text-sm text-primary">
                        {`if (position_value ≥ graduation_threshold && profit_margin ≥ 200%) {
  transfer_amount = position_value - minimum_floor
  execute_vault_transfer(transfer_amount)
  maintain_minimum_floor(asset)
}`}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Architecture */}
          {activeSection === 'architecture' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-8"
            >
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Zap className="w-6 h-6 text-primary" />
                    <span>System Architecture</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-8">
                    {architectureComponents.map((layer, index) => (
                      <div key={index} className={`glass-card p-6 border-2 ${layer.color}`}>
                        <h3 className="text-lg font-semibold mb-4">{layer.layer}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {layer.components.map((component, compIndex) => (
                            <div key={compIndex} className="flex items-center space-x-2">
                              <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                              <span className="text-sm text-muted-foreground">{component}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle className="text-lg">Security Features</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Lock className="w-5 h-5 text-[#6EE7FF]" />
                      <span className="text-sm">End-to-end encryption</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Shield className="w-5 h-5 text-[#FF6EE7]" />
                      <span className="text-sm">Hardware wallet integration</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-[#A3FF8F]" />
                      <span className="text-sm">Multi-signature support</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <AlertTriangle className="w-5 h-5 text-[#FFCBA4]" />
                      <span className="text-sm">Real-time monitoring</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle className="text-lg">Integration Points</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Globe className="w-5 h-5 text-[#6EE7FF]" />
                      <span className="text-sm">Major exchange APIs</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Zap className="w-5 h-5 text-[#FF6EE7]" />
                      <span className="text-sm">DeFi protocol connections</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Target className="w-5 h-5 text-[#C084FC]" />
                      <span className="text-sm">Price feed aggregators</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Users className="w-5 h-5 text-[#A3FF8F]" />
                      <span className="text-sm">Social trading platforms</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          )}

          {/* IP & Ownership */}
          {activeSection === 'ip' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-8"
            >
              <Card className="glass-card border-primary/50 neon-glow">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Crown className="w-6 h-6 text-primary" />
                    <span>Intellectual Property & Ownership Declaration</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center p-8 glass-card rounded-lg border border-primary/30">
                    <Crown className="w-16 h-16 text-primary mx-auto mb-4" />
                    <h2 className="text-2xl font-bold text-gradient mb-4">
                      Designed & Owned by Ray Jessee
                    </h2>
                    <h3 className="text-xl text-primary mb-4">
                      Commander LedgerGhost90
                    </h3>
                    <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                      All intellectual property, methodologies, system architecture, and proprietary algorithms 
                      contained within the Sovereign Legacy Loop are the exclusive creation and property of Ray Jessee.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-[#6EE7FF]">Protected Intellectual Property</h3>
                      <ul className="space-y-2 text-muted-foreground">
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Sovereign Legacy Loop methodology</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Dual-route profit siphon algorithm</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Graduation protocol system</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Self-sustaining minimum floor concept</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                          <span>Integrated sniper war chest architecture</span>
                        </li>
                      </ul>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-[#FF6EE7]">Rights & Protections</h3>
                      <ul className="space-y-2 text-muted-foreground">
                        <li className="flex items-start space-x-2">
                          <Shield className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                          <span>Exclusive commercial rights</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <Shield className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                          <span>Patent-pending algorithms</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <Shield className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                          <span>Trademark protections</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <Shield className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                          <span>Trade secret classifications</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <Shield className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                          <span>International IP filings</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="border-t border-white/10 pt-6">
                    <div className="flex items-start space-x-3 p-4 glass rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <p className="font-semibold text-amber-500 mb-1">Legal Notice</p>
                        <p className="text-muted-foreground leading-relaxed">
                          Any unauthorized use, reproduction, or distribution of the Sovereign Legacy Loop 
                          methodology or its components is strictly prohibited and may result in legal action. 
                          All rights reserved under applicable intellectual property laws.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="text-center">
                <h3 className="text-xl font-semibold mb-4">Licensing Opportunities</h3>
                <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                  Interested in licensing the Sovereign Legacy Loop technology for your platform or institution? 
                  Contact us to discuss partnership opportunities.
                </p>
                <Button className="gradient-aqua-magenta text-black font-semibold hover-lift">
                  Contact for Licensing
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Vault
