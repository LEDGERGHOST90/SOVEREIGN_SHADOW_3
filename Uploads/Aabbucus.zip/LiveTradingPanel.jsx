import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  AlertTriangle,
  CheckCircle,
  Zap,
  RefreshCw,
  Target,
  Shield
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import binanceService from '../services/binanceService'

const LiveTradingPanel = () => {
  const [portfolioData, setPortfolioData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [selectedAsset, setSelectedAsset] = useState('BTC')
  const [tradeType, setTradeType] = useState('BUY')
  const [tradeAmount, setTradeAmount] = useState('')
  const [isExecutingTrade, setIsExecutingTrade] = useState(false)
  const [tradeResult, setTradeResult] = useState(null)
  const [isExecutingSiphon, setIsExecutingSiphon] = useState(false)
  const [siphonResult, setSiphonResult] = useState(null)
  const [passphrase, setPassphrase] = useState('')

  useEffect(() => {
    loadPortfolioData()
    // Refresh data every 30 seconds
    const interval = setInterval(loadPortfolioData, 30000)
    return () => clearInterval(interval)
  }, [])

  const loadPortfolioData = async () => {
    try {
      setIsLoading(true)
      const corePositions = await binanceService.getCorePositions()
      setPortfolioData(corePositions)
      setError(null)
    } catch (err) {
      console.error('Failed to load portfolio data:', err)
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  const executeTrade = async () => {
    if (!tradeAmount || parseFloat(tradeAmount) <= 0) {
      setTradeResult({
        success: false,
        message: 'Please enter a valid trade amount'
      })
      return
    }

    setIsExecutingTrade(true)
    setTradeResult(null)

    try {
      const result = await binanceService.executeTrade(
        tradeType,
        selectedAsset,
        parseFloat(tradeAmount),
        'MARKET'
      )

      setTradeResult({
        success: true,
        message: `${tradeType} order executed successfully`,
        details: result
      })

      // Refresh portfolio data after trade
      setTimeout(loadPortfolioData, 2000)
    } catch (err) {
      setTradeResult({
        success: false,
        message: `Trade execution failed: ${err.message}`
      })
    } finally {
      setIsExecutingTrade(false)
    }
  }

  const executeProfitSiphon = async () => {
    if (!passphrase) {
      setSiphonResult({
        success: false,
        message: 'Please enter the daily passphrase'
      })
      return
    }

    setIsExecutingSiphon(true)
    setSiphonResult(null)

    try {
      const result = await binanceService.simulateProfitSiphon(passphrase, false)
      setSiphonResult({
        success: true,
        message: 'Profit siphon executed successfully',
        details: result
      })

      // Refresh portfolio data after siphon
      setTimeout(loadPortfolioData, 3000)
    } catch (err) {
      setSiphonResult({
        success: false,
        message: `Profit siphon failed: ${err.message}`
      })
    } finally {
      setIsExecutingSiphon(false)
    }
  }

  if (isLoading && !portfolioData) {
    return (
      <Card className="glass-card">
        <CardContent className="p-8 text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-primary" />
          <p>Loading live portfolio data...</p>
        </CardContent>
      </Card>
    )
  }

  if (error && !portfolioData) {
    return (
      <Card className="glass-card border-red-500/30">
        <CardContent className="p-8 text-center">
          <AlertTriangle className="w-8 h-8 mx-auto mb-4 text-red-400" />
          <p className="text-red-400 mb-4">Failed to connect to Binance API</p>
          <p className="text-sm text-muted-foreground mb-4">{error}</p>
          <Button onClick={loadPortfolioData} variant="outline" className="border-red-500/30">
            Retry Connection
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Live Portfolio Overview */}
      <Card className="glass-card border-green-500/30">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-6 h-6 text-green-400" />
              <span>Live Portfolio</span>
            </div>
            <Button onClick={loadPortfolioData} variant="ghost" size="sm">
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {portfolioData && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">
                  ${portfolioData.totalValue?.toFixed(2) || '0.00'}
                </div>
                <div className="text-sm text-muted-foreground">Total Value</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#6EE7FF]">
                  ${portfolioData.usdtBalance?.toFixed(2) || '0.00'}
                </div>
                <div className="text-sm text-muted-foreground">USDT War Chest</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#FF6EE7]">
                  {Object.keys(portfolioData.corePositions || {}).length}
                </div>
                <div className="text-sm text-muted-foreground">Core Assets</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#A3FF8F]">
                  {portfolioData.lastUpdated ? 'LIVE' : 'OFFLINE'}
                </div>
                <div className="text-sm text-muted-foreground">Status</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Manual Trading Panel */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-6 h-6 text-primary" />
              <span>Manual Trading</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Asset</Label>
                <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                  <SelectTrigger className="glass">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="glass-card border-white/10">
                    <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                    <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                    <SelectItem value="SOL">Solana (SOL)</SelectItem>
                    <SelectItem value="XRP">Ripple (XRP)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={tradeType} onValueChange={setTradeType}>
                  <SelectTrigger className="glass">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="glass-card border-white/10">
                    <SelectItem value="BUY">Buy</SelectItem>
                    <SelectItem value="SELL">Sell</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Amount (USD)</Label>
              <Input
                type="number"
                placeholder="Enter amount in USD"
                value={tradeAmount}
                onChange={(e) => setTradeAmount(e.target.value)}
                className="glass"
              />
            </div>

            {tradeResult && (
              <Alert className={`${tradeResult.success ? 'border-green-500/30' : 'border-red-500/30'}`}>
                <div className="flex items-center space-x-2">
                  {tradeResult.success ? 
                    <CheckCircle className="w-4 h-4 text-green-400" /> : 
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                  }
                  <AlertDescription className={tradeResult.success ? 'text-green-400' : 'text-red-400'}>
                    {tradeResult.message}
                  </AlertDescription>
                </div>
              </Alert>
            )}

            <Button
              onClick={executeTrade}
              disabled={isExecutingTrade || !tradeAmount}
              className="w-full gradient-aqua-magenta text-black font-semibold hover-lift"
            >
              {isExecutingTrade ? (
                <div className="flex items-center space-x-2">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Executing...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Zap className="w-4 h-4" />
                  <span>{tradeType} {selectedAsset}</span>
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Profit Siphon Execution */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-6 h-6 text-primary" />
              <span>Profit Siphon</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Daily Passphrase</Label>
              <Input
                type="password"
                placeholder="ΩSIGIL-COLLECT-YYYYMMDD"
                value={passphrase}
                onChange={(e) => setPassphrase(e.target.value)}
                className="glass"
              />
              <p className="text-xs text-muted-foreground">
                Use today's date in YYYYMMDD format
              </p>
            </div>

            {siphonResult && (
              <Alert className={`${siphonResult.success ? 'border-green-500/30' : 'border-red-500/30'}`}>
                <div className="flex items-center space-x-2">
                  {siphonResult.success ? 
                    <CheckCircle className="w-4 h-4 text-green-400" /> : 
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                  }
                  <AlertDescription className={siphonResult.success ? 'text-green-400' : 'text-red-400'}>
                    {siphonResult.message}
                  </AlertDescription>
                </div>
              </Alert>
            )}

            <Button
              onClick={executeProfitSiphon}
              disabled={isExecutingSiphon || !passphrase}
              className="w-full gradient-lime-orange text-black font-semibold hover-lift"
            >
              {isExecutingSiphon ? (
                <div className="flex items-center space-x-2">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Executing Siphon...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <DollarSign className="w-4 h-4" />
                  <span>Execute Profit Siphon</span>
                </div>
              )}
            </Button>

            <Alert className="border-yellow-500/30">
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
              <AlertDescription className="text-yellow-400">
                <strong>Live Trading:</strong> This will execute real trades on your Binance account. 
                Ensure you understand the risks before proceeding.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      {/* Core Positions Display */}
      {portfolioData?.corePositions && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle>Core Positions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {Object.entries(portfolioData.corePositions).map(([key, position]) => (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass-card p-4 rounded-lg"
                >
                  <div className="text-center">
                    <div className="text-lg font-bold text-primary mb-1">
                      {position.asset}
                    </div>
                    <div className="text-2xl font-bold mb-1">
                      ${position.usdValue?.toFixed(2) || '0.00'}
                    </div>
                    <div className="text-sm text-muted-foreground mb-2">
                      {position.amount?.toFixed(6) || '0'} {position.asset}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Target: ${position.target}
                    </div>
                    <div className={`text-xs ${position.usdValue >= position.target ? 'text-green-400' : 'text-yellow-400'}`}>
                      {position.usdValue >= position.target ? 'Above Target' : 'Below Target'}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default LiveTradingPanel
