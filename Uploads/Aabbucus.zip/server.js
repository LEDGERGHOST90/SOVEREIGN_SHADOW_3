// Sovereign Legacy Loop - Persistent Backend Server
// Keeps your API connections alive and data persistent

import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

// ES module compatibility
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables
dotenv.config();

// Import services (we'll need to convert these to ES modules too)
// For now, let's create a simple working version

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
    origin: ['http://localhost:5173', 'http://localhost:3000', 'https://*.manus.im'],
    credentials: true
}));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../dist')));

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        database: 'initializing',
        uptime: process.uptime(),
        message: 'Backend server is running'
    });
});

// Mock portfolio endpoint (we'll replace with real data once database is working)
app.get('/api/portfolio', (req, res) => {
    console.log('📊 Portfolio data requested');
    
    const mockData = {
        totalUsdValue: 2000 + Math.random() * 100,
        btc: 0.014 + Math.random() * 0.001,
        eth: 0.16 + Math.random() * 0.01,
        sol: 3.9 + Math.random() * 0.1,
        xrp: 550 + Math.random() * 50,
        usdt: 232 + Math.random() * 20,
        lastUpdated: new Date().toISOString(),
        isLive: false
    };
    
    res.json(mockData);
});

// Mock PnL endpoint
app.get('/api/pnl', (req, res) => {
    console.log('📈 PnL data requested');
    
    const mockPnL = [];
    const baseDate = new Date();
    baseDate.setDate(baseDate.getDate() - 14);
    
    for (let i = 0; i < 14; i++) {
        const date = new Date(baseDate);
        date.setDate(date.getDate() + i);
        
        mockPnL.push({
            date: date.toISOString().split('T')[0],
            value: 1800 + Math.random() * 400 + i * 10
        });
    }
    
    res.json(mockPnL);
});

// Credentials test endpoint
app.post('/api/credentials/test', (req, res) => {
    const { apiKey, secretKey } = req.body;
    
    if (!apiKey || !secretKey) {
        return res.status(400).json({ error: 'API key and secret key are required' });
    }
    
    console.log('🧪 Testing API credentials (mock)...');
    
    // Mock successful test
    setTimeout(() => {
        res.json({ 
            success: true, 
            message: 'Credentials tested successfully (mock mode)',
            mock: true
        });
    }, 1000);
});

// Credentials status endpoint
app.get('/api/credentials/status', (req, res) => {
    res.json({
        hasCredentials: false,
        connectionStatus: 'mock_mode',
        isLiveTradingAllowed: false,
        message: 'Running in mock mode - database initializing'
    });
});

// Siphon simulation endpoint
app.post('/api/simulate-siphon', (req, res) => {
    const { passphrase, plan } = req.body;
    
    if (!passphrase) {
        return res.status(400).json({ error: 'Passphrase is required' });
    }
    
    console.log('🌊 Siphon simulation requested (mock)');
    
    // Verify passphrase format
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const expectedPassphrase = `ΩSIGIL-COLLECT-${today}`;
    
    if (passphrase !== expectedPassphrase) {
        return res.status(400).json({ error: 'Invalid passphrase format' });
    }
    
    const totalProfit = plan?.totalProfit || 156.50;
    const coreReinvest = totalProfit * 0.3;
    const usdtWarChest = totalProfit * 0.7;
    
    res.json({
        success: true,
        simulated: true,
        liveDisabled: true,
        actions: [
            { step: 'calculate', detail: `Base USD ${totalProfit}, split 30/70` },
            { step: 'reinvest', detail: `Reinvest $${coreReinvest.toFixed(2)} to core positions` },
            { step: 'transfer', detail: `Transfer $${usdtWarChest.toFixed(2)} to USDT war chest` }
        ],
        amounts: {
            totalProfit,
            coreReinvest: coreReinvest.toFixed(2),
            usdtWarChest: usdtWarChest.toFixed(2)
        }
    });
});

// Waitlist endpoint
app.post('/api/waitlist', (req, res) => {
    const { email, useCase } = req.body;
    
    if (!email) {
        return res.status(400).json({ error: 'Email is required' });
    }
    
    console.log('📧 Waitlist signup:', email);
    res.json({ success: true, message: 'Added to waitlist successfully' });
});

// Serve React app for all other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../dist/index.html'));
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('🚨 Server error:', error);
    res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Sovereign Legacy Loop server running on port ${PORT}`);
    console.log(`📊 Mode: Mock/Development (database services loading...)`);
    console.log(`🛡️ Safety: All trading disabled (simulation mode)`);
    console.log(`🔗 Frontend: Connect to http://localhost:${PORT}`);
});

export default app;
