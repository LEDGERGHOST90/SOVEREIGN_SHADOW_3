import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { 
  ArrowRight, 
  Zap, 
  Shield, 
  Target, 
  TrendingUp, 
  Lock, 
  Repeat,
  DollarSign,
  BarChart3,
  Layers
} from 'lucide-react'
import { motion } from 'framer-motion'

const Landing = () => {
  const [currentStep, setCurrentStep] = useState(0)

  const flowSteps = [
    { icon: TrendingUp, label: "Core Positions", color: "text-[#6EE7FF]" },
    { icon: Repeat, label: "Profit Siphon", color: "text-[#FF6EE7]" },
    { icon: Target, label: "Sniper Mode", color: "text-[#C084FC]" },
    { icon: Shield, label: "Vault Transfer", color: "text-[#A3FF8F]" }
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % flowSteps.length)
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  const features = [
    {
      icon: Layers,
      title: "Core Position Management",
      description: "Maintain $500 minimum floors in BTC, ETH, SOL, XRP for stability and growth",
      color: "text-[#6EE7FF]"
    },
    {
      icon: Repeat,
      title: "Intelligent Profit Siphon",
      description: "30% reinvested into core positions, 70% flows to USDT war chest automatically",
      color: "text-[#FF6EE7]"
    },
    {
      icon: Target,
      title: "Sniper War Chest",
      description: "USDT ammunition for high-frequency meme coin flips and opportunity strikes",
      color: "text-[#C084FC]"
    },
    {
      icon: Shield,
      title: "Graduation Protocol",
      description: "Positions hitting $1.5k-$3.5k automatically transfer excess to Ledger Vault",
      color: "text-[#A3FF8F]"
    }
  ]

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-card/50"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(110,231,255,0.1),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(255,110,231,0.1),transparent_50%)]"></div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Main Headline */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-6">
              <span className="text-gradient">Sovereign Legacy Loop</span>
              <br />
              <span className="text-foreground">Self-Fueling Wealth Engine</span>
            </h1>

            {/* 12-Second Elevator Pitch */}
            <div className="max-w-4xl mx-auto mb-8">
              <p className="text-xl sm:text-2xl text-muted-foreground leading-relaxed">
                Turn trading profits into a <span className="text-[#6EE7FF] font-semibold">protected Ledger Vault</span> while 
                maintaining a live <span className="text-[#FF6EE7] font-semibold">USDT sniper war chest</span> for 
                high-frequency opportunities. <span className="text-[#A3FF8F] font-semibold">Fully automated</span>, 
                <span className="text-[#C084FC] font-semibold"> self-sustaining</span>, and designed for 
                <span className="text-gradient font-semibold"> sovereign wealth building</span>.
              </p>
            </div>

            {/* Flow Visualization */}
            <div className="flex justify-center items-center space-x-4 mb-12">
              {flowSteps.map((step, index) => {
                const Icon = step.icon
                const isActive = index === currentStep
                return (
                  <motion.div
                    key={index}
                    className={`flex flex-col items-center space-y-2 transition-all duration-500 ${
                      isActive ? 'scale-110' : 'scale-100 opacity-60'
                    }`}
                    animate={{
                      scale: isActive ? 1.1 : 1,
                      opacity: isActive ? 1 : 0.6
                    }}
                  >
                    <div className={`w-16 h-16 rounded-full glass-card flex items-center justify-center ${
                      isActive ? 'neon-glow' : ''
                    }`}>
                      <Icon className={`w-8 h-8 ${step.color}`} />
                    </div>
                    <span className={`text-sm font-medium ${step.color}`}>
                      {step.label}
                    </span>
                  </motion.div>
                )
              })}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
              <Link to="/demo">
                <Button size="lg" className="gradient-aqua-magenta text-black font-semibold hover-lift text-lg px-8 py-4">
                  Experience the Demo
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link to="/waitlist">
                <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/10 text-lg px-8 py-4">
                  Join Waitlist
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-[#6EE7FF] mb-2">$500</div>
                <div className="text-sm text-muted-foreground">Minimum Core Position</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#FF6EE7] mb-2">70%</div>
                <div className="text-sm text-muted-foreground">Profit to War Chest</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#A3FF8F] mb-2">$3.5k</div>
                <div className="text-sm text-muted-foreground">Vault Graduation</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              <span className="text-gradient">Revolutionary Architecture</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Four interconnected systems working in harmony to build and protect your wealth
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="glass-card hover-lift h-full">
                    <CardContent className="p-6">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br from-current/20 to-current/10 flex items-center justify-center mb-4 ${feature.color}`}>
                        <Icon className={`w-6 h-6 ${feature.color}`} />
                      </div>
                      <h3 className="text-lg font-semibold mb-3 text-foreground">
                        {feature.title}
                      </h3>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Monetization Preview */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="text-gradient">Coming Soon</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-12 max-w-3xl mx-auto">
            Professional-grade tools and insights for serious wealth builders
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="glass-card">
              <CardContent className="p-8 text-center">
                <DollarSign className="w-12 h-12 text-[#6EE7FF] mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">$49/mo</h3>
                <p className="text-muted-foreground">Signals & Dashboards</p>
              </CardContent>
            </Card>
            <Card className="glass-card border-primary/50">
              <CardContent className="p-8 text-center">
                <BarChart3 className="w-12 h-12 text-[#FF6EE7] mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">$149/mo</h3>
                <p className="text-muted-foreground">AI Sniper Insights</p>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="p-8 text-center">
                <Zap className="w-12 h-12 text-[#A3FF8F] mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">$499/mo</h3>
                <p className="text-muted-foreground">Institutional API</p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12">
            <Link to="/pricing">
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/10">
                View Full Pricing
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Landing
