-- Sovereign Legacy Loop - Persistent Database Schema
-- This ensures your data survives restarts and maintains state

-- API Credentials (encrypted storage)
CREATE TABLE IF NOT EXISTS api_credentials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exchange TEXT NOT NULL DEFAULT 'binance_us',
    api_key_encrypted TEXT NOT NULL,
    secret_key_encrypted TEXT NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    last_tested DATETIME,
    test_result TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Portfolio snapshots (persistent balance tracking)
CREATE TABLE IF NOT EXISTS portfolio_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_usd_value REAL,
    btc_balance REAL DEFAULT 0,
    eth_balance REAL DEFAULT 0,
    sol_balance REAL DEFAULT 0,
    xrp_balance REAL DEFAULT 0,
    usdt_balance REAL DEFAULT 0,
    snapshot_data TEXT, -- JSON blob for full data
    is_live BOOLEAN DEFAULT 0 -- 0 = mock, 1 = live data
);

-- Trading history (persistent trade log)
CREATE TABLE IF NOT EXISTS trading_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL, -- BUY/SELL
    quantity REAL NOT NULL,
    price REAL NOT NULL,
    total_usd REAL NOT NULL,
    is_simulated BOOLEAN DEFAULT 1, -- Safety: default to simulated
    trade_type TEXT DEFAULT 'manual', -- manual, siphon, rebalance
    profit_loss REAL DEFAULT 0,
    notes TEXT
);

-- Siphon operations (profit distribution tracking)
CREATE TABLE IF NOT EXISTS siphon_operations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    passphrase_used TEXT NOT NULL,
    total_profit REAL NOT NULL,
    core_reinvest_amount REAL NOT NULL,
    usdt_war_chest_amount REAL NOT NULL,
    vault_transfer_amount REAL DEFAULT 0,
    is_simulated BOOLEAN DEFAULT 1,
    operation_data TEXT, -- JSON blob for full operation details
    status TEXT DEFAULT 'completed' -- pending, completed, failed
);

-- System settings (persistent configuration)
CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Safety guardrails (multiple layers of protection)
CREATE TABLE IF NOT EXISTS safety_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    setting_name TEXT UNIQUE NOT NULL,
    is_enabled BOOLEAN DEFAULT 1,
    setting_value TEXT,
    description TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Insert default safety settings
INSERT OR REPLACE INTO safety_settings (setting_name, is_enabled, setting_value, description) VALUES
('DISABLE_LIVE_TRADING', 1, 'true', 'Master switch - prevents all live trading'),
('MAX_TRADE_USD', 1, '100', 'Maximum USD amount per trade'),
('DAILY_TRADE_LIMIT', 1, '500', 'Maximum USD trading per day'),
('REQUIRE_PASSPHRASE', 1, 'true', 'Require daily passphrase for operations'),
('SIMULATION_MODE', 1, 'true', 'Force simulation mode for all operations'),
('API_RATE_LIMIT', 1, '10', 'Max API calls per minute');

-- Insert default system settings
INSERT OR REPLACE INTO system_settings (key, value, description) VALUES
('app_version', '1.0.0', 'Current application version'),
('last_startup', datetime('now'), 'Last application startup time'),
('database_initialized', 'true', 'Database setup completed'),
('encryption_key_set', 'false', 'Whether encryption key is configured');
