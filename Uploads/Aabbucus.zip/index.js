export default function Welcome() {
  return (
    <main className="max-w-6xl mx-auto p-8">
      <h1 className="text-4xl font-bold neon-text">Welcome to the Sovereign Legacy Loop</h1>
      <p className="mt-4 text-slate-300">This page features moving graphics and an interactive overview.</p>
      <div className="glass-card h-64 mt-8 flex items-center justify-center ripple">
        <span className="text-slate-200">Animated hero / moving graphics placeholder</span>
      </div>
    </main>
  );
}
