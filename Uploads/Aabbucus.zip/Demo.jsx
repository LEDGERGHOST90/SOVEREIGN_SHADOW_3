import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Play, 
  Pause, 
  RotateCcw, 
  TrendingUp, 
  Target, 
  Shield, 
  Repeat,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Zap
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import LiveTradingPanel from '../components/LiveTradingPanel'
import LiveDashboard from '../components/LiveDashboard'
import { simulateSiphon } from '../api/portfolio'

const Demo = () => {
  const [isSimulating, setIsSimulating] = useState(false)
  const [passphrase, setPassphrase] = useState('')
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [simulationStep, setSimulationStep] = useState(0)
  const [simulationResult, setSimulationResult] = useState(null)

  // Mock portfolio data for engine diagram
  const [portfolio, setPortfolio] = useState({
    btc: { amount: 630, target: 500, percentage: 31 },
    eth: { amount: 407, target: 500, percentage: 20 },
    sol: { amount: 393, target: 500, percentage: 19 },
    xrp: { amount: 392, target: 500, percentage: 19 },
    usdt: { amount: 232, target: 0, percentage: 11 }
  })

  const [vaultBalance, setVaultBalance] = useState(15420)
  const [totalProfit, setTotalProfit] = useState(1247)

  const handlePassphraseSubmit = async () => {
    try {
      const result = await simulateSiphon(passphrase, true)
      setIsAuthenticated(true)
      setSimulationResult(result)
    } catch (error) {
      alert(`Authentication failed: ${error.message}`)
    }
  }

  const startSimulation = async () => {
    if (!isAuthenticated) return
    setIsSimulating(true)
    setSimulationStep(0)
    
    try {
      const result = await simulateSiphon(passphrase, false)
      setSimulationResult(result)
      
      // Simulate the siphon process steps
      const interval = setInterval(() => {
        setSimulationStep(prev => {
          if (prev >= 4) {
            setIsSimulating(false)
            clearInterval(interval)
            return 0
          }
          return prev + 1
        })
      }, 2000)
    } catch (error) {
      setIsSimulating(false)
      alert(`Simulation failed: ${error.message}`)
    }
  }

  const resetSimulation = () => {
    setIsSimulating(false)
    setSimulationStep(0)
    setIsAuthenticated(false)
    setPassphrase('')
    setSimulationResult(null)
    setPortfolio({
      btc: { amount: 630, target: 500, percentage: 31 },
      eth: { amount: 407, target: 500, percentage: 20 },
      sol: { amount: 393, target: 500, percentage: 19 },
      xrp: { amount: 392, target: 500, percentage: 19 },
      usdt: { amount: 232, target: 0, percentage: 11 }
    })
  }

  const simulationSteps = [
    "Analyzing portfolio positions...",
    "Calculating profit siphon (30% core / 70% USDT)...",
    "Executing rebalancing trades...",
    "Checking graduation thresholds...",
    "Simulation complete!"
  ]

  return (
    <div className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="text-gradient">Interactive Demo</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the Sovereign Legacy Loop in action. See how the profit siphon, 
            graduation protocol, and live trading work together.
          </p>
        </div>

        <Tabs defaultValue="engine" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 glass-card">
            <TabsTrigger value="engine">Engine Diagram</TabsTrigger>
            <TabsTrigger value="siphon">Siphon Console</TabsTrigger>
            <TabsTrigger value="trading">Live Trading</TabsTrigger>
            <TabsTrigger value="dashboard">Live Dashboard</TabsTrigger>
          </TabsList>

          {/* Engine Diagram */}
          <TabsContent value="engine" className="space-y-6">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Repeat className="w-6 h-6 text-primary" />
                  <span>Sovereign Legacy Loop Flow</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                  {/* Core Positions */}
                  <motion.div 
                    className="glass-card p-6 text-center hover-lift"
                    whileHover={{ scale: 1.02 }}
                  >
                    <TrendingUp className="w-12 h-12 text-[#6EE7FF] mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Core Positions</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      BTC, ETH, SOL, XRP with $500 minimum floors
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>BTC:</span>
                        <span className="text-[#6EE7FF]">$630</span>
                      </div>
                      <div className="flex justify-between">
                        <span>ETH:</span>
                        <span className="text-[#FF6EE7]">$407</span>
                      </div>
                      <div className="flex justify-between">
                        <span>SOL:</span>
                        <span className="text-[#C084FC]">$393</span>
                      </div>
                      <div className="flex justify-between">
                        <span>XRP:</span>
                        <span className="text-[#A3FF8F]">$392</span>
                      </div>
                    </div>
                  </motion.div>

                  {/* Profit Siphon */}
                  <motion.div 
                    className="glass-card p-6 text-center hover-lift"
                    whileHover={{ scale: 1.02 }}
                  >
                    <Target className="w-12 h-12 text-[#FF6EE7] mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Profit Siphon</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      30% reinvested, 70% to USDT war chest
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>Reinvest:</span>
                        <span className="text-[#FF6EE7]">30%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>War Chest:</span>
                        <span className="text-[#6EE7FF]">70%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Daily Trigger:</span>
                        <span className="text-[#A3FF8F]">Auto</span>
                      </div>
                    </div>
                  </motion.div>

                  {/* Graduation Protocol */}
                  <motion.div 
                    className="glass-card p-6 text-center hover-lift"
                    whileHover={{ scale: 1.02 }}
                  >
                    <Shield className="w-12 h-12 text-[#A3FF8F] mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Graduation</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Assets graduate to vault at 3x floor
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>Threshold:</span>
                        <span className="text-[#A3FF8F]">$1,500</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Next:</span>
                        <span className="text-[#FFCBA4]">BTC</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Progress:</span>
                        <span className="text-[#FF6EE7]">42%</span>
                      </div>
                    </div>
                  </motion.div>

                  {/* Vault */}
                  <motion.div 
                    className="glass-card p-6 text-center hover-lift"
                    whileHover={{ scale: 1.02 }}
                  >
                    <DollarSign className="w-12 h-12 text-[#FFCBA4] mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Vault</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Graduated assets compound independently
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>Balance:</span>
                        <span className="text-[#FFCBA4]">$15,420</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Growth:</span>
                        <span className="text-[#A3FF8F]">+8.7%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Assets:</span>
                        <span className="text-[#6EE7FF]">3</span>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Siphon Console */}
          <TabsContent value="siphon" className="space-y-6">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="w-6 h-6 text-primary" />
                  <span>Profit Siphon Console</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {!isAuthenticated ? (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="passphrase">Daily Passphrase</Label>
                      <Input
                        id="passphrase"
                        type="password"
                        placeholder="ΩSIGIL-COLLECT-YYYYMMDD"
                        value={passphrase}
                        onChange={(e) => setPassphrase(e.target.value)}
                        className="glass"
                      />
                      <p className="text-xs text-muted-foreground">
                        Use today's date: ΩSIGIL-COLLECT-{new Date().toISOString().slice(0, 10).replace(/-/g, '')}
                      </p>
                    </div>
                    <Button 
                      onClick={handlePassphraseSubmit}
                      className="w-full gradient-aqua-magenta text-black font-semibold hover-lift"
                      disabled={!passphrase}
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      Authenticate
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="flex items-center space-x-2 text-green-400">
                      <CheckCircle className="w-5 h-5" />
                      <span>Authentication successful</span>
                    </div>

                    {simulationResult && (
                      <Card className="glass border-green-500/30">
                        <CardHeader>
                          <CardTitle className="text-lg">Simulation Preview</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {simulationResult.actions?.map((action, index) => (
                              <div key={index} className="flex items-center justify-between p-3 glass rounded-lg">
                                <span className="text-sm">{action.description}</span>
                                <span className="text-sm font-semibold text-primary">
                                  ${action.amount?.toFixed(2) || 'N/A'}
                                </span>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    <div className="flex space-x-3">
                      <Button 
                        onClick={startSimulation}
                        disabled={isSimulating}
                        className="flex-1 gradient-lime-orange text-black font-semibold hover-lift"
                      >
                        {isSimulating ? (
                          <div className="flex items-center space-x-2">
                            <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                            <span>Executing...</span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-2">
                            <Play className="w-4 h-4" />
                            <span>Start Simulation</span>
                          </div>
                        )}
                      </Button>
                      <Button 
                        onClick={resetSimulation}
                        variant="outline"
                        className="border-primary/30"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Reset
                      </Button>
                    </div>

                    {isSimulating && (
                      <Card className="glass-card border-yellow-500/30">
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-6 h-6 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin"></div>
                            <span className="text-yellow-400">
                              {simulationSteps[simulationStep] || "Processing..."}
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Live Trading */}
          <TabsContent value="trading" className="space-y-6">
            <LiveTradingPanel />
          </TabsContent>

          {/* Live Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            <LiveDashboard />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default Demo
