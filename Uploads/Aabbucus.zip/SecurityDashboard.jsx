import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Switch } from '@/components/ui/switch'
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Settings,
  DollarSign,
  Clock,
  TrendingDown,
  TrendingUp,
  Eye,
  Lock,
  Activity
} from 'lucide-react'
import { motion } from 'framer-motion'
import securityManager from '../utils/security'
import { getPortfolioData } from '../api/portfolio'

const SecurityDashboard = () => {
  const [securitySettings, setSecuritySettings] = useState({})
  const [portfolioRisk, setPortfolioRisk] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [tempSettings, setTempSettings] = useState({})

  useEffect(() => {
    loadSecurityData()
  }, [])

  const loadSecurityData = async () => {
    try {
      setIsLoading(true)
      
      // Load security settings
      const settings = securityManager.getSecuritySettings()
      setSecuritySettings(settings)
      setTempSettings(settings)

      // Load portfolio data and assess risk
      const portfolioData = await getPortfolioData()
      const riskAssessment = securityManager.assessPortfolioRisk(portfolioData)
      setPortfolioRisk(riskAssessment)

    } catch (error) {
      console.error('Failed to load security data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSettingChange = (key, value) => {
    setTempSettings(prev => ({ ...prev, [key]: value }))
  }

  const saveSettings = async () => {
    setIsSaving(true)
    try {
      securityManager.updateSecuritySettings(tempSettings)
      setSecuritySettings(tempSettings)
      
      // Show success message
      setTimeout(() => {
        setIsSaving(false)
      }, 1000)
    } catch (error) {
      console.error('Failed to save settings:', error)
      setIsSaving(false)
    }
  }

  const resetToDefaults = () => {
    const defaults = {
      maxTradeAmount: 1000,
      dailyTradeLimit: 5000,
      tradingCooldown: 30000
    }
    setTempSettings(defaults)
  }

  const getRiskColor = (level) => {
    switch (level) {
      case 'HIGH': return 'text-red-400 border-red-500/30'
      case 'MEDIUM': return 'text-yellow-400 border-yellow-500/30'
      case 'LOW': return 'text-green-400 border-green-500/30'
      default: return 'text-muted-foreground border-white/10'
    }
  }

  const getRiskIcon = (level) => {
    switch (level) {
      case 'HIGH': return <AlertTriangle className="w-6 h-6 text-red-400" />
      case 'MEDIUM': return <Eye className="w-6 h-6 text-yellow-400" />
      case 'LOW': return <CheckCircle className="w-6 h-6 text-green-400" />
      default: return <Shield className="w-6 h-6 text-muted-foreground" />
    }
  }

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardContent className="p-8 text-center">
          <Shield className="w-8 h-8 animate-pulse mx-auto mb-4 text-primary" />
          <p>Loading security dashboard...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Security Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-card border-green-500/30">
          <CardContent className="p-6 text-center">
            <DollarSign className="w-8 h-8 mx-auto mb-2 text-green-400" />
            <div className="text-2xl font-bold text-green-400">
              ${securitySettings.remainingDailyLimit?.toFixed(0) || '0'}
            </div>
            <div className="text-sm text-muted-foreground">Daily Limit Remaining</div>
            <div className="text-xs text-green-400">
              ${securitySettings.dailyTradeVolume?.toFixed(0) || '0'} used today
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-[#6EE7FF]/30">
          <CardContent className="p-6 text-center">
            <Lock className="w-8 h-8 mx-auto mb-2 text-[#6EE7FF]" />
            <div className="text-2xl font-bold text-[#6EE7FF]">
              ${securitySettings.maxTradeAmount || '0'}
            </div>
            <div className="text-sm text-muted-foreground">Max Trade Amount</div>
            <div className="text-xs text-[#6EE7FF]">Per transaction limit</div>
          </CardContent>
        </Card>

        <Card className="glass-card border-[#FF6EE7]/30">
          <CardContent className="p-6 text-center">
            <Clock className="w-8 h-8 mx-auto mb-2 text-[#FF6EE7]" />
            <div className="text-2xl font-bold text-[#FF6EE7]">
              {(securitySettings.tradingCooldown / 1000) || '0'}s
            </div>
            <div className="text-sm text-muted-foreground">Trading Cooldown</div>
            <div className="text-xs text-[#FF6EE7]">Between trades</div>
          </CardContent>
        </Card>

        <Card className={`glass-card ${portfolioRisk ? getRiskColor(portfolioRisk.riskLevel) : 'border-white/10'}`}>
          <CardContent className="p-6 text-center">
            {portfolioRisk && getRiskIcon(portfolioRisk.riskLevel)}
            <div className="text-2xl font-bold mt-2">
              {portfolioRisk?.riskLevel || 'UNKNOWN'}
            </div>
            <div className="text-sm text-muted-foreground">Portfolio Risk</div>
            <div className="text-xs">
              {portfolioRisk?.risks.length || 0} risks, {portfolioRisk?.warnings.length || 0} warnings
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Security Settings */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="w-6 h-6 text-primary" />
              <span>Security Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>Maximum Trade Amount (USD)</Label>
              <Input
                type="number"
                value={tempSettings.maxTradeAmount || ''}
                onChange={(e) => handleSettingChange('maxTradeAmount', parseFloat(e.target.value))}
                className="glass"
                placeholder="1000"
              />
              <p className="text-xs text-muted-foreground">
                Maximum amount allowed per single trade
              </p>
            </div>

            <div className="space-y-2">
              <Label>Daily Trade Limit (USD)</Label>
              <Input
                type="number"
                value={tempSettings.dailyTradeLimit || ''}
                onChange={(e) => handleSettingChange('dailyTradeLimit', parseFloat(e.target.value))}
                className="glass"
                placeholder="5000"
              />
              <p className="text-xs text-muted-foreground">
                Maximum total trading volume per day
              </p>
            </div>

            <div className="space-y-2">
              <Label>Trading Cooldown (seconds)</Label>
              <Input
                type="number"
                value={(tempSettings.tradingCooldown / 1000) || ''}
                onChange={(e) => handleSettingChange('tradingCooldown', parseFloat(e.target.value) * 1000)}
                className="glass"
                placeholder="30"
              />
              <p className="text-xs text-muted-foreground">
                Minimum time between consecutive trades
              </p>
            </div>

            <div className="flex space-x-3">
              <Button
                onClick={saveSettings}
                disabled={isSaving}
                className="flex-1 gradient-aqua-magenta text-black font-semibold hover-lift"
              >
                {isSaving ? 'Saving...' : 'Save Settings'}
              </Button>
              <Button
                onClick={resetToDefaults}
                variant="outline"
                className="border-primary/30"
              >
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Risk Assessment */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-6 h-6 text-primary" />
              <span>Risk Assessment</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {portfolioRisk ? (
              <>
                <div className={`p-4 rounded-lg border ${getRiskColor(portfolioRisk.riskLevel)}`}>
                  <div className="flex items-center space-x-2 mb-2">
                    {getRiskIcon(portfolioRisk.riskLevel)}
                    <span className="font-semibold">
                      Risk Level: {portfolioRisk.riskLevel}
                    </span>
                  </div>
                </div>

                {portfolioRisk.risks.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-red-400 flex items-center space-x-2">
                      <AlertTriangle className="w-4 h-4" />
                      <span>High Risk Issues</span>
                    </h4>
                    {portfolioRisk.risks.map((risk, index) => (
                      <Alert key={index} className="border-red-500/30">
                        <AlertDescription className="text-red-400">
                          {risk}
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                )}

                {portfolioRisk.warnings.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-yellow-400 flex items-center space-x-2">
                      <Eye className="w-4 h-4" />
                      <span>Warnings</span>
                    </h4>
                    {portfolioRisk.warnings.map((warning, index) => (
                      <Alert key={index} className="border-yellow-500/30">
                        <AlertDescription className="text-yellow-400">
                          {warning}
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                )}

                {portfolioRisk.risks.length === 0 && portfolioRisk.warnings.length === 0 && (
                  <Alert className="border-green-500/30">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <AlertDescription className="text-green-400">
                      Portfolio risk assessment looks good. No major issues detected.
                    </AlertDescription>
                  </Alert>
                )}
              </>
            ) : (
              <div className="text-center text-muted-foreground">
                <Activity className="w-8 h-8 mx-auto mb-2" />
                <p>Risk assessment unavailable</p>
                <p className="text-sm">Portfolio data required for analysis</p>
              </div>
            )}

            <Button
              onClick={loadSecurityData}
              variant="outline"
              className="w-full border-primary/30"
            >
              Refresh Risk Assessment
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Security Guidelines */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Security Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold text-primary">Trading Security</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span>Start with small trade amounts to test the system</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span>Set conservative daily limits initially</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span>Use trading cooldowns to prevent emotional decisions</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span>Monitor portfolio risk levels regularly</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold text-primary">API Security</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span>Use API keys with minimal required permissions</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span>Enable IP restrictions on your exchange account</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span>Regularly rotate API keys for enhanced security</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span>Never share API credentials with third parties</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default SecurityDashboard
