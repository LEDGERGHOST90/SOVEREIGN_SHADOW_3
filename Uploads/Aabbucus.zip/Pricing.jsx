import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Check, 
  Star, 
  Zap, 
  BarChart3, 
  DollarSign,
  Shield,
  Target,
  TrendingUp,
  Users,
  Crown
} from 'lucide-react'
import { motion } from 'framer-motion'

const Pricing = () => {
  const [billingCycle, setBillingCycle] = useState('monthly')

  const plans = [
    {
      name: "Signals",
      price: { monthly: 49, yearly: 490 },
      description: "Essential signals and dashboards for individual traders",
      icon: DollarSign,
      color: "text-[#6EE7FF]",
      gradient: "from-[#6EE7FF]/20 to-[#6EE7FF]/5",
      features: [
        "Real-time portfolio dashboard",
        "Basic profit siphon alerts",
        "Core position monitoring",
        "USDT war chest tracking",
        "Email notifications",
        "Mobile-responsive interface",
        "Basic support"
      ],
      limitations: [
        "No AI insights",
        "Limited to 1 portfolio",
        "Basic alerts only"
      ]
    },
    {
      name: "AI Sniper",
      price: { monthly: 149, yearly: 1490 },
      description: "Advanced AI-powered insights and sniper logic",
      icon: BarChart3,
      color: "text-[#FF6EE7]",
      gradient: "from-[#FF6EE7]/20 to-[#FF6EE7]/5",
      popular: true,
      features: [
        "Everything in Signals",
        "AI-powered market analysis",
        "Smart sniper recommendations",
        "Graduation threshold optimization",
        "Advanced profit siphon logic",
        "Meme coin opportunity alerts",
        "Risk assessment tools",
        "Priority support",
        "Custom alert rules",
        "Portfolio optimization suggestions"
      ],
      limitations: [
        "Limited to 3 portfolios",
        "No API access"
      ]
    },
    {
      name: "Institutional",
      price: { monthly: 499, yearly: 4990 },
      description: "Full API access and institutional-grade features",
      icon: Zap,
      color: "text-[#A3FF8F]",
      gradient: "from-[#A3FF8F]/20 to-[#A3FF8F]/5",
      features: [
        "Everything in AI Sniper",
        "Full REST API access",
        "Webhook integrations",
        "Custom dashboard creation",
        "Multi-exchange support",
        "Advanced backtesting tools",
        "White-label options",
        "Dedicated account manager",
        "Custom integrations",
        "Unlimited portfolios",
        "Real-time data feeds",
        "Advanced analytics"
      ],
      limitations: []
    }
  ]

  const enterprise = {
    name: "Enterprise",
    description: "Custom solutions for institutions and large-scale operations",
    features: [
      "Custom licensing agreements",
      "On-premise deployment options",
      "Dedicated infrastructure",
      "Custom feature development",
      "24/7 premium support",
      "Compliance assistance",
      "Training and onboarding"
    ]
  }

  return (
    <div className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="text-gradient">Pricing Plans</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Choose the perfect plan for your wealth-building journey. 
            All plans include the core Sovereign Legacy Loop methodology.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className={`text-sm ${billingCycle === 'monthly' ? 'text-foreground' : 'text-muted-foreground'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
              className={`relative w-14 h-7 rounded-full transition-colors ${
                billingCycle === 'yearly' ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <div className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-transform ${
                billingCycle === 'yearly' ? 'translate-x-8' : 'translate-x-1'
              }`}></div>
            </button>
            <span className={`text-sm ${billingCycle === 'yearly' ? 'text-foreground' : 'text-muted-foreground'}`}>
              Yearly
            </span>
            {billingCycle === 'yearly' && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                Save 17%
              </Badge>
            )}
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => {
            const Icon = plan.icon
            const price = billingCycle === 'monthly' ? plan.price.monthly : plan.price.yearly
            const savings = billingCycle === 'yearly' ? (plan.price.monthly * 12 - plan.price.yearly) : 0

            return (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative"
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground px-4 py-1">
                      <Star className="w-3 h-3 mr-1" />
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <Card className={`glass-card hover-lift h-full ${
                  plan.popular ? 'border-primary/50 neon-glow' : ''
                }`}>
                  <CardHeader className="text-center pb-4">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${plan.gradient} flex items-center justify-center mx-auto mb-4`}>
                      <Icon className={`w-8 h-8 ${plan.color}`} />
                    </div>
                    <CardTitle className="text-2xl mb-2">{plan.name}</CardTitle>
                    <p className="text-muted-foreground text-sm mb-4">{plan.description}</p>
                    
                    <div className="space-y-2">
                      <div className="text-4xl font-bold">
                        ${price}
                        <span className="text-lg text-muted-foreground font-normal">
                          /{billingCycle === 'monthly' ? 'mo' : 'yr'}
                        </span>
                      </div>
                      {billingCycle === 'yearly' && savings > 0 && (
                        <div className="text-sm text-green-400">
                          Save ${savings}/year
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-6">
                    <div className="space-y-3">
                      {plan.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-start space-x-3">
                          <Check className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>

                    {plan.limitations.length > 0 && (
                      <div className="border-t border-white/10 pt-4">
                        <div className="text-xs text-muted-foreground mb-2">Limitations:</div>
                        <div className="space-y-1">
                          {plan.limitations.map((limitation, limitIndex) => (
                            <div key={limitIndex} className="text-xs text-muted-foreground">
                              • {limitation}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <Link to="/waitlist" className="block">
                      <Button 
                        className={`w-full ${
                          plan.popular 
                            ? 'gradient-aqua-magenta text-black font-semibold' 
                            : 'border-primary text-primary hover:bg-primary/10'
                        }`}
                        variant={plan.popular ? 'default' : 'outline'}
                      >
                        Join Waitlist
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>

        {/* Enterprise Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card className="glass-card border-[#C084FC]/30">
            <CardContent className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#C084FC]/20 to-[#C084FC]/5 flex items-center justify-center">
                      <Crown className="w-6 h-6 text-[#C084FC]" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">{enterprise.name}</h3>
                      <p className="text-muted-foreground">{enterprise.description}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {enterprise.features.map((feature, index) => (
                      <div key={index} className="flex items-start space-x-2">
                        <Check className="w-4 h-4 text-[#C084FC] mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="text-center lg:text-right">
                  <div className="text-3xl font-bold mb-2">Custom Pricing</div>
                  <p className="text-muted-foreground mb-6">
                    Tailored solutions for your specific needs and scale
                  </p>
                  <Button 
                    size="lg" 
                    className="gradient-violet-lime text-black font-semibold hover-lift"
                  >
                    Contact Sales
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* FAQ Section */}
        <div className="mt-24 text-center">
          <h2 className="text-3xl font-bold mb-8">
            <span className="text-gradient">Frequently Asked Questions</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="glass-card text-left">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">When will the platform launch?</h3>
                <p className="text-sm text-muted-foreground">
                  We're currently in development with a planned beta launch in Q2 2024. 
                  Waitlist members get priority access and early-bird pricing.
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card text-left">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Is my data secure?</h3>
                <p className="text-sm text-muted-foreground">
                  Absolutely. We use bank-grade encryption and never store your private keys. 
                  All data is encrypted at rest and in transit.
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card text-left">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Can I cancel anytime?</h3>
                <p className="text-sm text-muted-foreground">
                  Yes, all subscriptions can be cancelled at any time. 
                  No long-term contracts or cancellation fees.
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card text-left">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Do you offer refunds?</h3>
                <p className="text-sm text-muted-foreground">
                  We offer a 30-day money-back guarantee for all plans. 
                  If you're not satisfied, we'll refund your payment.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Pricing
