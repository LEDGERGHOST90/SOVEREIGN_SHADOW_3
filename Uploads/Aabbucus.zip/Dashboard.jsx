import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { 
  Grid3X3, 
  Home, 
  Star, 
  Sparkles, 
  CreditCard, 
  Settings, 
  Folder,
  TrendingUp,
  Shield,
  CheckCircle,
  AlertTriangle,
  Circle
} from 'lucide-react';

const Dashboard = () => {
  const [portfolioData, setPortfolioData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch real portfolio data from backend
  useEffect(() => {
    const fetchPortfolioData = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/portfolio');
        const data = await response.json();
        setPortfolioData(data);
      } catch (error) {
        console.error('Error fetching portfolio:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPortfolioData();
    const interval = setInterval(fetchPortfolioData, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  // Asset allocation data
  const assetAllocation = [
    { name: 'BTC', value: 37, color: '#F7931A' },
    { name: 'SOL', value: 21, color: '#9945FF' },
    { name: 'ETH', value: 20, color: '#627EEA' },
    { name: 'XRP', value: 20, color: '#23292F' },
    { name: 'UST', value: 1, color: '#5493F7' }
  ];

  // Staking yields data
  const stakingData = [
    { month: 'Jan', yield: 22 },
    { month: 'Feb', yield: 25 },
    { month: 'Mar', yield: 28 },
    { month: 'Apr', yield: 24 },
    { month: 'May', yield: 26 },
    { month: 'Jun', yield: 25 }
  ];

  // Asset allocation chart data
  const allocationChart = [
    { name: 'BTC', value: 85, color: '#F7931A' },
    { name: 'XRP', value: 72, color: '#23292F' },
    { name: 'IT', value: 45, color: '#627EEA' },
    { name: 'TRACE', value: 38, color: '#9945FF' },
    { name: 'O', value: 25, color: '#5493F7' }
  ];

  const totalWealth = portfolioData ? portfolioData.totalUsdValue : 7715.32;
  const flipEngineBalance = totalWealth * 0.26; // ~26% in flip engine
  const vaultBalance = totalWealth * 0.74; // ~74% in vault

  const sidebarItems = [
    { icon: Grid3X3, active: true },
    { icon: Home, active: false },
    { icon: Star, active: false },
    { icon: Sparkles, active: false },
    { icon: CreditCard, active: false },
    { icon: Settings, active: false },
    { icon: Folder, active: false }
  ];

  const systemInsights = [
    { id: 1, text: "Allocation Mismatch", status: "error", type: "HODL Disciplines (5)" },
    { id: 2, text: "SOL Discrepancy", status: "success", type: "Hardware Security" },
    { id: 4, text: "No Formal Siphon Rules", status: "error", type: "Profit Extraction" },
    { id: 5, text: "Unrealistic Targets", status: "warning", type: "Staking Yields" }
  ];

  const handleManualSiphon = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/simulate-siphon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          passphrase: `ΩSIGIL-COLLECT-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}`,
          plan: { totalProfit: 1500 }
        })
      });
      const result = await response.json();
      console.log('Siphon result:', result);
    } catch (error) {
      console.error('Siphon error:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Main Container with Gold Border */}
      <div className="h-screen p-4">
        <div className="h-full border border-yellow-600/30 rounded-lg flex">
          
          {/* Sidebar */}
          <div className="w-16 border-r border-yellow-600/30 flex flex-col items-center py-6 space-y-6">
            {sidebarItems.map((item, index) => (
              <button
                key={index}
                className={`p-2 rounded-lg transition-colors ${
                  item.active 
                    ? 'bg-yellow-600/20 text-yellow-400' 
                    : 'text-gray-400 hover:text-white hover:bg-gray-800'
                }`}
              >
                <item.icon size={20} />
              </button>
            ))}
            
            <div className="flex-1" />
            
            <button className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800">
              <Settings size={20} />
            </button>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6">
            
            {/* Header */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <div className="text-gray-400 text-sm mb-1">Total Wealth</div>
                <div className="text-4xl font-bold">${totalWealth.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                <div className="text-green-400 text-sm flex items-center mt-1">
                  Capital Flow <TrendingUp size={14} className="ml-1" />
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">The Legacy Loop</div>
                <div className="text-gray-400 text-sm">FOR MY USE ONLY</div>
                <div className="text-gray-400 text-sm">HIGHLY CUSTOMIZABLE</div>
              </div>
            </div>

            {/* Two-Tier System */}
            <div className="grid grid-cols-2 gap-6 mb-6">
              
              {/* Tier 1: Flip Engine */}
              <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Tier 1: Flip Engine (Binance)</h3>
                  <button className="w-4 h-4 border border-gray-600 rounded"></button>
                </div>
                
                <div className="mb-4">
                  <div className="text-2xl font-bold">${flipEngineBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                  <div className="text-gray-400 text-sm">Volatility Capture</div>
                </div>

                {/* Mini Chart */}
                <div className="h-16 mb-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={stakingData}>
                      <Line type="monotone" dataKey="yield" stroke="#6EE7FF" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Current Balance</span>
                    <div className="flex items-center">
                      <span className="text-green-400 mr-2">+2.3%</span>
                      <Circle size={8} className="fill-current text-white" />
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Tsilliegy Controls</span>
                    <Circle size={8} className="fill-current text-white" />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Strategy Controls</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Self-Replenish Threshold:</span>
                    <span>1%</span>
                  </div>
                </div>
              </div>

              {/* Tier 2: Vault Tracker */}
              <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Tier 2: Vault Tracker (Ledger)</h3>
                  <button className="text-gray-400">↓</button>
                </div>
                
                <div className="mb-4">
                  <div className="text-gray-400 text-sm mb-1">Current Balance</div>
                  <div className="text-2xl font-bold">${vaultBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                  <div className="text-gray-400 text-xs">Hardware Wallet Connected (Native SegWit)</div>
                </div>

                <div className="mb-4">
                  <div className="text-gray-400 text-sm mb-2">Asset Allocation & 65% & Yield</div>
                  <div className="text-xs text-gray-500 mb-2">4.5% APY</div>
                  
                  {/* Asset Allocation Chart */}
                  <div className="h-16">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={allocationChart}>
                        <Bar dataKey="value" fill="#6EE7FF" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="mb-4">
                  <h4 className="text-sm font-semibold mb-2">Siphon Rules</h4>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400 text-sm">Monthly</span>
                    <Circle size={8} className="fill-current text-white" />
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400 text-xs">AUTOMATIC SIPHON</span>
                    <Circle size={8} className="fill-current text-white" />
                  </div>
                  <div className="text-right text-sm">
                    <div className="text-gray-400">Staking Yields: $25.15/month</div>
                  </div>
                </div>

                {/* Mini Yield Chart */}
                <div className="h-12">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={stakingData}>
                      <Line type="monotone" dataKey="yield" stroke="#6EE7FF" strokeWidth={1} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Bottom Section */}
            <div className="grid grid-cols-2 gap-6">
              
              {/* Asset Allocation */}
              <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Asset Allocation</h3>
                  <button className="w-4 h-4 border border-gray-600 rounded"></button>
                </div>

                <div className="flex items-center justify-center mb-4">
                  <div className="w-32 h-32">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={assetAllocation}
                          cx="50%"
                          cy="50%"
                          innerRadius={30}
                          outerRadius={60}
                          dataKey="value"
                        >
                          {assetAllocation.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                  <div className="flex items-center"><div className="w-3 h-3 bg-orange-500 rounded mr-2"></div>BTC (37%)</div>
                  <div className="flex items-center"><div className="w-3 h-3 bg-gray-600 rounded mr-2"></div>XRP 20%</div>
                  <div className="flex items-center"><div className="w-3 h-3 bg-purple-500 rounded mr-2"></div>SOL (21%)</div>
                  <div className="flex items-center"><div className="w-3 h-3 bg-gray-600 rounded mr-2"></div>XRP 4%</div>
                  <div className="flex items-center"><div className="w-3 h-3 bg-blue-500 rounded mr-2"></div>ETH (20%) 20%</div>
                  <div className="flex items-center"><div className="w-3 h-3 bg-blue-400 rounded mr-2"></div>UST (1%)</div>
                </div>

                <div className="border-t border-gray-700 pt-4">
                  <div className="text-gray-400 text-sm mb-2">Target Monthly Extraction:</div>
                  <div className="text-xl font-bold mb-1">$1,500</div>
                  <div className="text-red-400 text-xs mb-3">UNREALISTIC (82% required)</div>
                  
                  <button 
                    onClick={handleManualSiphon}
                    className="w-full bg-yellow-600 hover:bg-yellow-700 text-black font-semibold py-2 px-4 rounded transition-colors"
                  >
                    MANUAL SIPHON TO VAULT
                  </button>
                </div>
              </div>

              {/* System Insights */}
              <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">System Insights</h3>
                  <button className="w-4 h-4 border border-gray-600 rounded"></button>
                </div>

                <div className="space-y-3">
                  {systemInsights.map((insight) => (
                    <div key={insight.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className={`text-sm mr-2 ${
                          insight.status === 'error' ? 'text-red-400' : 
                          insight.status === 'success' ? 'text-green-400' : 
                          'text-yellow-400'
                        }`}>
                          {insight.id}.
                        </span>
                        <span className={`text-sm ${
                          insight.status === 'error' ? 'text-red-400' : 
                          insight.status === 'success' ? 'text-green-400' : 
                          'text-yellow-400'
                        }`}>
                          {insight.text}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className={`text-xs ${
                          insight.status === 'error' ? 'text-red-400' : 
                          insight.status === 'success' ? 'text-green-400' : 
                          'text-yellow-400'
                        }`}>
                          {insight.type}
                        </div>
                        {insight.status === 'success' && <CheckCircle size={12} className="text-green-400 ml-auto" />}
                        {insight.status === 'warning' && <span className="text-yellow-400 text-xs">4</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
