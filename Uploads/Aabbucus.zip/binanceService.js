import axios from 'axios'

class BinanceService {
  constructor() {
    // Use Flask backend proxy instead of direct Binance API calls
    this.backendURL = 'http://localhost:5000/api/binance'
    this.apiKey = null
    this.secretKey = null
  }

  setCredentials(apiKey, secretKey) {
    this.apiKey = apiKey
    this.secretKey = secretKey
  }

  // Test API connectivity and credentials via backend proxy
  async testConnection() {
    if (!this.apiKey || !this.secretKey) {
      throw new Error('API credentials not set')
    }

    try {
      const response = await axios.post(`${this.backendURL}/test-connection`, {
        apiKey: this.apiKey,
        secretKey: this.secretKey
      })

      return response.data
    } catch (error) {
      const errorMessage = error.response?.data?.error || error.message
      throw new Error(`Connection failed: ${errorMessage}`)
    }
  }

  // Get account information including balances via backend proxy
  async getAccountInfo() {
    if (!this.apiKey || !this.secretKey) {
      throw new Error('API credentials not set')
    }

    try {
      const response = await axios.post(`${this.backendURL}/account`, {
        apiKey: this.apiKey,
        secretKey: this.secretKey
      })

      if (response.data.success) {
        return response.data.data
      } else {
        throw new Error(response.data.error)
      }
    } catch (error) {
      const errorMessage = error.response?.data?.error || error.message
      throw new Error(`Failed to get account info: ${errorMessage}`)
    }
  }

  // Get current prices for all symbols via backend proxy
  async getCurrentPrices() {
    try {
      const response = await axios.get(`${this.backendURL}/prices`)
      
      if (response.data.success) {
        return response.data.data
      } else {
        throw new Error(response.data.error)
      }
    } catch (error) {
      const errorMessage = error.response?.data?.error || error.message
      throw new Error(`Failed to get current prices: ${errorMessage}`)
    }
  }

  // Calculate portfolio value in USD via backend proxy
  async getPortfolioValue() {
    if (!this.apiKey || !this.secretKey) {
      throw new Error('API credentials not set')
    }

    try {
      const response = await axios.post(`${this.backendURL}/portfolio`, {
        apiKey: this.apiKey,
        secretKey: this.secretKey
      })

      if (response.data.success) {
        return response.data.data
      } else {
        throw new Error(response.data.error)
      }
    } catch (error) {
      const errorMessage = error.response?.data?.error || error.message
      throw new Error(`Failed to calculate portfolio value: ${errorMessage}`)
    }
  }

  // Execute profit siphon strategy (simulation for now)
  async executeProfitSiphon(floors = { btc: 500, eth: 500, sol: 500, xrp: 500 }) {
    try {
      const portfolio = await this.getPortfolioValue()
      const actions = []
      let totalSiphoned = 0

      // Check each core position for profits above floor
      for (const [asset, floor] of Object.entries(floors)) {
        const position = portfolio.positions[asset]
        if (position && position.amount > floor) {
          const profit = position.amount - floor
          const siphonAmount = profit * 0.7 // 70% to war chest
          const reinvestAmount = profit * 0.3 // 30% reinvest

          // For now, simulate the siphon (don't execute real trades)
          if (siphonAmount > 10) { // Only if worth more than $10
            actions.push({
              asset,
              action: 'siphon_simulated',
              amount: siphonAmount,
              reinvestAmount: reinvestAmount,
              message: `Would siphon $${siphonAmount.toFixed(2)} from ${asset.toUpperCase()}`
            })
            totalSiphoned += siphonAmount
          }
        }
      }

      return {
        success: true,
        totalSiphoned,
        actions,
        newPortfolioValue: portfolio.totalValue - totalSiphoned,
        message: `Simulation complete. Would siphon $${totalSiphoned.toFixed(2)} total.`
      }
    } catch (error) {
      throw new Error(`Profit siphon failed: ${error.message}`)
    }
  }

  // Get 24hr ticker statistics via backend proxy
  async get24hrStats() {
    try {
      // This would need to be implemented in the backend
      // For now, return mock data
      return [
        { symbol: 'BTCUSDT', priceChange: '1234.56', priceChangePercent: '2.34' },
        { symbol: 'ETHUSDT', priceChange: '67.89', priceChangePercent: '1.23' },
        { symbol: 'SOLUSDT', priceChange: '4.56', priceChangePercent: '3.45' },
        { symbol: 'XRPUSDT', priceChange: '0.012', priceChangePercent: '1.89' }
      ]
    } catch (error) {
      throw new Error(`Failed to get 24hr stats: ${error.message}`)
    }
  }

  // Execute a trade order (simulation for now)
  async executeTrade(symbol, side, quantity, type = 'MARKET') {
    if (!this.apiKey || !this.secretKey) {
      throw new Error('API credentials not set')
    }

    try {
      // For safety, simulate trades instead of executing real ones
      const prices = await this.getCurrentPrices()
      const symbolKey = `${symbol.toUpperCase()}USDT`
      const price = parseFloat(prices[symbolKey] || 0)
      const value = parseFloat(quantity) * price

      return {
        symbol: symbol.toUpperCase(),
        orderId: Math.floor(Math.random() * 1000000),
        side: side.toUpperCase(),
        type,
        quantity: parseFloat(quantity).toString(),
        price: price.toString(),
        status: 'SIMULATED',
        executedQty: parseFloat(quantity).toString(),
        cummulativeQuoteQty: value.toString(),
        message: `Simulated ${side} order for ${quantity} ${symbol} at $${price}`
      }
    } catch (error) {
      const errorMessage = error.response?.data?.error || error.message
      throw new Error(`Trade simulation failed: ${errorMessage}`)
    }
  }
}

// Export singleton instance
const binanceService = new BinanceService()
export default binanceService

// Export siphon function for compatibility
export const simulateSiphon = async (passphrase, testOnly = false) => {
  const today = new Date().toISOString().slice(0, 10).replace(/-/g, '')
  const expectedPassphrase = `ΩSIGIL-COLLECT-${today}`
  
  if (passphrase !== expectedPassphrase) {
    throw new Error('Invalid passphrase format. Use: ΩSIGIL-COLLECT-YYYYMMDD')
  }

  if (testOnly) {
    // Just validate passphrase, don't execute
    return {
      success: true,
      message: 'Passphrase validated successfully'
    }
  }

  // Execute profit siphon simulation
  return await binanceService.executeProfitSiphon()
}
