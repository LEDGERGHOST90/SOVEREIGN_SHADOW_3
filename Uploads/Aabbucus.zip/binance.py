import hashlib
import hmac
import time
import requests
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin

binance_bp = Blueprint('binance', __name__)

class BinanceProxy:
    def __init__(self):
        self.base_url = 'https://api.binance.us'
    
    def create_signature(self, query_string, secret_key):
        """Create HMAC SHA256 signature for Binance API"""
        return hmac.new(
            secret_key.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
    
    def get_server_time(self):
        """Get Binance server time"""
        try:
            response = requests.get(f'{self.base_url}/api/v3/time', timeout=10)
            response.raise_for_status()
            return response.json()['serverTime']
        except Exception as e:
            raise Exception(f'Failed to get server time: {str(e)}')
    
    def test_connection(self, api_key, secret_key):
        """Test API connection and credentials"""
        try:
            timestamp = self.get_server_time()
            query_string = f'timestamp={timestamp}'
            signature = self.create_signature(query_string, secret_key)
            
            headers = {'X-MBX-APIKEY': api_key}
            params = {'timestamp': timestamp, 'signature': signature}
            
            response = requests.get(
                f'{self.base_url}/api/v3/account',
                headers=headers,
                params=params,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'success': True,
                    'message': 'Connection successful',
                    'accountType': data.get('accountType', 'SPOT')
                }
            else:
                error_msg = response.json().get('msg', 'Unknown error')
                return {
                    'success': False,
                    'error': f'API Error: {error_msg}'
                }
                
        except Exception as e:
            return {
                'success': False,
                'error': f'Connection failed: {str(e)}'
            }
    
    def get_account_info(self, api_key, secret_key):
        """Get account information including balances"""
        try:
            timestamp = self.get_server_time()
            query_string = f'timestamp={timestamp}'
            signature = self.create_signature(query_string, secret_key)
            
            headers = {'X-MBX-APIKEY': api_key}
            params = {'timestamp': timestamp, 'signature': signature}
            
            response = requests.get(
                f'{self.base_url}/api/v3/account',
                headers=headers,
                params=params,
                timeout=10
            )
            
            if response.status_code == 200:
                return {'success': True, 'data': response.json()}
            else:
                error_msg = response.json().get('msg', 'Unknown error')
                return {'success': False, 'error': error_msg}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_prices(self):
        """Get current prices for all symbols"""
        try:
            response = requests.get(f'{self.base_url}/api/v3/ticker/price', timeout=10)
            response.raise_for_status()
            
            prices = {}
            for ticker in response.json():
                prices[ticker['symbol']] = ticker['price']
            
            return {'success': True, 'data': prices}
        except Exception as e:
            return {'success': False, 'error': str(e)}

# Initialize proxy
proxy = BinanceProxy()

@binance_bp.route('/test-connection', methods=['POST'])
@cross_origin()
def test_connection():
    """Test Binance API connection"""
    try:
        data = request.get_json()
        api_key = data.get('apiKey')
        secret_key = data.get('secretKey')
        
        if not api_key or not secret_key:
            return jsonify({'success': False, 'error': 'API key and secret key are required'}), 400
        
        result = proxy.test_connection(api_key, secret_key)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@binance_bp.route('/account', methods=['POST'])
@cross_origin()
def get_account():
    """Get account information"""
    try:
        data = request.get_json()
        api_key = data.get('apiKey')
        secret_key = data.get('secretKey')
        
        if not api_key or not secret_key:
            return jsonify({'success': False, 'error': 'API key and secret key are required'}), 400
        
        result = proxy.get_account_info(api_key, secret_key)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@binance_bp.route('/prices', methods=['GET'])
@cross_origin()
def get_prices():
    """Get current market prices"""
    try:
        result = proxy.get_prices()
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@binance_bp.route('/portfolio', methods=['POST'])
@cross_origin()
def get_portfolio():
    """Calculate portfolio value in USD"""
    try:
        data = request.get_json()
        api_key = data.get('apiKey')
        secret_key = data.get('secretKey')
        
        if not api_key or not secret_key:
            return jsonify({'success': False, 'error': 'API key and secret key are required'}), 400
        
        # Get account info and prices
        account_result = proxy.get_account_info(api_key, secret_key)
        prices_result = proxy.get_prices()
        
        if not account_result['success']:
            return jsonify(account_result)
        
        if not prices_result['success']:
            return jsonify(prices_result)
        
        account_data = account_result['data']
        prices = prices_result['data']
        
        total_value = 0
        positions = {}
        
        for balance in account_data['balances']:
            amount = float(balance['free'])
            if amount > 0:
                value = amount
                
                if balance['asset'] not in ['USDT', 'USD']:
                    symbol = f"{balance['asset']}USDT"
                    price = float(prices.get(symbol, 0))
                    value = amount * price
                
                if value > 1:  # Only include positions worth more than $1
                    positions[balance['asset'].lower()] = {
                        'amount': value,
                        'quantity': amount,
                        'percentage': 0  # Will be calculated after total
                    }
                    total_value += value
        
        # Calculate percentages
        for asset in positions:
            positions[asset]['percentage'] = round((positions[asset]['amount'] / total_value) * 100)
        
        return jsonify({
            'success': True,
            'data': {
                'totalValue': total_value,
                'positions': positions
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
