import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  DollarSign,
  Target,
  Shield,
  Zap,
  AlertTriangle,
  CheckCircle,
  Activity
} from 'lucide-react'
import { motion } from 'framer-motion'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import binanceService from '../services/binanceService'
import { getPortfolioData } from '../api/portfolio'

const LiveDashboard = () => {
  const [portfolioData, setPortfolioData] = useState(null)
  const [marketData, setMarketData] = useState({})
  const [isLoading, setIsLoading] = useState(true)
  const [lastUpdate, setLastUpdate] = useState(null)
  const [connectionStatus, setConnectionStatus] = useState('connecting')
  const [priceHistory, setPriceHistory] = useState([])

  useEffect(() => {
    loadDashboardData()
    
    // Set up real-time updates every 10 seconds
    const interval = setInterval(loadDashboardData, 10000)
    return () => clearInterval(interval)
  }, [])

  const loadDashboardData = async () => {
    try {
      setIsLoading(true)
      setConnectionStatus('connecting')

      // Load portfolio data
      const portfolio = await getPortfolioData()
      setPortfolioData(portfolio)

      // Load market data for core assets
      const coreAssets = ['BTC', 'ETH', 'SOL', 'XRP']
      const marketStats = {}
      
      for (const asset of coreAssets) {
        try {
          const stats = await binanceService.get24hrStats(asset)
          marketStats[asset] = stats
        } catch (error) {
          console.warn(`Failed to get stats for ${asset}:`, error)
        }
      }
      
      setMarketData(marketStats)
      setLastUpdate(new Date())
      setConnectionStatus('connected')

      // Update price history for chart
      const newDataPoint = {
        timestamp: new Date().toLocaleTimeString(),
        totalValue: portfolio.total_value,
        btcPrice: marketStats.BTC?.lastPrice || 0,
        ethPrice: marketStats.ETH?.lastPrice || 0
      }
      
      setPriceHistory(prev => {
        const updated = [...prev, newDataPoint]
        return updated.slice(-20) // Keep last 20 data points
      })

    } catch (error) {
      console.error('Failed to load dashboard data:', error)
      setConnectionStatus('error')
    } finally {
      setIsLoading(false)
    }
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value)
  }

  const formatPercentage = (value) => {
    const sign = value >= 0 ? '+' : ''
    return `${sign}${value.toFixed(2)}%`
  }

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected': return 'text-green-400'
      case 'connecting': return 'text-yellow-400'
      case 'error': return 'text-red-400'
      default: return 'text-muted-foreground'
    }
  }

  const getStatusIcon = () => {
    switch (connectionStatus) {
      case 'connected': return <CheckCircle className="w-4 h-4" />
      case 'connecting': return <RefreshCw className="w-4 h-4 animate-spin" />
      case 'error': return <AlertTriangle className="w-4 h-4" />
      default: return <Activity className="w-4 h-4" />
    }
  }

  // Prepare pie chart data
  const pieData = portfolioData ? Object.entries(portfolioData)
    .filter(([key, value]) => key !== 'total_value' && key !== 'total_change_24h' && key !== 'total_change_percent' && key !== 'last_updated' && key !== 'source')
    .map(([key, value]) => ({
      name: key.toUpperCase(),
      value: value.amount,
      percentage: value.percentage
    })) : []

  const COLORS = ['#6EE7FF', '#FF6EE7', '#A3FF8F', '#FFCBA4', '#C084FC']

  return (
    <div className="space-y-6">
      {/* Status Header */}
      <Card className="glass-card">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className={`flex items-center space-x-2 ${getStatusColor()}`}>
                {getStatusIcon()}
                <span className="font-semibold">
                  {connectionStatus === 'connected' ? 'Live Data' : 
                   connectionStatus === 'connecting' ? 'Connecting...' : 'Connection Error'}
                </span>
              </div>
              {lastUpdate && (
                <div className="text-sm text-muted-foreground">
                  Last update: {lastUpdate.toLocaleTimeString()}
                </div>
              )}
            </div>
            <Button onClick={loadDashboardData} variant="ghost" size="sm">
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Portfolio Overview */}
      {portfolioData && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="glass-card border-green-500/30">
            <CardContent className="p-6 text-center">
              <DollarSign className="w-8 h-8 mx-auto mb-2 text-green-400" />
              <div className="text-2xl font-bold text-green-400">
                {formatCurrency(portfolioData.total_value)}
              </div>
              <div className="text-sm text-muted-foreground">Total Portfolio</div>
              <div className={`text-sm font-semibold ${portfolioData.total_change_percent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatPercentage(portfolioData.total_change_percent)} (24h)
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card border-[#6EE7FF]/30">
            <CardContent className="p-6 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-[#6EE7FF]" />
              <div className="text-2xl font-bold text-[#6EE7FF]">
                {formatCurrency(portfolioData.usdt?.amount || 0)}
              </div>
              <div className="text-sm text-muted-foreground">USDT War Chest</div>
              <div className="text-sm text-[#6EE7FF]">
                {portfolioData.usdt?.percentage || 0}% of portfolio
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card border-[#FF6EE7]/30">
            <CardContent className="p-6 text-center">
              <Shield className="w-8 h-8 mx-auto mb-2 text-[#FF6EE7]" />
              <div className="text-2xl font-bold text-[#FF6EE7]">
                {Object.keys(portfolioData).filter(key => 
                  !['total_value', 'total_change_24h', 'total_change_percent', 'last_updated', 'source', 'usdt'].includes(key)
                ).length}
              </div>
              <div className="text-sm text-muted-foreground">Core Assets</div>
              <div className="text-sm text-[#FF6EE7]">Active positions</div>
            </CardContent>
          </Card>

          <Card className="glass-card border-[#A3FF8F]/30">
            <CardContent className="p-6 text-center">
              <Zap className="w-8 h-8 mx-auto mb-2 text-[#A3FF8F]" />
              <div className="text-2xl font-bold text-[#A3FF8F]">
                {formatCurrency(portfolioData.total_change_24h || 0)}
              </div>
              <div className="text-sm text-muted-foreground">24h P&L</div>
              <div className={`text-sm font-semibold ${(portfolioData.total_change_24h || 0) >= 0 ? 'text-[#A3FF8F]' : 'text-red-400'}`}>
                {(portfolioData.total_change_24h || 0) >= 0 ? 'Profit' : 'Loss'}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Portfolio Composition */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle>Portfolio Composition</CardTitle>
          </CardHeader>
          <CardContent>
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percentage }) => `${name} ${percentage}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No portfolio data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Price Chart */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle>Portfolio Value Trend</CardTitle>
          </CardHeader>
          <CardContent>
            {priceHistory.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={priceHistory}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis dataKey="timestamp" stroke="rgba(255,255,255,0.5)" />
                  <YAxis stroke="rgba(255,255,255,0.5)" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(0,0,0,0.8)', 
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px'
                    }}
                    formatter={(value) => formatCurrency(value)}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="totalValue" 
                    stroke="#6EE7FF" 
                    strokeWidth={2}
                    dot={{ fill: '#6EE7FF', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                Collecting price data...
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Market Data */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Market Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(marketData).map(([asset, stats]) => (
              <motion.div
                key={asset}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-card p-4 rounded-lg"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-primary">{asset}</span>
                  {stats.priceChangePercent >= 0 ? 
                    <TrendingUp className="w-4 h-4 text-green-400" /> : 
                    <TrendingDown className="w-4 h-4 text-red-400" />
                  }
                </div>
                <div className="text-xl font-bold mb-1">
                  {formatCurrency(stats.lastPrice)}
                </div>
                <div className={`text-sm font-semibold ${stats.priceChangePercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {formatPercentage(stats.priceChangePercent)}
                </div>
                <div className="text-xs text-muted-foreground">
                  {formatCurrency(stats.priceChange)} (24h)
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default LiveDashboard
