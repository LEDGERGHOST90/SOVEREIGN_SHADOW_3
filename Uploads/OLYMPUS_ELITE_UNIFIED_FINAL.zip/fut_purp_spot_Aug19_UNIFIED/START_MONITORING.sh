#!/bin/bash
echo "👁️ STARTING 24/7 HEDGE MONITORING"
echo "================================="
python3 OLYMPUS_ELITE_UNIFIED_SYSTEM.py start_monitoring
