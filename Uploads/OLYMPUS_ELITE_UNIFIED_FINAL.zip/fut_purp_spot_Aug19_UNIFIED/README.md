# OLYMPUS ELITE UNIFIED HEDGE SYSTEM

## Single File Architecture
All components consolidated into `OLYMPUS_ELITE_UNIFIED_SYSTEM.py`
- ✅ All paths purged from old `/home/ubuntu/` references
- ✅ Project-relative path management
- ✅ Complete hedge automation system
- ✅ Overseer approval workflow
- ✅ 24/7 monitoring system
- ✅ Comprehensive smoke testing

## Quick Start

```bash
# Run smoke test
./RUN_SMOKE_TEST.sh

# Execute hedge (with approval workflow)
./EXECUTE_HEDGE.sh

# Start 24/7 monitoring
./START_MONITORING.sh
```

## Manual Commands

```bash
# Smoke test
python3 OLYMPUS_ELITE_UNIFIED_SYSTEM.py smoke_test

# Execute hedge
python3 OLYMPUS_ELITE_UNIFIED_SYSTEM.py execute_hedge

# Start monitoring
python3 OLYMPUS_ELITE_UNIFIED_SYSTEM.py start_monitoring

# Device scan
python3 OLYMPUS_ELITE_UNIFIED_SYSTEM.py device_scan

# Vault snapshot
python3 OLYMPUS_ELITE_UNIFIED_SYSTEM.py vault_snapshot
```

## Directory Structure (Auto-Created)
```
/
├── OLYMPUS_ELITE_UNIFIED_SYSTEM.py  # Main system file
├── state/                           # State files
├── logs/                           # Log files
├── data/                           # Data files
└── *.sh                           # Launcher scripts
```

## Features
- 🎯 Overseer approval workflow
- 🛡️ 24/7 hedge monitoring
- 🔐 Ledger hardware wallet integration
- 📊 Portfolio analysis and hedging
- 🚨 Risk management and alerts
- 🧪 Comprehensive smoke testing

Built by: Manus AI Systems Engineer
Date: August 19, 2025
