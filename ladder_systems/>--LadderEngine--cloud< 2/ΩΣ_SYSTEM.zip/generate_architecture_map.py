#!/usr/bin/env python3
"""
ΩΣ SYSTEM ARCHITECTURE MAPPER
=============================
This script generates a complete, polished snapshot of the current file and folder structure
for your Ω_ΣIGMA_Systems environment. Ideal for verifying system readiness, documentation
sync, and Notion dashboard embedding.

Author: LedgerGhost90
Date: Final Sweep — STRUCTURE_LOCK_0712
"""

import os
from datetime import datetime

ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
IGNORED_DIRS = {'.git', '__pycache__', 'venv', 'archives', 'legacy', '.cache', '.nvm', '.browser_data_dir', '.npm', '.config', '.local', '.logs', '.pki', '.secrets'}
IGNORED_FILES = {'.DS_Store', '.bash_logout', '.bashrc', '.profile', '.zshrc', '.env'}

def generate_tree(path, prefix=''):
    """
    Recursively generates a directory tree structure. [1, 3]
    """
    try:
        entries = sorted([e for e in os.listdir(path) if e not in IGNORED_FILES])
    except PermissionError:
        return []
    
    output = []
    for idx, entry in enumerate(entries):
        full_path = os.path.join(path, entry)
        is_last = idx == len(entries) - 1
        connector = '└── ' if is_last else '├── '
        sub_prefix = '    ' if is_last else '│   '

        if os.path.isdir(full_path) and entry not in IGNORED_DIRS:
            output.append(f"{prefix}{connector}{entry}/")
            output += generate_tree(full_path, prefix + sub_prefix)
        elif os.path.isfile(full_path):
            # Get file size for additional info
            try:
                size = os.path.getsize(full_path)
                if size > 1024*1024:  # > 1MB
                    size_str = f" ({size/(1024*1024):.1f}MB)"
                elif size > 1024:  # > 1KB
                    size_str = f" ({size/1024:.1f}KB)"
                else:
                    size_str = f" ({size}B)"
            except:
                size_str = ""
            
            output.append(f"{prefix}{connector}{entry}{size_str}")
    return output

def main():
    """
    Main function to generate and print the architecture report.
    """
    timestamp = datetime.utcnow().isoformat()
    print(f"\nΩΣ SYSTEM ARCHITECTURE REPORT")
    print(f"Generated: {timestamp}")
    print(f"Root Directory: {ROOT_DIR}")
    print(f"Status: ACTIVE CLEANUP PHASE")
    print("\nFile Structure:\n")

    tree_output = generate_tree(ROOT_DIR)
    for line in tree_output:
        print(line)

    print(f"\nTotal files scanned: {len([line for line in tree_output if not line.strip().endswith('/')])}")
    print(f"Total directories: {len([line for line in tree_output if line.strip().endswith('/')])}")
    print("\nStatus: ✅ STRUCTURE_SCAN_COMPLETE | ΩΣ SYSTEM MAPPING\n")

if __name__ == "__main__":
    main()

